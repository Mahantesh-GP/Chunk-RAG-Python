#!/bin/bash
# =============================================================================
# Spec Kit Setup Script
# GHCP Rollout Dashboard — Playwright E2E Tests
# Run this once from your project root folder
# =============================================================================

set -e  # stop on any error

echo ""
echo "============================================"
echo "  Spec Kit Setup — GHCP Rollout Dashboard"
echo "============================================"
echo ""

# -----------------------------------------------------------------------------
# STEP 1: Check we are in the right folder
# -----------------------------------------------------------------------------
echo "→ Checking project folder..."

if [ ! -f "config.py" ]; then
  echo ""
  echo "  ⚠️  WARNING: config.py not found in current folder."
  echo "  Make sure you are running this from your dashboard project root."
  echo "  Example: cd /path/to/your-dashboard-project && bash 01-setup.sh"
  echo ""
  read -p "  Continue anyway? (y/n): " confirm
  if [ "$confirm" != "y" ]; then
    echo "  Aborted. Navigate to your project root and try again."
    exit 1
  fi
fi

echo "  ✅ Project folder confirmed"

# -----------------------------------------------------------------------------
# STEP 2: Check Git is initialised
# -----------------------------------------------------------------------------
echo ""
echo "→ Checking Git..."

if [ ! -d ".git" ]; then
  echo "  Git not initialised. Initialising now..."
  git init
  git add .
  git commit -m "Initial commit before Spec Kit setup" --allow-empty
  echo "  ✅ Git initialised"
else
  echo "  ✅ Git already initialised"
fi

# -----------------------------------------------------------------------------
# STEP 3: Check Python is available
# -----------------------------------------------------------------------------
echo ""
echo "→ Checking Python..."

if ! command -v python3 &> /dev/null; then
  echo "  ❌ Python3 not found. Please install Python 3.8+ and try again."
  exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1)
echo "  ✅ $PYTHON_VERSION found"

# -----------------------------------------------------------------------------
# STEP 4: Check uv or pipx is available, install uv if needed
# -----------------------------------------------------------------------------
echo ""
echo "→ Checking package installer (uv or pipx)..."

if command -v uv &> /dev/null; then
  echo "  ✅ uv found — using uv"
  INSTALLER="uv"
elif command -v pipx &> /dev/null; then
  echo "  ✅ pipx found — using pipx"
  INSTALLER="pipx"
else
  echo "  uv not found. Installing uv now..."
  pip install uv --quiet
  INSTALLER="uv"
  echo "  ✅ uv installed"
fi

# -----------------------------------------------------------------------------
# STEP 5: Install Playwright if not present
# -----------------------------------------------------------------------------
echo ""
echo "→ Checking Playwright..."

if ! python3 -c "import playwright" &> /dev/null; then
  echo "  Playwright not found. Installing..."
  pip install pytest-playwright --quiet
  python3 -m playwright install chromium
  echo "  ✅ Playwright installed"
else
  echo "  ✅ Playwright already installed"
fi

# -----------------------------------------------------------------------------
# STEP 6: Install Spec Kit CLI
# -----------------------------------------------------------------------------
echo ""
echo "→ Installing Spec Kit CLI..."

if command -v specify &> /dev/null; then
  echo "  Spec Kit already installed. Checking version..."
  specify --version || true
else
  if [ "$INSTALLER" = "uv" ]; then
    uvx --from git+https://github.com/github/spec-kit.git specify --version > /dev/null 2>&1 || true
  else
    pipx install git+https://github.com/github/spec-kit.git --quiet || true
  fi
fi

echo "  ✅ Spec Kit CLI ready"

# -----------------------------------------------------------------------------
# STEP 7: Initialise Spec Kit in this project
# -----------------------------------------------------------------------------
echo ""
echo "→ Initialising Spec Kit in your project..."

if [ "$INSTALLER" = "uv" ]; then
  uvx --from git+https://github.com/github/spec-kit.git specify init . --here --integration copilot --force
else
  specify init . --here --integration copilot --force
fi

echo "  ✅ Spec Kit initialised"

# -----------------------------------------------------------------------------
# STEP 8: Create required folders
# -----------------------------------------------------------------------------
echo ""
echo "→ Creating required folders..."

mkdir -p tests/screenshots/rollout
mkdir -p .specify/specs

echo "  ✅ tests/screenshots/rollout/ created"
echo "  ✅ .specify/specs/ confirmed"

# -----------------------------------------------------------------------------
# STEP 9: Verify .github/prompts exists
# -----------------------------------------------------------------------------
echo ""
echo "→ Verifying Copilot slash commands..."

if [ -d ".github/prompts" ]; then
  PROMPT_COUNT=$(ls .github/prompts/*.md 2>/dev/null | wc -l)
  echo "  ✅ $PROMPT_COUNT slash command files found in .github/prompts/"
else
  echo "  ⚠️  .github/prompts not found — slash commands may not work"
  echo "  Try: specify init . --here --integration copilot --force"
fi

# -----------------------------------------------------------------------------
# STEP 10: Verify setup
# -----------------------------------------------------------------------------
echo ""
echo "→ Running verify check..."

if [ "$INSTALLER" = "uv" ]; then
  uvx --from git+https://github.com/github/spec-kit.git specify check || echo "  ⚠️  specify check reported issues — see above"
else
  specify check || echo "  ⚠️  specify check reported issues — see above"
fi

# -----------------------------------------------------------------------------
# DONE
# -----------------------------------------------------------------------------
echo ""
echo "============================================"
echo "  ✅ Setup Complete!"
echo "============================================"
echo ""
echo "Next steps:"
echo ""
echo "  1. Open this project in VS Code:"
echo "     code ."
echo ""
echo "  2. Open GitHub Copilot Chat (Ctrl+Shift+I)"
echo ""
echo "  3. Follow 03-step-by-step-guide.md"
echo "     Use prompts from 04-copilot-prompts.md"
echo ""
echo "  4. Run all 4 commands in order:"
echo "     /speckit.constitution"
echo "     /speckit.specify"
echo "     /speckit.tasks"
echo "     /speckit.implement"
echo ""
echo "  5. Run tests:"
echo "     pytest tests/test_rollout_dashboard.py -v"
echo ""
echo "============================================"
echo ""
