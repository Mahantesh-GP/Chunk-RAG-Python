# Business Requirements Document
## GHCP Rollout Dashboard — Playwright E2E Tests

**Version:** 1.0  
**Date:** May 2026  
**Author:** Mahantesh  
**Purpose:** Source document for Spec Kit `/speckit.specify` command  
**How to use:** Attach this file in Copilot Chat when running `/speckit.specify`

---

## Business Objective

The GHCP Rollout Dashboard is already built and running. It tracks GenAI SDLC 
Phase 1 adoption across teams and is consumed by PMs, DRs, EA Team, and Senior 
Leadership daily.

The objective of this BRD is to define requirements for automated Playwright 
end-to-end tests that validate the dashboard after every regeneration — ensuring 
data accuracy, structural integrity, and security compliance are verified 
automatically without manual checking.

---

## Current State

- Dashboard HTML is generated daily from Excel via JSON intermediate file
- No automated tests exist for the rollout dashboard specifically
- Validation is currently manual — developer checks visually after generation
- Manager has requested: test scenarios documented, code path in repo, 
  validation approach explained
- Security fixes (CSP, XSS, inline JS) were applied — tests must confirm 
  these fixes hold after every regeneration

---

## Existing File Locations

| File | Path |
|---|---|
| Generated HTML | Package/Rollout/rllot_dashboard.html |
| Source JSON | Package/Rollout/rllot_data.json |
| Dashboard config | config.py (rollout entry) |
| Tests folder | tests/ |
| Screenshots | tests/screenshots/rollout/ |

---

## What Must Be Tested

### 1. Page Structure
- Dashboard page loads without errors
- Title reads: "GHCP Rollout Dashboard"
- Subtitle describes rollout progress tracking purpose
- Last refresh timestamp is visible
- All three data sections present:
  - BackEnd_Unit_Testing
  - Gen_Test_Case
  - Gen_Scripts_4_PostMan
- Each section has a visible data table

### 2. Data Accuracy
- At least one data row visible per section when JSON has data
- Values displayed in HTML match values in rllot_data.json
- No section shows empty table when JSON source has data
- Team names in HTML match team names in JSON

### 3. Security Validation
- Content Security Policy meta tag present in HTML head
- Zero inline JavaScript event handlers in HTML 
  (no onclick, onload, onerror, onmouseover)
- Zero inline script blocks with code content
- All displayed values are properly escaped 
  (no raw < > & characters from data)

### 4. Baseline Capture
- Screenshot captured after all tests pass
- Saved to tests/screenshots/rollout/baseline.png
- Baseline used for future regression comparison

---

## Success Criteria

- SC-001: All tests pass on current dashboard with zero failures
- SC-002: If dashboard is regenerated tomorrow same tests pass
- SC-003: If a security fix is accidentally reverted at least one test fails
- SC-004: If data in JSON changes the HTML reflects it correctly
- SC-005: Test file is in tests/ folder and runs with single pytest command
- SC-006: Each test function has a comment showing which requirement it covers
- SC-007: Test scenarios and code path are documented for manager review

---

## Out of Scope

- Testing the Python generation scripts (process_rollout.py, build_rollout_dashboard.py)
- Performance testing
- Cross-browser testing (Chrome only)
- Mobile testing
- Authentication testing (no auth on this dashboard)

---

## Constraints

- Single test file only: tests/test_rollout_dashboard.py
- No changes to existing Python scripts
- No new dependencies beyond existing Playwright setup
- Must reuse existing config.py pattern
- Tests must run with: pytest tests/test_rollout_dashboard.py -v

