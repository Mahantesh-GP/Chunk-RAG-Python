# Verify Checklist
## Confirm Everything Worked Correctly

Run through this checklist after completing all 4 Copilot commands.

---

## After Setup Script (01-setup.sh)

```bash
# Run these in your project root terminal

# Spec Kit folders exist
ls .specify/memory/
ls .specify/specs/
ls .github/prompts/

# Screenshots folder exists
ls tests/screenshots/rollout/

# Dashboard files exist
ls Package/Rollout/rllot_dashboard.html
ls Package/Rollout/rllot_data.json
```

| Check | Command | Expected |
|---|---|---|
| .specify folder | `ls .specify/` | memory/ specs/ templates/ |
| Copilot prompts | `ls .github/prompts/` | speckit.*.md files |
| Screenshots folder | `ls tests/screenshots/` | rollout/ folder |

---

## After Prompt 1 — Constitution

```bash
# Constitution file exists
cat .specify/memory/constitution.md

# Templates updated
ls .specify/templates/
```

| Check | What to look for |
|---|---|
| constitution.md exists | File present with your rules |
| Testing rules present | "pytest-playwright" mentioned |
| Simplicity rules present | "single test file" mentioned |
| Templates updated | plan-template.md modified timestamp recent |

---

## After Prompt 2 — Specify

```bash
# Spec folder created
ls .specify/specs/

# Spec file exists
cat .specify/specs/001-rollout-dashboard-e2e-tests/spec.md
```

| Check | What to look for |
|---|---|
| Git branch created | `git branch` shows 001-rollout-dashboard-e2e-tests |
| spec.md exists | File present in specs/001-... folder |
| FR-XXX items | spec.md contains FR-001, FR-002 etc |
| SC-XXX items | spec.md contains SC-001, SC-002 etc |
| No tech details | No mention of Python, Playwright, JSON in spec.md |
| No gaps remaining | Zero [NEEDS CLARIFICATION] markers |

---

## After Prompt 3 — Tasks

```bash
# Tasks file exists
cat .specify/specs/001-rollout-dashboard-e2e-tests/tasks.md
```

| Check | What to look for |
|---|---|
| tasks.md exists | File present |
| Phase 1 is Setup | First phase = verify files and config |
| Phase 2 is Structure | Second phase = page load, title, sections |
| Phase 3 is Data | Third phase = HTML vs JSON accuracy |
| Phase 4 is Security | Fourth phase = CSP, inline handlers |
| Phase 5 is Screenshot | Fifth phase = baseline capture |
| Phase 6 is Docs | Sixth phase = documentation for manager |
| File paths correct | tasks reference Package/Rollout/ paths |

---

## After Prompt 4 — Implement

```bash
# Test file exists
cat tests/test_rollout_dashboard.py

# Count test functions
grep "def test_" tests/test_rollout_dashboard.py | wc -l
```

| Check | What to look for |
|---|---|
| test file exists | tests/test_rollout_dashboard.py present |
| At least 8 tests | grep "def test_" shows 8+ functions |
| FR comments present | Each function has # Validates: FR-XXX comment |
| Correct HTML path | Package/Rollout/rllot_dashboard.html in file |
| Correct JSON path | Package/Rollout/rllot_data.json in file |
| No hardcoded values | No hardcoded team names or data values |
| Screenshot path | tests/screenshots/rollout/baseline.png |
| tasks.md all checked | All [ ] replaced with [x] in tasks.md |

---

## After Running Tests

```bash
pytest tests/test_rollout_dashboard.py -v
```

| Check | Expected |
|---|---|
| All tests pass | X passed, 0 failed |
| No import errors | No ModuleNotFoundError |
| Screenshot created | tests/screenshots/rollout/baseline.png exists |
| Runtime reasonable | Under 60 seconds |

```bash
# Confirm screenshot was created
ls -la tests/screenshots/rollout/
```

---

## After Prompt 5 — Checklist

```bash
# Checklist exists
cat ".specify/specs/001-rollout-dashboard-e2e-tests/checklists/rollout.md"
```

| Check | What to look for |
|---|---|
| Checklist exists | File present in checklists/ folder |
| Test coverage section | Lists each test with FR-XXX |
| Security section | Describes CSP and inline handler checks |
| Code path section | Shows exact file path in repo |
| Run command present | Shows pytest command |
| Manager-readable | Plain English, no jargon |

---

## Final Confirmation — Share With Manager

These three things answer your manager's request:

| What manager asked for | Where it is |
|---|---|
| Test scenarios documented | `.specify/specs/001-.../spec.md` |
| Code path in repo | `checklists/rollout.md` — Code path section |
| Validation approach explained | `checklists/rollout.md` — Data accuracy section |
| Tests actually working | pytest output — all passed |

---

## All Good?

If all checks pass:

```bash
# Commit everything
git add .
git commit -m "feat: add Playwright E2E tests for rollout dashboard via Spec Kit"
```

Done. ✅

