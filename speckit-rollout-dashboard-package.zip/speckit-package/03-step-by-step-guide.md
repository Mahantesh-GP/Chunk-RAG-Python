# Step by Step Guide
## Spec Kit — Playwright E2E Tests for GHCP Rollout Dashboard

**Time required:** ~1 hour  
**Prerequisites:** Setup script `01-setup.sh` already run successfully  
**Where you work:** GitHub Copilot Chat in VS Code  

---

## Before You Start — Confirm These

Open terminal in your project and verify:

```bash
# 1. Spec Kit slash commands exist
ls .github/prompts/

# 2. Screenshots folder exists  
ls tests/screenshots/rollout/

# 3. Your dashboard files exist
ls Package/Rollout/rllot_dashboard.html
ls Package/Rollout/rllot_data.json

# 4. Config has rollout entry
grep -i "rollout" config.py
```

If any of these fail — re-run `01-setup.sh` before continuing.

---

## Overview — 4 Commands Only

```
COMMAND 1: /speckit.constitution   ← set testing rules
COMMAND 2: /speckit.specify        ← describe what to test  
COMMAND 3: /speckit.tasks          ← break into test tasks
COMMAND 4: /speckit.implement      ← generate test code
```

No plan. No analyze. Just these 4.

---

## COMMAND 1 — /speckit.constitution

**Open Copilot Chat → type this exactly:**

```
/speckit.constitution

This constitution is for Playwright test generation only.
Existing code must not be modified.

Testing framework:
- Playwright Python with pytest-playwright
- Single test file: tests/test_rollout_dashboard.py
- Screenshots: tests/screenshots/rollout/
- Run command: pytest tests/test_rollout_dashboard.py -v

Test coverage order (must follow this order):
1. Structure tests — page loads, sections present
2. Data accuracy tests — HTML values match JSON
3. Security tests — CSP present, no inline handlers
4. Baseline screenshot — captured last

Test quality rules:
- Each test function must have a comment referencing which
  requirement it validates
- Data accuracy tests must read from JSON dynamically —
  no hardcoded expected values
- Security tests must parse actual HTML — not screenshot based
- Tests must pass on the current dashboard on first run

Simplicity rules:
- Single test file only — no helper classes
- Plain pytest functions — no class-based tests
- No mocking — test against actual generated files
- No changes to config.py, process_rollout.py,
  or build_rollout_dashboard.py
```

**Wait for:** `.specify/memory/constitution.md` to be created

**Then check:** Copilot shows constitution.md content and templates updated

**When to move on:** Constitution created with no errors

---

## COMMAND 2 — /speckit.specify

**In Copilot Chat — attach file first:**
1. Click paperclip icon in Copilot Chat
2. Attach `02-brd.md` from this package

**Then type this prompt:**

```
/speckit.specify

I have attached the BRD as a file. Read it fully.

Feature name for this spec: rollout-dashboard-e2e-tests

Extract spec.md following Spec Kit template rules:
- Convert all test requirements to FR-XXX format
- Convert all success criteria to SC-XXX format
- Do NOT include technology details in spec.md
  (Playwright, Python, JSON paths — these go to plan.md)
- Mark anything ambiguous with [NEEDS CLARIFICATION]
- Business language only in spec.md

Additional context:
- This dashboard is already built and running
- We are adding tests only — zero code changes
- Three data sections exist: BackEnd_Unit_Testing,
  Gen_Test_Case, Gen_Scripts_4_PostMan
- Manager has specifically asked for test documentation
  and code path in repo
```

**Wait for:**
- Git branch `001-rollout-dashboard-e2e-tests` created
- `.specify/specs/001-rollout-dashboard-e2e-tests/spec.md` created

**Then check:**
- spec.md has FR-XXX and SC-XXX numbered items
- No technology details inside spec.md
- Any [NEEDS CLARIFICATION] markers visible

**If [NEEDS CLARIFICATION] appears:** Answer each one directly in Copilot Chat before moving on. Common answers:
- Authentication: Not required — internal only
- Empty sections: Show "No data" message — do not hide table
- Screenshot format: PNG only

**When to move on:** spec.md exists with zero [NEEDS CLARIFICATION] remaining

---

## COMMAND 3 — /speckit.tasks

**In Copilot Chat — type this exactly:**

```
/speckit.tasks

Generate tasks for feature 001-rollout-dashboard-e2e-tests.

Requirements:
- Tests only — no implementation tasks
- Phase order must be:
  Phase 1: Setup (verify files exist, verify config entry)
  Phase 2: Structure tests (page load, title, sections)
  Phase 3: Data accuracy tests (HTML vs JSON matching)
  Phase 4: Security tests (CSP, no inline handlers)
  Phase 5: Baseline screenshot capture
  Phase 6: Documentation (code path, test scenarios for manager)

- Each task must specify:
  - Exact file path
  - Exact function name to create
  - Which FR-XXX or SC-XXX it satisfies

- Mark parallel-safe tasks with [P]

Existing structure to follow:
- config.py already has rollout entry — just verify it
- tests/ folder already exists — add file there
- Package/Rollout/ paths are fixed — reference them exactly
```

**Wait for:** `.specify/specs/001-rollout-dashboard-e2e-tests/tasks.md` created

**Then check:**
- Phase 2 (structure) comes before Phase 3 (data) before Phase 4 (security)
- Phase 6 documentation task exists
- All file paths look correct

**When to move on:** tasks.md exists and phase order is correct

---

## COMMAND 4 — /speckit.implement

**In Copilot Chat — type this exactly:**

```
/speckit.implement

Execute all tasks in tasks.md for feature 
001-rollout-dashboard-e2e-tests.

Critical rules — read before writing any code:
- Read constitution.md first
- Single test file: tests/test_rollout_dashboard.py
- Each test function must have this comment format:
  # Validates: FR-001 — page loads without errors

- Data accuracy tests:
  Read Package/Rollout/rllot_data.json directly
  Compare JSON values to what appears in HTML
  Do NOT hardcode any expected values

- Security tests:
  Parse HTML file content directly using Python
  Check for: CSP meta tag, inline event handlers,
  inline script blocks
  Use string parsing or BeautifulSoup — not screenshots

- Do NOT modify these files:
  config.py
  process_rollout.py
  build_rollout_dashboard.py

- After writing tests — show me the complete test file
  so I can review before you mark tasks complete

- Mark each task complete in tasks.md as you finish it
```

**Wait for:** Complete `tests/test_rollout_dashboard.py` shown in chat

**Review the generated file — check these:**

```
□ Imports: playwright, json, os, pathlib present
□ File paths reference Package/Rollout/ correctly
□ JSON keys match your actual rllot_data.json structure
□ Each test function has # Validates: FR-XXX comment
□ No hardcoded expected values in data accuracy tests
□ Security tests parse HTML as text — not screenshots
□ Screenshot saves to tests/screenshots/rollout/baseline.png
```

**If any path or key is wrong — fix it:**
```
The JSON structure uses key "Team_Name" not "Team".
Update test_data_accuracy to use "Team_Name".
```

**When to move on:** File reviewed and looks correct

---

## Run Your Tests

```bash
# From your project root
pytest tests/test_rollout_dashboard.py -v
```

**Expected output:**
```
tests/test_rollout_dashboard.py::test_page_loads              PASSED
tests/test_rollout_dashboard.py::test_title_correct           PASSED
tests/test_rollout_dashboard.py::test_subtitle_present        PASSED
tests/test_rollout_dashboard.py::test_timestamp_visible       PASSED
tests/test_rollout_dashboard.py::test_backend_section_present PASSED
tests/test_rollout_dashboard.py::test_testcase_section_present PASSED
tests/test_rollout_dashboard.py::test_postman_section_present PASSED
tests/test_rollout_dashboard.py::test_data_matches_json       PASSED
tests/test_rollout_dashboard.py::test_csp_meta_present        PASSED
tests/test_rollout_dashboard.py::test_no_inline_handlers      PASSED
tests/test_rollout_dashboard.py::test_no_inline_scripts       PASSED
tests/test_rollout_dashboard.py::test_baseline_screenshot     PASSED

12 passed in 15.32s
```

---

## Get Manager Sign-Off Document

**In Copilot Chat — type this:**

```
/speckit.checklist

Generate a review checklist for feature 
001-rollout-dashboard-e2e-tests.

Include these sections:
1. Test coverage — list each test with FR-XXX it covers
2. Security validation — what security tests check
3. Data accuracy — how tests verify HTML matches JSON source
4. Code path — exact file location in repo
5. How to run — exact pytest command
6. Screenshot baseline — where it is saved and what it proves

This document is for manager sign-off.
Format it so a non-technical manager can understand it.
```

**Output:** `.specify/specs/001-rollout-dashboard-e2e-tests/checklists/rollout.md`

Share this file with your manager. It directly addresses the documentation request.

---

## Troubleshooting

**Slash commands not appearing in Copilot Chat:**
```bash
specify init . --here --integration copilot --force
# Restart VS Code
```

**Copilot ignores constitution:**
Start every prompt with: `"Read constitution.md first. Then..."`

**Test file paths wrong:**
Tell Copilot: `"The HTML file is at Package/Rollout/rllot_dashboard.html — update all path references"`

**JSON keys not matching:**
```bash
# Check your actual JSON keys
python3 -c "import json; d=json.load(open('Package/Rollout/rllot_data.json')); print(list(d.keys())); print(list(d[list(d.keys())[0]][0].keys()))"
```
Then tell Copilot the correct key names.

**Playwright browser not found:**
```bash
python3 -m playwright install chromium
```

**Tests fail on CSP check:**
```bash
# Check what CSP looks like in your HTML
grep -i "content-security" Package/Rollout/rllot_dashboard.html
```
If missing — your HTML generation script needs the fix first.

**Git hook fires on first command:**
Normal — Spec Kit checks Git is ready. Click Continue.

**"Build Specification" dropdown appears:**
Choose "Continue in Copilot CLI" — always, for local projects.

