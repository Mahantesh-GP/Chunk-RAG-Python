# Spec Kit Setup Package
## GHCP Rollout Dashboard — Playwright E2E Tests

**Start here. Read this first.**

---

## What is in this package

| File | Purpose |
|---|---|
| `README.md` | This file — read first |
| `01-setup.sh` | Run once — installs Spec Kit in your project |
| `02-brd.md` | BRD for GHCP Rollout Dashboard — attach in Copilot Chat |
| `03-step-by-step-guide.md` | Complete walkthrough with copy-paste prompts |
| `04-copilot-prompts.md` | All 4 prompts in one place — copy paste directly |
| `05-verify-checklist.md` | Verify everything worked correctly |

---

## How to use this package

### On your machine

**Step 1 — Copy setup script to your project root**
```bash
cp 01-setup.sh /path/to/your-dashboard-project/
cd /path/to/your-dashboard-project/
```

**Step 2 — Run the setup script**
```bash
bash 01-setup.sh
```

**Step 3 — Open project in VS Code**
```bash
code .
```

**Step 4 — Follow 03-step-by-step-guide.md**
Open Copilot Chat and use prompts from `04-copilot-prompts.md`

**Step 5 — Verify with 05-verify-checklist.md**
Confirm everything is set up correctly

---

## Folder structure after setup

```
your-dashboard-project/
├── .specify/
│   ├── memory/
│   │   └── constitution.md        ← generated in Step 1 of guide
│   └── specs/
│       └── 001-rollout-e2e-tests/
│           ├── spec.md            ← generated in Step 2
│           ├── tasks.md           ← generated in Step 3
│           └── checklists/
│               └── rollout.md     ← manager sign-off doc
├── .github/
│   └── prompts/                   ← Copilot slash commands
├── tests/
│   └── test_rollout_dashboard.py  ← generated Playwright tests
└── tests/screenshots/rollout/
    └── baseline.png               ← captured after tests pass
```

---

## Time required

| Activity | Time |
|---|---|
| Run setup script | 2 minutes |
| Run 4 Copilot commands | 30-45 minutes |
| Review and run tests | 15 minutes |
| **Total** | **~1 hour** |

---

## If something goes wrong

See the Troubleshooting section at the bottom of `03-step-by-step-guide.md`

