# All Copilot Prompts — Ready to Copy Paste
## GHCP Rollout Dashboard — Spec Kit E2E Tests

Copy each prompt in order. Paste into GitHub Copilot Chat in VS Code.

---

## PROMPT 1 — Constitution
### Paste this into Copilot Chat first

```
/speckit.constitution

This constitution is for Playwright test generation only.
Existing code must not be modified.

Testing framework:
- Playwright Python with pytest-playwright
- Single test file: tests/test_rollout_dashboard.py
- Screenshots: tests/screenshots/rollout/
- Run command: pytest tests/test_rollout_dashboard.py -v

Test coverage order (must follow this order):
1. Structure tests — page loads, sections present
2. Data accuracy tests — HTML values match JSON
3. Security tests — CSP present, no inline handlers
4. Baseline screenshot — captured last

Test quality rules:
- Each test function must have a comment referencing which
  requirement it validates
- Data accuracy tests must read from JSON dynamically —
  no hardcoded expected values
- Security tests must parse actual HTML — not screenshot based
- Tests must pass on the current dashboard on first run

Simplicity rules:
- Single test file only — no helper classes
- Plain pytest functions — no class-based tests
- No mocking — test against actual generated files
- No changes to config.py, process_rollout.py,
  or build_rollout_dashboard.py
```

**Wait for constitution.md to be created before Prompt 2.**

---

## PROMPT 2 — Specify
### Attach 02-brd.md file first, then paste this

> How to attach: Click paperclip icon in Copilot Chat → select 02-brd.md

```
/speckit.specify

I have attached the BRD as a file. Read it fully.

Feature name for this spec: rollout-dashboard-e2e-tests

Extract spec.md following Spec Kit template rules:
- Convert all test requirements to FR-XXX format
- Convert all success criteria to SC-XXX format
- Do NOT include technology details in spec.md
  (Playwright, Python, JSON paths — these go to plan.md)
- Mark anything ambiguous with [NEEDS CLARIFICATION]
- Business language only in spec.md

Additional context:
- This dashboard is already built and running
- We are adding tests only — zero code changes
- Three data sections exist: BackEnd_Unit_Testing,
  Gen_Test_Case, Gen_Scripts_4_PostMan
- Manager has specifically asked for test documentation
  and code path in repo
```

**Wait for spec.md to be created. Answer any [NEEDS CLARIFICATION] questions before Prompt 3.**

---

## PROMPT 3 — Tasks
### Paste this after spec.md is complete

```
/speckit.tasks

Generate tasks for feature 001-rollout-dashboard-e2e-tests.

Requirements:
- Tests only — no implementation tasks
- Phase order must be:
  Phase 1: Setup (verify files exist, verify config entry)
  Phase 2: Structure tests (page load, title, sections)
  Phase 3: Data accuracy tests (HTML vs JSON matching)
  Phase 4: Security tests (CSP, no inline handlers)
  Phase 5: Baseline screenshot capture
  Phase 6: Documentation (code path, test scenarios for manager)

- Each task must specify:
  - Exact file path
  - Exact function name to create
  - Which FR-XXX or SC-XXX it satisfies

- Mark parallel-safe tasks with [P]

Existing structure to follow:
- config.py already has rollout entry — just verify it
- tests/ folder already exists — add file there
- Package/Rollout/ paths are fixed — reference them exactly
```

**Wait for tasks.md to be created. Confirm phase order is correct before Prompt 4.**

---

## PROMPT 4 — Implement
### Paste this after tasks.md is confirmed correct

```
/speckit.implement

Execute all tasks in tasks.md for feature 
001-rollout-dashboard-e2e-tests.

Critical rules — read before writing any code:
- Read constitution.md first
- Single test file: tests/test_rollout_dashboard.py
- Each test function must have this comment format:
  # Validates: FR-001 — page loads without errors

- Data accuracy tests:
  Read Package/Rollout/rllot_data.json directly
  Compare JSON values to what appears in HTML
  Do NOT hardcode any expected values

- Security tests:
  Parse HTML file content directly using Python
  Check for: CSP meta tag, inline event handlers,
  inline script blocks
  Use string parsing or BeautifulSoup — not screenshots

- Do NOT modify these files:
  config.py
  process_rollout.py
  build_rollout_dashboard.py

- After writing tests — show me the complete test file
  so I can review before you mark tasks complete

- Mark each task complete in tasks.md as you finish it
```

**Review the generated test file before running.**

---

## PROMPT 5 — Checklist (for manager)
### Paste this after tests pass

```
/speckit.checklist

Generate a review checklist for feature 
001-rollout-dashboard-e2e-tests.

Include these sections:
1. Test coverage — list each test with FR-XXX it covers
2. Security validation — what security tests check
3. Data accuracy — how tests verify HTML matches JSON source
4. Code path — exact file location in repo
5. How to run — exact pytest command
6. Screenshot baseline — where it is saved and what it proves

This document is for manager sign-off.
Format it so a non-technical manager can understand it.
```

**Output is your manager sign-off document.**

---

## Run Tests Command

```bash
pytest tests/test_rollout_dashboard.py -v
```

---

## Quick Reference

| Prompt | Command | Output |
|---|---|---|
| 1 | `/speckit.constitution` | `.specify/memory/constitution.md` |
| 2 | `/speckit.specify` | `specs/001-rollout.../spec.md` |
| 3 | `/speckit.tasks` | `specs/001-rollout.../tasks.md` |
| 4 | `/speckit.implement` | `tests/test_rollout_dashboard.py` |
| 5 | `/speckit.checklist` | `checklists/rollout.md` |

