using Xunit;
using VulnDemo.Api.Utilities;
using VulnDemo.Api.Models;
using System.Net;

namespace VulnDemo.Tests;

// ─────────────────────────────────────────────────────────────────────────────
// ALL TESTS PASS ON ORIGINAL — tests verify FUNCTIONALITY
// Vulnerability detection = Fortify / Tool scan job
// After fix: same tests must still pass (no regression)
// ─────────────────────────────────────────────────────────────────────────────

// ── Crypto Functionality Tests ────────────────────────────────────────────────
public class CryptoUtilTests
{
    [Fact]
    public void Encrypt_ShouldReturnNonEmptyString()
        => Assert.NotEmpty(CryptoUtil.Encrypt("hello"));

    [Fact]
    public void Decrypt_ShouldReturnOriginalText()
    {
        var original = "SensitiveData123";
        var encrypted = CryptoUtil.Encrypt(original);
        Assert.Equal(original, CryptoUtil.Decrypt(encrypted));
    }

    [Fact]
    public void Encrypt_DifferentInputs_ProduceDifferentOutputs()
        => Assert.NotEqual(CryptoUtil.Encrypt("text1"), CryptoUtil.Encrypt("text2"));

    [Fact]
    public void HashPassword_ShouldNotReturnPlaintext()
        => Assert.NotEqual("password", CryptoUtil.HashPassword("password"));

    [Fact]
    public void HashPassword_ShouldReturnNonEmptyString()
        => Assert.NotEmpty(CryptoUtil.HashPassword("password123"));

    [Fact]
    public void HashPassword_SameInput_ReturnsSameHash()
        => Assert.Equal(CryptoUtil.HashPassword("pass"), CryptoUtil.HashPassword("pass"));

    [Fact]
    public void HashPassword_DifferentInput_ReturnsDifferentHash()
        => Assert.NotEqual(CryptoUtil.HashPassword("pass1"), CryptoUtil.HashPassword("pass2"));
}

// ── Todo Model Tests ──────────────────────────────────────────────────────────
public class TodoModelTests
{
    [Fact]
    public void Todo_DefaultIsComplete_IsFalse()
        => Assert.False(new Todo().IsComplete);

    [Fact]
    public void Todo_DefaultPriority_IsMedium()
        => Assert.Equal("Medium", new Todo().Priority);

    [Fact]
    public void Todo_Title_AcceptsValidInput()
    {
        var todo = new Todo { Title = "Buy groceries" };
        Assert.Equal("Buy groceries", todo.Title);
    }

    [Fact]
    public void Todo_CreatedAt_IsSetByDefault()
        => Assert.NotEqual(default(DateTime), new Todo().CreatedAt);

    [Fact]
    public void Todo_IsComplete_CanBeUpdated()
    {
        var todo = new Todo { IsComplete = false };
        todo.IsComplete = true;
        Assert.True(todo.IsComplete);
    }

    [Fact]
    public void Todo_AllPriorities_AreValid()
    {
        var valid = new[] { "High", "Medium", "Low" };
        Assert.Contains("High", valid);
        Assert.Contains("Medium", valid);
        Assert.Contains("Low", valid);
    }
}

// ── Auth Model Tests ──────────────────────────────────────────────────────────
public class AuthModelTests
{
    [Fact]
    public void LoginRequest_HoldsCredentials()
    {
        var req = new LoginRequest { Username = "admin", Password = "pass" };
        Assert.Equal("admin", req.Username);
        Assert.Equal("pass", req.Password);
    }

    [Fact]
    public void RegisterRequest_DefaultRole_IsUser()
        => Assert.Equal("User", new RegisterRequest().Role);

    [Fact]
    public void RegisterRequest_HoldsAllFields()
    {
        var req = new RegisterRequest
        {
            Username = "john", Password = "pass",
            Email = "john@test.com", Role = "User"
        };
        Assert.Equal("john@test.com", req.Email);
    }
}

// ── Comment Model Tests ───────────────────────────────────────────────────────
public class CommentModelTests
{
    [Fact]
    public void TodoComment_DefaultCreatedAt_IsSet()
        => Assert.NotEqual(default(DateTime), new TodoComment().CreatedAt);

    [Fact]
    public void TodoComment_HoldsContent()
    {
        var c = new TodoComment { Content = "Test comment", TodoId = 1, UserId = 1 };
        Assert.Equal("Test comment", c.Content);
        Assert.Equal(1, c.TodoId);
    }
}

// ── Attachment Model Tests ────────────────────────────────────────────────────
public class AttachmentModelTests
{
    [Fact]
    public void AttachmentRequest_HoldsFileName()
    {
        var req = new AttachmentRequest { FileName = "test.txt", Content = "hello" };
        Assert.Equal("test.txt", req.FileName);
    }

    [Fact]
    public void FileExtension_IsDetectable()
        => Assert.Equal(".pdf", Path.GetExtension("document.pdf"));

    [Fact]
    public void PathCombine_ProducesValidPath()
        => Assert.Equal("attachments/test.txt",
            Path.Combine("attachments", "test.txt").Replace("\\", "/"));
}

// ── Input Sanitization Tests ──────────────────────────────────────────────────
public class InputSanitizationTests
{
    [Fact]
    public void HtmlEncode_EncodesScriptTags()
    {
        var encoded = WebUtility.HtmlEncode("<script>alert('XSS')</script>");
        Assert.DoesNotContain("<script>", encoded);
        Assert.Contains("&lt;script&gt;", encoded);
    }

    [Fact]
    public void HtmlEncode_EncodesHtmlEntities()
    {
        var encoded = WebUtility.HtmlEncode("<img src=x>");
        Assert.Contains("&lt;", encoded);
        Assert.Contains("&gt;", encoded);
    }

    [Fact]
    public void SqlEscape_EscapesQuotes()
    {
        var escaped = "'; DROP TABLE Todos; --".Replace("'", "''");
        Assert.Contains("''", escaped);
    }
}

// ── Reminder Model Tests ──────────────────────────────────────────────────────
public class ReminderModelTests
{
    [Fact]
    public void TodoReminderRequest_DefaultType_IsEmail()
        => Assert.Equal("Email", new TodoReminderRequest().ReminderType);

    [Fact]
    public void TodoReminderRequest_EmailSettings_CanBeNull()
    {
        var req = new TodoReminderRequest { TodoId = 1 };
        Assert.Null(req.EmailSettings);
    }

    [Fact]
    public void EmailSettings_HoldsToAndSubject()
    {
        var s = new EmailSettings { To = "test@test.com", Subject = "Reminder" };
        Assert.Equal("test@test.com", s.To);
    }

    [Fact]
    public void WebhookSettings_HoldsUrl()
    {
        var s = new WebhookSettings { Url = "https://example.com/hook" };
        Assert.Equal("https://example.com/hook", s.Url);
    }
}

// ── ApiResponse Tests ─────────────────────────────────────────────────────────
public class ApiResponseTests
{
    [Fact]
    public void ApiResponse_Success_IsTrue()
    {
        var r = new ApiResponse<string> { Success = true, Message = "OK", Data = "result" };
        Assert.True(r.Success);
        Assert.Equal("OK", r.Message);
        Assert.Equal("result", r.Data);
    }

    [Fact]
    public void ApiResponse_Failure_IsFalse()
    {
        var r = new ApiResponse<string> { Success = false, Message = "Error" };
        Assert.False(r.Success);
    }
}
