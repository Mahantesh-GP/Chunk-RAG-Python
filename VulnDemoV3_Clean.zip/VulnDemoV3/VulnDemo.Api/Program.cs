using Microsoft.Data.Sqlite;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// V-033: Security Misconfiguration - Swagger enabled in all environments (no env check)
builder.Services.AddSwaggerGen();

// V-008: Security Misconfiguration - CORS allows any origin
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", p =>
        p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
});

// Initialize SQLite DB
using (var conn = new SqliteConnection("Data Source=vulndemo.db"))
{
    conn.Open();
    var cmd = conn.CreateCommand();
    cmd.CommandText = @"
        CREATE TABLE IF NOT EXISTS Todos (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Title TEXT NOT NULL,
            Description TEXT,
            IsComplete INTEGER DEFAULT 0,
            Priority TEXT DEFAULT 'Medium',
            Category TEXT,
            CreatedAt TEXT,
            CreatedBy TEXT,
            AttachmentPath TEXT
        );
        CREATE TABLE IF NOT EXISTS Users (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Username TEXT NOT NULL UNIQUE,
            Password TEXT NOT NULL,
            Email TEXT,
            Role TEXT DEFAULT 'User',
            IsActive INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS Comments (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            TodoId INTEGER NOT NULL,
            UserId INTEGER NOT NULL,
            Content TEXT NOT NULL,
            CreatedAt TEXT
        );
        CREATE TABLE IF NOT EXISTS AuditLog (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Action TEXT,
            UserId TEXT,
            Timestamp TEXT,
            Details TEXT
        );
        INSERT OR IGNORE INTO Users (Id, Username, Password, Email, Role)
        VALUES (1, 'admin', 'admin123', 'admin@company.com', 'Admin');
        INSERT OR IGNORE INTO Users (Id, Username, Password, Email, Role)
        VALUES (2, 'john', 'password1', 'john@company.com', 'User');
        INSERT OR IGNORE INTO Todos (Id, Title, Description, Priority, Category, CreatedAt, CreatedBy)
        VALUES (1, 'Buy groceries', 'Milk, eggs, bread', 'Medium', 'Personal', datetime('now'), 'john');
        INSERT OR IGNORE INTO Todos (Id, Title, Description, Priority, Category, CreatedAt, CreatedBy)
        VALUES (2, 'Pay bills', 'Electricity and water', 'High', 'Finance', datetime('now'), 'admin');
    ";
    cmd.ExecuteNonQuery();
}

var app = builder.Build();

// V-033: Swagger in all environments (no environment check)
app.UseSwagger();
app.UseSwaggerUI();

app.UseStaticFiles();
app.UseCors("AllowAll");
app.UseAuthorization();
app.MapControllers();
app.MapFallbackToFile("index.html");
app.Run();
