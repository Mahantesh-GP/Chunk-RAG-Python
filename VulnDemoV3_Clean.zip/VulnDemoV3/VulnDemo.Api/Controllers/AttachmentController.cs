using Microsoft.AspNetCore.Mvc;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AttachmentController : ControllerBase
{
    // ── V-014: Path Traversal ─────────────────────────────────────
    // Natural fit: Download todo attachment by filename
    [HttpGet("download")]
    public IActionResult Download([FromQuery] string fileName)
    {
        // VULNERABLE: No path sanitization
        // Try: ../../appsettings.json or ../../Program.cs
        var filePath = Path.Combine("attachments", fileName);
        if (!System.IO.File.Exists(filePath))
            return NotFound(new { message = "File not found", path = filePath }); // VULNERABLE: exposes path
        var content = System.IO.File.ReadAllText(filePath);
        return Ok(new { fileName, content });
    }

    // ── V-022: Header Manipulation ────────────────────────────────
    // Natural fit: File download sets Content-Disposition header
    [HttpGet("export")]
    public IActionResult ExportTodo([FromQuery] string fileName)
    {
        // VULNERABLE: User input injected directly into response header
        // Try: fileName = "todos.csv\r\nSet-Cookie: session=hijacked"
        Response.Headers.Append("Content-Disposition", "attachment; filename=" + fileName); // VULNERABLE
        Response.Headers.Append("X-Exported-File", fileName); // VULNERABLE: reflected in header
        return Ok(new { message = "Export ready", fileName });
    }

    // ── V-015: Unrestricted File Upload ───────────────────────────
    // Natural fit: Attach file to todo
    [HttpPost("upload")]
    public IActionResult Upload([FromBody] AttachmentRequest request)
    {
        // VULNERABLE: No file type validation - .exe, .sh, .bat all accepted
        // VULNERABLE: No file size limit
        // VULNERABLE: User controls file path
        var uploadDir = "attachments";
        Directory.CreateDirectory(uploadDir);
        var fullPath = Path.Combine(uploadDir, request.FileName); // VULNERABLE: no sanitization
        System.IO.File.WriteAllText(fullPath, request.Content);
        return Ok(new ApiResponse<string>
        {
            Success = true,
            Message = "Attachment uploaded",
            Data = fullPath // VULNERABLE: internal path exposed
        });
    }

    // ── V-016: Stack Trace in Error Response ──────────────────────
    // Natural fit: View attachment - error reveals internal details
    [HttpGet("view/{fileName}")]
    public IActionResult View(string fileName)
    {
        try
        {
            var path = Path.Combine("attachments", fileName);
            var bytes = System.IO.File.ReadAllBytes(path);
            return File(bytes, "application/octet-stream", fileName);
        }
        catch (Exception ex)
        {
            // VULNERABLE: Full stack trace returned to client
            return StatusCode(500, new
            {
                error = ex.Message,
                stackTrace = ex.StackTrace,          // VULNERABLE
                innerException = ex.InnerException?.Message,
                path = Path.Combine("attachments", fileName) // VULNERABLE: exposes server path
            });
        }
    }
}
