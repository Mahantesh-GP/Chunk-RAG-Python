using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;
using VulnDemo.Api.Utilities;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly string _db = "Data Source=vulndemo.db";

    // ── V-003 + V-001b: Hardcoded creds + SQL Injection in login ──
    // Natural fit: Login page
    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: SQL injection - try: admin' OR '1'='1' --
        cmd.CommandText = $"SELECT * FROM Users WHERE Username='{request.Username}' AND Password='{request.Password}'";
        using var reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            var userId = reader.GetInt32(0);
            var role = reader.IsDBNull(4) ? "User" : reader.GetString(4);
            // VULNERABLE: Hardcoded static token - no JWT, no expiry
            return Ok(new { token = $"TOKEN_{userId}_{role}", userId, role });
        }
        return Unauthorized(new { message = "Invalid credentials" });
    }

    // ── V-012: Plaintext password storage ─────────────────────────
    // Natural fit: User registration
    [HttpPost("register")]
    public IActionResult Register([FromBody] RegisterRequest request)
    {
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: Password stored as plaintext - no hashing
        // VULNERABLE: User controls their own role
        cmd.CommandText = "INSERT INTO Users (Username, Password, Email, Role) VALUES (@u, @p, @e, @r)";
        cmd.Parameters.AddWithValue("@u", request.Username);
        cmd.Parameters.AddWithValue("@p", request.Password); // VULNERABLE: no hashing
        cmd.Parameters.AddWithValue("@e", request.Email);
        cmd.Parameters.AddWithValue("@r", request.Role);     // VULNERABLE: user sets role
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Registered" });
    }

    // ── V-013: User enumeration in password reset ─────────────────
    // Natural fit: Forgot password feature
    [HttpPost("forgot-password")]
    public IActionResult ForgotPassword([FromBody] string email)
    {
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id FROM Users WHERE Email = @e";
        cmd.Parameters.AddWithValue("@e", email);
        var result = cmd.ExecuteScalar();
        if (result != null)
        {
            // VULNERABLE: Host header used to build reset URL
            // V-023: Host Header Injection - natural fit: reset link generation
            var host = Request.Headers["Host"].ToString();
            var resetLink = $"http://{host}/reset?email={email}&token=abc123";
            return Ok(new { message = $"Reset link sent to {email}", resetLink }); // VULNERABLE: confirms email exists
        }
        return Ok(new { message = "Email not found in system" }); // VULNERABLE: different message = enumeration
    }

    // ── V-004: Weak 3DES encryption ───────────────────────────────
    // Natural fit: Encrypt sensitive todo data before export
    [HttpGet("encrypt")]
    public IActionResult EncryptData([FromQuery] string data)
    {
        var encrypted = CryptoUtil.Encrypt(data);
        return Ok(new { encrypted, algorithm = "3DES", note = "Used for todo export encryption" });
    }

    // ── V-019: MD5 password hashing ───────────────────────────────
    // Natural fit: Password change feature
    [HttpPost("change-password")]
    public IActionResult ChangePassword([FromQuery] string username, [FromQuery] string newPassword)
    {
        // VULNERABLE: MD5 used for hashing - easily reversible
        var hashedPassword = CryptoUtil.HashPassword(newPassword);
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE Users SET Password = @p WHERE Username = @u";
        cmd.Parameters.AddWithValue("@p", hashedPassword);
        cmd.Parameters.AddWithValue("@u", username);
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Password updated", hashAlgorithm = "MD5" });
    }
}
