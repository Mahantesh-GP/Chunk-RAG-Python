using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CommentController : ControllerBase
{
    private readonly string _db = "Data Source=vulndemo.db";

    // ── V-002b: Stored XSS in comments ────────────────────────────
    // Natural fit: Todo comments rendered in browser
    [HttpGet("todo/{todoId}")]
    public IActionResult GetComments(int todoId)
    {
        var comments = new List<object>();
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM Comments WHERE TodoId = @id";
        cmd.Parameters.AddWithValue("@id", todoId);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            comments.Add(new
            {
                Id = reader.GetInt32(0),
                Content = reader.GetString(3), // VULNERABLE: stored XSS - content returned raw
                CreatedAt = reader.IsDBNull(4) ? "" : reader.GetString(4)
            });
        // VULNERABLE: Returns raw HTML content - stored XSS possible
        return Ok(new ApiResponse<List<object>> { Success = true, Data = comments });
    }

    // ── V-027: Insecure Design - No rate limiting ─────────────────
    // Natural fit: Comment submission - no rate limiting allows spam
    [HttpPost]
    public IActionResult AddComment([FromBody] TodoComment comment)
    {
        // VULNERABLE: No rate limiting - attacker can flood with comments
        // VULNERABLE: No content length validation
        // VULNERABLE: XSS content stored as-is
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "INSERT INTO Comments (TodoId, UserId, Content, CreatedAt) VALUES (@tid, @uid, @c, @at)";
        cmd.Parameters.AddWithValue("@tid", comment.TodoId);
        cmd.Parameters.AddWithValue("@uid", comment.UserId);
        cmd.Parameters.AddWithValue("@c", comment.Content); // VULNERABLE: no sanitization
        cmd.Parameters.AddWithValue("@at", DateTime.UtcNow.ToString("o"));
        cmd.ExecuteNonQuery();
        return Ok(new ApiResponse<string> { Success = true, Message = "Comment added" });
    }

    // ── V-034: Missing CSRF protection ────────────────────────────
    // Natural fit: Delete comment - state change without CSRF token
    [HttpDelete("{id}")]
    public IActionResult DeleteComment(int id)
    {
        // VULNERABLE: No CSRF token validation
        // VULNERABLE: No ownership check (IDOR)
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM Comments WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
        return Ok(new ApiResponse<string> { Success = true, Message = "Comment deleted" });
    }
}
