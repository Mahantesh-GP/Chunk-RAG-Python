using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TodoController : ControllerBase
{
    private readonly string _db = "Data Source=vulndemo.db";

    // ── V-001: SQL Injection in Search ────────────────────────────
    // Natural fit: Todo search feature
    [HttpGet("search")]
    public IActionResult Search([FromQuery] string keyword, [FromQuery] string category = "")
    {
        var results = new List<Todo>();
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: string concatenation - try: ' OR '1'='1
        cmd.CommandText = $"SELECT * FROM Todos WHERE Title LIKE '%{keyword}%' AND Category LIKE '%{category}%'";
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) results.Add(MapTodo(reader));
        return Ok(new ApiResponse<List<Todo>> { Success = true, Data = results });
    }

    // ── V-002: XSS in Todo description display ────────────────────
    // Natural fit: Todo description rendered as HTML
    [HttpGet("{id}/preview")]
    public IActionResult Preview(int id)
    {
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM Todos WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return NotFound();
        var title = reader.GetString(1);
        var desc = reader.IsDBNull(2) ? "" : reader.GetString(2);
        // VULNERABLE: raw HTML output - try description: <script>alert('XSS')</script>
        return Content($"<html><body><h1>{title}</h1><p>{desc}</p></body></html>", "text/html");
    }

    // ── V-009: IDOR - No ownership check ──────────────────────────
    // Natural fit: Any user can view/delete any todo by guessing ID
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: No check that requesting user owns this todo
        cmd.CommandText = "SELECT * FROM Todos WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        using var reader = cmd.ExecuteReader();
        if (reader.Read())
            return Ok(new ApiResponse<Todo> { Success = true, Data = MapTodo(reader) });
        return NotFound();
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var results = new List<Todo>();
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM Todos";
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) results.Add(MapTodo(reader));
        return Ok(new ApiResponse<List<Todo>> { Success = true, Data = results });
    }

    // ── V-010: No input validation ────────────────────────────────
    // Natural fit: Create todo accepts any input without validation
    [HttpPost]
    public IActionResult Create([FromBody] Todo todo)
    {
        // VULNERABLE: No max length, no type validation, no sanitization
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"INSERT INTO Todos 
            (Title, Description, IsComplete, Priority, Category, CreatedAt, CreatedBy)
            VALUES (@t, @d, @c, @p, @cat, @at, @by)";
        cmd.Parameters.AddWithValue("@t", todo.Title);
        cmd.Parameters.AddWithValue("@d", todo.Description ?? "");
        cmd.Parameters.AddWithValue("@c", todo.IsComplete ? 1 : 0);
        cmd.Parameters.AddWithValue("@p", todo.Priority);
        cmd.Parameters.AddWithValue("@cat", todo.Category ?? "");
        cmd.Parameters.AddWithValue("@at", DateTime.UtcNow.ToString("o"));
        cmd.Parameters.AddWithValue("@by", todo.CreatedBy ?? "anonymous");
        cmd.ExecuteNonQuery();
        return Ok(new ApiResponse<string> { Success = true, Message = "Todo created" });
    }

    // ── V-009b: IDOR on delete ────────────────────────────────────
    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: No ownership check - any user can delete any todo
        cmd.CommandText = "DELETE FROM Todos WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
        return Ok(new ApiResponse<string> { Success = true, Message = "Deleted" });
    }

    private static Todo MapTodo(SqliteDataReader r) => new()
    {
        Id = r.GetInt32(0),
        Title = r.IsDBNull(1) ? "" : r.GetString(1),
        Description = r.IsDBNull(2) ? "" : r.GetString(2),
        IsComplete = r.GetInt32(3) == 1,
        Priority = r.IsDBNull(4) ? "Medium" : r.GetString(4),
        Category = r.IsDBNull(5) ? "" : r.GetString(5),
        CreatedAt = r.IsDBNull(6) ? DateTime.UtcNow : DateTime.Parse(r.GetString(6)),
        CreatedBy = r.IsDBNull(7) ? "" : r.GetString(7)
    };
}
