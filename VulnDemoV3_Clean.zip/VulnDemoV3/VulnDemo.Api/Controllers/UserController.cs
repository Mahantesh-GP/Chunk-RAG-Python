using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using System.Xml;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly string _db = "Data Source=vulndemo.db";

    // ── V-029: Mass Assignment - Sensitive Field Exposure ─────────
    // Natural fit: Update user profile in Todo app
    [HttpPut("profile")]
    public IActionResult UpdateProfile([FromBody] UserProfileDto profile)
    {
        // VULNERABLE: Full object accepted - user can set IsAdmin=true, Role=Admin
        // No [BindNever] or [JsonIgnore] on sensitive fields
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE Users SET Username=@u, Email=@e, Role=@r WHERE Id=@id";
        cmd.Parameters.AddWithValue("@u", profile.Username);
        cmd.Parameters.AddWithValue("@e", profile.Email);
        cmd.Parameters.AddWithValue("@r", profile.Role); // VULNERABLE: user sets own role
        cmd.Parameters.AddWithValue("@id", profile.Id);
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Profile updated", role = profile.Role });
    }

    // ── V-031: Broken Access Control - Client-side role check ─────
    // Natural fit: Admin-only user management in Todo app
    [HttpDelete("{userId}")]
    public IActionResult DeleteUser(int userId, [FromHeader] string role)
    {
        // VULNERABLE: Role comes from request header - attacker sets role: Admin
        if (role != "Admin")
            return Forbid();
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM Users WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", userId);
        cmd.ExecuteNonQuery();
        return Ok(new { message = $"User {userId} deleted" });
    }

    // ── V-013b: Exposes all users with passwords ──────────────────
    // Natural fit: Admin user list feature
    [HttpGet("list")]
    public IActionResult ListUsers()
    {
        var users = new List<object>();
        using var conn = new SqliteConnection(_db);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: Returns password field to any caller
        cmd.CommandText = "SELECT Id, Username, Password, Email, Role FROM Users";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            users.Add(new
            {
                Id = reader.GetInt32(0),
                Username = reader.GetString(1),
                Password = reader.GetString(2), // VULNERABLE: plaintext passwords exposed
                Email = reader.IsDBNull(3) ? "" : reader.GetString(3),
                Role = reader.IsDBNull(4) ? "User" : reader.GetString(4)
            });
        return Ok(users);
    }

    // ── V-021: SSRF ───────────────────────────────────────────────
    // Natural fit: User sets notification webhook URL for todo reminders
    [HttpPost("notify-webhook")]
    public async Task<IActionResult> NotifyWebhook([FromBody] UserProfileDto profile)
    {
        if (string.IsNullOrEmpty(profile.NotificationWebhook))
            return BadRequest(new { message = "No webhook URL set" });

        // VULNERABLE: User-controlled URL used in outbound HTTP request
        // Attacker sets: http://169.254.169.254/metadata → Azure IMDS access
        // Or: http://localhost:5000/api/user/list → internal API access
        var client = new HttpClient(); // VULNERABLE: no timeout, allows redirects
        try
        {
            var response = await client.PostAsJsonAsync(
                profile.NotificationWebhook, // VULNERABLE: no URL whitelist
                new { message = "Todo reminder", userId = profile.Id }
            );
            return Ok(new { status = response.StatusCode, webhookUrl = profile.NotificationWebhook });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = ex.Message });
        }
    }

    // ── V-032: Security Misconfiguration - Debug endpoint ─────────
    // Natural fit: Developer left debug endpoint in production
    [HttpGet("debug")]
    public IActionResult Debug()
    {
        // VULNERABLE: Exposes server internals, connection strings, env vars
        return Ok(new
        {
            connectionString = _db,
            machineName = Environment.MachineName,
            osVersion = Environment.OSVersion.ToString(),
            dotnetVersion = Environment.Version.ToString(),
            workingDirectory = Environment.CurrentDirectory,
            environmentVariables = Environment.GetEnvironmentVariables()
        });
    }

    // ── V-026: XPath Injection ────────────────────────────────────
    // Natural fit: Todo app stores user preferences in XML config
    [HttpGet("preferences")]
    public IActionResult GetPreferences([FromQuery] string username)
    {
        var xml = @"<?xml version='1.0'?>
            <users>
                <user><name>admin</name><role>Admin</role><theme>dark</theme><apiKey>secret-admin-key</apiKey></user>
                <user><name>john</name><role>User</role><theme>light</theme><apiKey>secret-john-key</apiKey></user>
            </users>";

        var doc = new XmlDocument();
        doc.LoadXml(xml);
        // VULNERABLE: XPath injection - try: ' or '1'='1
        var query = $"//user[name='{username}']"; // VULNERABLE
        var nodes = doc.SelectNodes(query);
        var results = new List<object>();
        if (nodes != null)
            foreach (XmlNode node in nodes)
                results.Add(new
                {
                    name = node["name"]?.InnerText,
                    theme = node["theme"]?.InnerText,
                    apiKey = node["apiKey"]?.InnerText // VULNERABLE: API key exposed via XPath injection
                });
        return Ok(new { query, results });
    }

    // ── V-030: Optional submodel with required property ───────────
    // Natural fit: Set reminder for a todo
    [HttpPost("set-reminder")]
    public IActionResult SetReminder([FromBody] TodoReminderRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // VULNERABLE: EmailSettings is nullable but required when ReminderType = Email
        // No null check — silently skips email sending
        if (request.ReminderType == "Email")
        {
            var to = request.EmailSettings?.To; // VULNERABLE: may be null - silent skip
            if (to != null)
                return Ok(new { message = $"Email reminder set for todo {request.TodoId}", to });
            // VULNERABLE: returns success even without sending
            return Ok(new { message = "Reminder processed", warning = "Email settings were null - notification skipped" });
        }
        return Ok(new { message = "Reminder set" });
    }
}
