namespace VulnDemo.Api.Models;

// Core todo model
public class Todo
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool IsComplete { get; set; }
    public string Priority { get; set; } = "Medium";
    public string Category { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string CreatedBy { get; set; } = string.Empty;
    public string? AttachmentPath { get; set; }
}

// Auth models
public class LoginRequest
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public class RegisterRequest
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = "User"; // V-017: user controls own role
}

// V-029: Mass assignment - full model with sensitive fields exposed
public class UserProfileDto
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = "User";     // VULNERABLE: sensitive
    public bool IsAdmin { get; set; }               // VULNERABLE: sensitive
    public string? NotificationWebhook { get; set; }
}

// V-030: Optional submodel with required property
public class TodoReminderRequest
{
    public int TodoId { get; set; }
    public string ReminderType { get; set; } = "Email"; // Email or Webhook
    public EmailSettings? EmailSettings { get; set; }   // VULNERABLE: nullable but required for Email type
    public WebhookSettings? WebhookSettings { get; set; }
}

public class EmailSettings
{
    public string To { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
}

public class WebhookSettings
{
    public string Url { get; set; } = string.Empty;
    public string Secret { get; set; } = string.Empty;
}

// File attachment model
public class AttachmentRequest
{
    public string FileName { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
}

// Comment model
public class TodoComment
{
    public int Id { get; set; }
    public int TodoId { get; set; }
    public int UserId { get; set; }
    public string Content { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

// Generic response
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public T? Data { get; set; }
}
