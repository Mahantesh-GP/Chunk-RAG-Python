# VulnDemo V3 — Todo App with Natural Vulnerabilities

## Every vulnerability has a REAL reason to exist in a Todo app

## App Features & Their Vulnerabilities

| Feature | Controller | Vulnerabilities |
|---------|-----------|----------------|
| Search todos | TodoController | V-001 SQL Injection |
| Preview todo as HTML | TodoController | V-002 XSS |
| View any todo by ID | TodoController | V-009 IDOR |
| Create todo | TodoController | V-010 No input validation |
| Login | AuthController | V-001b SQL Injection, V-003 Hardcoded creds |
| Register | AuthController | V-012 Plaintext password, V-017 User sets own role |
| Forgot password | AuthController | V-013 User enumeration, V-023 Host header injection |
| Change password | AuthController | V-019 MD5 hashing |
| Export todo data | AuthController | V-004 Weak 3DES encryption |
| Download attachment | AttachmentController | V-014 Path traversal |
| Export file | AttachmentController | V-022 Header manipulation |
| Upload attachment | AttachmentController | V-015 Unrestricted upload |
| View attachment | AttachmentController | V-016 Stack trace exposure |
| Update profile | UserController | V-029 Mass assignment |
| Delete user | UserController | V-031 Broken access control |
| List users | UserController | V-013b Password exposure |
| Notification webhook | UserController | V-021 SSRF |
| Debug endpoint | UserController | V-032 Security misconfiguration |
| User preferences XML | UserController | V-026 XPath injection |
| Set todo reminder | UserController | V-030 Optional submodel |
| Add comment | CommentController | V-002b Stored XSS, V-027 No rate limiting |
| Delete comment | CommentController | V-034 No CSRF token |
| App config | Program.cs | V-008 CORS AllowAll, V-033 Swagger in prod |
| Dependencies | .csproj | V-007 Outdated Newtonsoft.Json 9.0.1 |

## Total: 24 vulnerabilities — ALL naturally fit the Todo app

## Build & Run
```
dotnet build VulnDemo.sln
cd VulnDemo.Api
dotnet run
```
Open: http://localhost:5000
Login: admin / admin123

## Tests
```
dotnet test VulnDemo.sln
```
Expected: ALL 30 tests PASS ✅ (on both original and fixed)
