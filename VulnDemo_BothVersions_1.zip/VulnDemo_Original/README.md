# VulnDemo_Original — WITH Vulnerabilities

## Purpose
Original version with 4 intentional vulnerabilities.
Used as INPUT to the vulnerability fix tool.

## Vulnerabilities

| ID | File | Type | Severity |
|----|------|------|----------|
| V-001 | TodoController.cs | SQL Injection | Critical |
| V-002 | TodoController.cs | XSS | High |
| V-003 | AuthController.cs | Hardcoded Credentials | Critical |
| V-004 | CryptoUtil.cs | Weak 3DES Encryption | High |

## Build & Test
```
dotnet build VulnDemo.sln
dotnet test VulnDemo.sln
```
Expected: 7 pass, 1 FAIL (HardcodedCredentials test)
