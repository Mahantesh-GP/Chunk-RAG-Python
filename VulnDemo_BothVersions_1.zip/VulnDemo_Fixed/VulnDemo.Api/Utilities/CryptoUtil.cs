using System.Security.Cryptography;
using System.Text;

namespace VulnDemo.Api.Utilities;

public static class CryptoUtil
{
    // FIXED V-004: Using AES with randomly generated key per operation
    // No hardcoded keys or IVs

    public static string Encrypt(string plainText)
    {
        // FIXED: Using AES (modern, strong encryption)
        using var aes = Aes.Create();
        aes.GenerateKey();
        aes.GenerateIV();

        var encryptor = aes.CreateEncryptor();
        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

        // Store IV + encrypted data together
        var result = new byte[aes.IV.Length + encryptedBytes.Length];
        Buffer.BlockCopy(aes.IV, 0, result, 0, aes.IV.Length);
        Buffer.BlockCopy(encryptedBytes, 0, result, aes.IV.Length, encryptedBytes.Length);

        return Convert.ToBase64String(result) + "|" + Convert.ToBase64String(aes.Key);
    }

    public static string Decrypt(string cipherText)
    {
        var parts = cipherText.Split('|');
        var data = Convert.FromBase64String(parts[0]);
        var key = Convert.FromBase64String(parts[1]);

        using var aes = Aes.Create();
        aes.Key = key;

        var iv = new byte[aes.BlockSize / 8];
        var encrypted = new byte[data.Length - iv.Length];
        Buffer.BlockCopy(data, 0, iv, 0, iv.Length);
        Buffer.BlockCopy(data, iv.Length, encrypted, 0, encrypted.Length);

        aes.IV = iv;
        var decryptor = aes.CreateDecryptor();
        var plainBytes = decryptor.TransformFinalBlock(encrypted, 0, encrypted.Length);
        return Encoding.UTF8.GetString(plainBytes);
    }
}
