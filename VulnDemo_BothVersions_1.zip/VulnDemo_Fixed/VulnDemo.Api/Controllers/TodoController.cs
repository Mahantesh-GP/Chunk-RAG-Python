using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using System.Net;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TodoController : ControllerBase
{
    private readonly string _connectionString = "Data Source=todos.db";

    // FIXED V-001: Parameterized query - no SQL Injection
    [HttpGet("search")]
    public IActionResult Search([FromQuery] string keyword)
    {
        var results = new List<Todo>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // FIXED: Using parameterized query
        cmd.CommandText = "SELECT * FROM Todos WHERE Title LIKE @keyword";
        cmd.Parameters.AddWithValue("@keyword", $"%{keyword}%");
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            results.Add(new Todo
            {
                Id = reader.GetInt32(0),
                Title = reader.GetString(1),
                IsComplete = reader.GetInt32(2) == 1
            });
        }
        return Ok(results);
    }

    // FIXED V-002: HTML encoded output - no XSS
    [HttpGet("echo")]
    public IActionResult Echo([FromQuery] string message)
    {
        // FIXED: Encoding user input before returning
        var encoded = WebUtility.HtmlEncode(message);
        return Content($"<html><body><h1>{encoded}</h1></body></html>", "text/html");
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var results = new List<Todo>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM Todos";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            results.Add(new Todo
            {
                Id = reader.GetInt32(0),
                Title = reader.GetString(1),
                IsComplete = reader.GetInt32(2) == 1
            });
        }
        return Ok(results);
    }

    [HttpPost]
    public IActionResult Create([FromBody] Todo todo)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "INSERT INTO Todos (Title, IsComplete) VALUES (@title, @complete)";
        cmd.Parameters.AddWithValue("@title", todo.Title);
        cmd.Parameters.AddWithValue("@complete", todo.IsComplete ? 1 : 0);
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Created successfully" });
    }
}
