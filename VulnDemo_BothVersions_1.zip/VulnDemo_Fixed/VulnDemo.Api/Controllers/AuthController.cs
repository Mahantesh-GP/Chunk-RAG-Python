using Microsoft.AspNetCore.Mvc;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IConfiguration _configuration;

    public AuthController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    // FIXED V-003: Credentials read from config, not hardcoded
    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        // FIXED: Reading from environment/config instead of hardcoded
        var validUsername = _configuration["Auth:Username"] 
                            ?? Environment.GetEnvironmentVariable("APP_USERNAME") 
                            ?? string.Empty;
        var validPassword = _configuration["Auth:Password"] 
                            ?? Environment.GetEnvironmentVariable("APP_PASSWORD") 
                            ?? string.Empty;

        if (string.IsNullOrEmpty(validPassword))
            return StatusCode(500, new { message = "Auth configuration missing" });

        if (request.Username == validUsername && request.Password == validPassword)
            return Ok(new { token = Guid.NewGuid().ToString(), message = "Login successful" });

        return Unauthorized(new { message = "Invalid credentials" });
    }
}
