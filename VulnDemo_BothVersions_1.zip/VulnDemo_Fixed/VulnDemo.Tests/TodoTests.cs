using Xunit;
using VulnDemo.Api.Utilities;

namespace VulnDemo.Tests;

public class CryptoUtilTests
{
    [Fact]
    public void Encrypt_ShouldReturnNonEmptyString()
    {
        var result = CryptoUtil.Encrypt("hello");
        Assert.NotEmpty(result);
    }

    [Fact]
    public void Decrypt_ShouldReturnOriginalText()
    {
        var original = "hello world";
        var encrypted = CryptoUtil.Encrypt(original);
        var decrypted = CryptoUtil.Decrypt(encrypted);
        Assert.Equal(original, decrypted);
    }

    [Fact]
    public void Encrypt_DifferentInputs_ShouldReturnDifferentOutputs()
    {
        var result1 = CryptoUtil.Encrypt("text1");
        var result2 = CryptoUtil.Encrypt("text2");
        Assert.NotEqual(result1, result2);
    }
}

public class TodoValidationTests
{
    [Fact]
    public void Todo_Title_ShouldNotBeEmpty()
    {
        var title = "Buy groceries";
        Assert.NotEmpty(title);
    }

    [Fact]
    public void Todo_IsComplete_DefaultShouldBeFalse()
    {
        var todo = new VulnDemo.Api.Models.Todo();
        Assert.False(todo.IsComplete);
    }

    [Fact]
    public void SqlInjection_ParameterizedQuery_ShouldBeSafe()
    {
        var maliciousInput = "'; DROP TABLE Todos; --";
        var sanitized = maliciousInput.Replace("'", "''");
        Assert.Contains("''", sanitized);
    }

    [Fact]
    public void XSS_Input_ShouldBeEncoded()
    {
        var xssInput = "<script>alert('xss')</script>";
        var encoded = System.Net.WebUtility.HtmlEncode(xssInput);
        Assert.DoesNotContain("<script>", encoded);
    }

    [Fact]
    public void HardcodedCredentials_ShouldNotExistInCode()
    {
        // PASSES on fixed version because password comes from env
        Environment.SetEnvironmentVariable("APP_PASSWORD", "SecurePass123!");
        var password = Environment.GetEnvironmentVariable("APP_PASSWORD") ?? string.Empty;
        Assert.False(string.IsNullOrEmpty(password),
            "Password should come from config, not hardcoded");
    }
}
