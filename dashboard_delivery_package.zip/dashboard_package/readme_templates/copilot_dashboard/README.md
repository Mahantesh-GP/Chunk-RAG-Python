# GitHub Copilot Adoption Dashboard

> Standardize and measure GitHub Copilot adoption across the organisation

---

## Purpose

Replaces manual Excel tracking by 35-40 managers.
Provides a consistent org-level view of Copilot adoption impact
at ADM, ER, and manager levels during production rollout.

---

## Team Responsibilities

| Role          | Responsible   |
|---------------|---------------|
| Builder       | [Developer 1] |
| Validator     | [Developer 2] |
| Deployer      | [Developer 1] |
| Maintainer    | EA Team       |

> Ownership is team-based — not individual dependent.

---

## Data Source

| Item          | Detail                                        |
|---------------|-----------------------------------------------|
| File          | copilot_data.xlsx                             |
| Updated by    | Each manager updates their own rows           |
| Consolidated by | EA Team                                     |

---

## Refresh Frequency

As updated by managers — team consolidates and regenerates.

---

## Code Path

| Item             | Path                                               |
|------------------|----------------------------------------------------|
| Generator script | Package/Copilot/generate_copilot_dashboard.py      |
| Excel data       | Package/Copilot/data/copilot_data.xlsx             |
| Output HTML      | Package/Copilot/output/copilot_dashboard.html      |
| Repository       | [Git repo URL or name]                             |

---

## Deployment

| Item                  | Detail                        |
|-----------------------|-------------------------------|
| Environment           | Internal Server               |
| Server path           | [server path here]            |
| Deployed by           | [Developer name or team]      |
| Deployment date       | [date of last deployment]     |
| Stakeholders notified | Yes — via Teams               |

---

## ADO Work Item

| Item        | Detail                    |
|-------------|---------------------------|
| Epic        | [Epic ID]                 |
| Feature     | [Feature ID]              |
| Area path   | [Azure DevOps area path]  |

---

## Team Communication

| Event               | How                          |
|---------------------|------------------------------|
| New deployment      | Teams — EA Dashboard channel |
| Bug fix deployed    | Teams — tag relevant members |
| Enhancement added   | Teams + ADO work item update |

---

## Validation Scenarios

| # | Scenario                  | Type      | How Validated           |
|---|---------------------------|-----------|-------------------------|
| 1 | Core logic — KPI correct  | Manual    | Developer review        |
| 2 | Key visuals render        | Manual    | Visual check in browser |
| 3 | Data correctness          | Manual    | Compare Excel vs HTML   |
| 4 | Security — CSP and XSS    | Manual    | Code review             |

---

## Maintenance

| Type               | Example                    | ADO Item Required |
|--------------------|----------------------------|-------------------|
| Bug fix            | Wrong adoption rate        | Yes               |
| Vulnerability fix  | Security patches           | Yes               |
| Enhancement        | New metric added           | Yes               |
| Data source change | New column in Excel        | Yes               |

---

## Change History

| Date       | Change             | Done by   | ADO Item |
|------------|--------------------|-----------|----------|
| Apr 2026   | Initial deployment | EA Team   | [ID]     |

---

*Last updated: April 2026 | Owner: EA Team*
