# [Dashboard Name]

> [One line description of what this dashboard shows]

---

## Purpose

[Describe what problem this dashboard solves and who benefits from it.]

---

## Team Responsibilities

| Role          | Responsible        |
|---------------|--------------------|
| Builder       | [Developer name]   |
| Validator     | [Developer name]   |
| Deployer      | [Developer name]   |
| Maintainer    | [Team name]        |

> Ownership is team-based — not individual dependent.

---

## Data Source

| Item          | Detail                          |
|---------------|---------------------------------|
| Type          | Excel / Database / API          |
| File / Table  | [file name or table name]       |
| Sheets        | [sheet names if Excel]          |
| Updated by    | [who updates the source data]   |

---

## Refresh Frequency

[Daily / Weekly / Monthly / On Demand]

---

## Code Path

| Item             | Path                                    |
|------------------|-----------------------------------------|
| Generator script | [path to Python script]                 |
| Data source      | [path to Excel or connection string]    |
| JSON output      | [path if flow has JSON step, else N/A]  |
| HTML output      | [path to generated HTML]                |
| Repository       | [Git repo URL or name]                  |

---

## Deployment

| Item                  | Detail                    |
|-----------------------|---------------------------|
| Environment           | [Internal Server / Azure] |
| Server path           | [path on server]          |
| Deployed by           | [Developer / Team]        |
| Deployment date       | [DD-MMM-YYYY]             |
| Stakeholders notified | Yes / No                  |

---

## ADO Work Item

| Item        | Detail                    |
|-------------|---------------------------|
| Epic        | [Epic ID]                 |
| Feature     | [Feature ID]              |
| Area path   | [Azure DevOps area path]  |

---

## Team Communication

| Event               | How                          |
|---------------------|------------------------------|
| New deployment      | [Teams / Email / Both]       |
| Bug fix deployed    | [Teams / Email / Both]       |
| Enhancement added   | [Teams + ADO work item]      |
| Data refresh done   | [Automated / Manual notify]  |

---

## Validation Scenarios

| # | Scenario                  | Type             | How Validated           |
|---|---------------------------|------------------|-------------------------|
| 1 | Core logic — KPI correct  | Manual/Automated | [describe how]          |
| 2 | Key visuals render        | Manual/Automated | [describe how]          |
| 3 | Data correctness          | Manual/Automated | [describe how]          |
| 4 | Security — CSP and XSS    | Manual/Automated | [describe how]          |

---

## Maintenance

| Type               | Example              | ADO Item Required |
|--------------------|----------------------|-------------------|
| Bug fix            | [example]            | Yes               |
| Vulnerability fix  | [example]            | Yes               |
| Enhancement        | [example]            | Yes               |
| Data source change | [example]            | Yes               |

---

## Change History

| Date | Change | Done by | ADO Item |
|------|--------|---------|----------|
|      |        |         |          |

---

*Last updated: [Date] | Owner: [Team]*
