# Audit Dashboard

> Process and Engineering Excellence Audit — Multi-Quarter View

---

## Purpose

Track and measure the outcome of the GitHub Copilot adoption initiative
across all projects at ADM, ER, and manager levels.

Provides PMO team with a consistent org-level view of audit scores,
non-conformances, opportunities, and quarterly trends.

---

## Team Responsibilities

| Role          | Responsible   |
|---------------|---------------|
| Builder       | [Developer 1] |
| Validator     | [Developer 2] |
| Deployer      | [Developer 1] |
| Maintainer    | EA Team       |

> Ownership is team-based — not individual dependent.

---

## Data Source

| Item          | Detail                                      |
|---------------|---------------------------------------------|
| File          | audit_data.xlsx                             |
| Sheets        | Projects, Ratings, Instructions             |
| Updated by    | Managers — update their own rows            |
| Consolidated by | EA Team                                   |

---

## Refresh Frequency

Daily — Python script reads updated Excel and generates HTML.

---

## Code Path

| Item              | Path                                              |
|-------------------|---------------------------------------------------|
| Generator script  | Package/Audit/generate_audit_dashboard.py         |
| Excel data        | Package/Audit/data/audit_data.xlsx                |
| Output HTML       | Package/Audit/output/audit_q1_2026.html           |
| Repository        | [Git repo URL or name]                            |

---

## Deployment

| Item                  | Detail                        |
|-----------------------|-------------------------------|
| Environment           | Internal Server               |
| Server path           | [server path here]            |
| Deployed by           | [Developer name or team]      |
| Deployment date       | [date of last deployment]     |
| Stakeholders notified | Yes — via Teams               |

---

## ADO Work Item

| Item        | Detail                          |
|-------------|---------------------------------|
| Epic        | [Epic ID — e.g. EPIC-123]       |
| Feature     | [Feature ID]                    |
| Area path   | [Azure DevOps area path]        |

---

## Team Communication

| Event               | How                          |
|---------------------|------------------------------|
| New deployment      | Teams — EA Dashboard channel |
| Bug fix deployed    | Teams — tag relevant members |
| Enhancement added   | Teams + ADO work item update |
| Data refresh done   | Automated — no notification  |

---

## Validation Scenarios

These are the critical scenarios validated before every deployment.

| # | Scenario                  | Type      | How Validated                          |
|---|---------------------------|-----------|----------------------------------------|
| 1 | Core logic — KPI correct  | Automated | excel_agent.py compares Excel vs HTML  |
| 2 | Key visuals render        | Automated | html_agent.py via Playwright           |
| 3 | Data correctness          | Automated | data_match_agent.py                    |
| 4 | Security — CSP and XSS    | Automated | security_agent.py                      |
| 5 | All project names in HTML | Automated | data_match_agent.py                    |

Run validation:
```bash
python validation_agent/orchestrator.py --dashboard audit
```

---

## Maintenance

All maintenance work follows the same lifecycle:
**Understand → Track → Build → Validate → Deploy**

| Type               | Example                              | ADO Item Required |
|--------------------|--------------------------------------|-------------------|
| Bug fix            | KPI calculation wrong                | Yes               |
| Vulnerability fix  | CSP header, XSS patch                | Yes               |
| Enhancement        | New chart, new filter                | Yes               |
| Data source change | New Excel column added               | Yes               |

---

## Change History

| Date       | Change                        | Done by       | ADO Item  |
|------------|-------------------------------|---------------|-----------|
| Apr 2026   | CSP and XSS vulnerability fix | [Developer]   | [ID]      |
| Apr 2026   | Initial deployment            | EA Team       | [ID]      |

---

*Last updated: April 2026 | Owner: EA Team*
