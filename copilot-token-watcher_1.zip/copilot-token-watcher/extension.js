const vscode = require('vscode');
const fs = require('fs');
const path = require('path');

let statusBarItem;
let lastReadPosition = 0;
let watcher;

// Running totals kept in memory (reset when VS Code restarts, except "month" which
// we persist to disk via extension globalState so it survives restarts).
let todayTokens = { input: 0, output: 0, calls: 0 };
let sessionTokens = { input: 0, output: 0, calls: 0 };
let monthTokens = { input: 0, output: 0, calls: 0 };
let todayDateStr = new Date().toDateString();
let currentMonthStr = new Date().toISOString().slice(0, 7); // "2026-07"

function activate(context) {
    statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    statusBarItem.command = 'copilotTokenWatcher.showSummary';
    context.subscriptions.push(statusBarItem);

    // Restore persisted month/day totals if VS Code was restarted today/this month
    const saved = context.globalState.get('copilotTokenWatcher.state');
    if (saved) {
        if (saved.todayDateStr === todayDateStr) {
            todayTokens = saved.todayTokens || todayTokens;
        }
        if (saved.currentMonthStr === currentMonthStr) {
            monthTokens = saved.monthTokens || monthTokens;
        }
    }

    startWatching(context);
    updateStatusBar();
    statusBarItem.show();

    context.subscriptions.push(
        vscode.commands.registerCommand('copilotTokenWatcher.resetToday', () => {
            todayTokens = { input: 0, output: 0, calls: 0 };
            persistState(context);
            updateStatusBar();
            vscode.window.showInformationMessage('Copilot Token Watcher: today\'s count reset.');
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('copilotTokenWatcher.showSummary', () => {
            const budget = vscode.workspace.getConfiguration('copilotTokenWatcher').get('monthlyCreditBudget');
            const pct = budget ? ((monthTokens.calls > 0 ? monthTokens.input + monthTokens.output : 0) / budget * 100).toFixed(1) : 'n/a';
            vscode.window.showInformationMessage(
                `Session: ${sessionTokens.calls} calls, ${(sessionTokens.input + sessionTokens.output).toLocaleString()} tokens | ` +
                `Today: ${todayTokens.calls} calls, ${(todayTokens.input + todayTokens.output).toLocaleString()} tokens | ` +
                `This month: ${(monthTokens.input + monthTokens.output).toLocaleString()} tokens (~${pct}% of budget)`
            );
        })
    );

    // React live if the user changes the file path setting without reloading VS Code
    context.subscriptions.push(
        vscode.workspace.onDidChangeConfiguration(e => {
            if (e.affectsConfiguration('copilotTokenWatcher.otelFilePath')) {
                startWatching(context);
            }
        })
    );
}

function getOtelFilePath() {
    let configured = vscode.workspace.getConfiguration('copilotTokenWatcher').get('otelFilePath');
    if (configured && configured.trim().length > 0) {
        return configured;
    }
    // Sensible default fallback if not configured explicitly
    return path.join(require('os').homedir(), 'copilot-otel.jsonl');
}

function startWatching(context) {
    if (watcher) {
        watcher.close();
    }

    const filePath = getOtelFilePath();

    if (!fs.existsSync(filePath)) {
        statusBarItem.text = `$(warning) Copilot tokens: file not found`;
        statusBarItem.tooltip = `Expected OTel file at: ${filePath}`;
        return;
    }

    // Start reading from the current end of file so we only pick up NEW entries
    lastReadPosition = fs.statSync(filePath).size;

    watcher = fs.watch(filePath, { persistent: false }, (eventType) => {
        if (eventType === 'change') {
            readNewLines(filePath, context);
        }
    });

    context.subscriptions.push({ dispose: () => watcher && watcher.close() });
}

function readNewLines(filePath, context) {
    const stats = fs.statSync(filePath);
    if (stats.size < lastReadPosition) {
        // File was truncated/rotated — restart from beginning
        lastReadPosition = 0;
    }
    if (stats.size === lastReadPosition) {
        return; // nothing new
    }

    const stream = fs.createReadStream(filePath, {
        start: lastReadPosition,
        end: stats.size,
        encoding: 'utf-8'
    });

    let buffer = '';
    stream.on('data', chunk => { buffer += chunk; });
    stream.on('end', () => {
        lastReadPosition = stats.size;
        const lines = buffer.split('\n').map(l => l.trim()).filter(Boolean);
        for (const line of lines) {
            processLine(line, context);
        }
    });
}

function processLine(line, context) {
    let event;
    try {
        event = JSON.parse(line);
    } catch {
        return; // skip malformed lines
    }

    const attrs = event.attributes || {};
    if (attrs['event.name'] !== 'gen_ai.client.inference.operation.details') {
        return; // not a token-usage event
    }

    const model = attrs['gen_ai.response.model'] || attrs['gen_ai.request.model'] || 'unknown';
    const inputTokens = attrs['gen_ai.usage.input_tokens'] || 0;
    const outputTokens = attrs['gen_ai.usage.output_tokens'] || 0;
    const total = inputTokens + outputTokens;

    // Roll the day/month counters over if the calendar day/month changed
    const nowDateStr = new Date().toDateString();
    const nowMonthStr = new Date().toISOString().slice(0, 7);
    if (nowDateStr !== todayDateStr) {
        todayDateStr = nowDateStr;
        todayTokens = { input: 0, output: 0, calls: 0 };
    }
    if (nowMonthStr !== currentMonthStr) {
        currentMonthStr = nowMonthStr;
        monthTokens = { input: 0, output: 0, calls: 0 };
    }

    sessionTokens.input += inputTokens;
    sessionTokens.output += outputTokens;
    sessionTokens.calls += 1;

    todayTokens.input += inputTokens;
    todayTokens.output += outputTokens;
    todayTokens.calls += 1;

    monthTokens.input += inputTokens;
    monthTokens.output += outputTokens;
    monthTokens.calls += 1;

    persistState(context);
    updateStatusBar();

    const showToast = vscode.workspace.getConfiguration('copilotTokenWatcher').get('showToastPerMessage');
    if (showToast) {
        vscode.window.setStatusBarMessage(
            `$(zap) ${model}: ${total.toLocaleString()} tokens (in ${inputTokens.toLocaleString()} / out ${outputTokens.toLocaleString()})`,
            6000
        );
    }
}

function persistState(context) {
    context.globalState.update('copilotTokenWatcher.state', {
        todayDateStr,
        currentMonthStr,
        todayTokens,
        monthTokens
    });
}

function updateStatusBar() {
    const budget = vscode.workspace.getConfiguration('copilotTokenWatcher').get('monthlyCreditBudget');
    const monthTotal = monthTokens.input + monthTokens.output;
    const pct = budget ? Math.round((monthTotal / budget) * 100) : null;

    statusBarItem.text = `$(zap) ${todayTokens.calls} calls today | ${monthTotal.toLocaleString()} tok/mo` + (pct !== null ? ` (${pct}%)` : '');
    statusBarItem.tooltip = new vscode.MarkdownString(
        `**Copilot Token Watcher**\n\n` +
        `- Session: ${sessionTokens.calls} calls, ${(sessionTokens.input + sessionTokens.output).toLocaleString()} tokens\n` +
        `- Today: ${todayTokens.calls} calls, ${(todayTokens.input + todayTokens.output).toLocaleString()} tokens\n` +
        `- This month: ${monthTokens.calls} calls, ${monthTotal.toLocaleString()} tokens` + (pct !== null ? ` (~${pct}% of ${budget} budget)` : '') +
        `\n\nClick for full summary.`
    );
}

function deactivate() {
    if (watcher) {
        watcher.close();
    }
}

module.exports = { activate, deactivate };
