# How I Implemented Playwright for Dashboard Validation
## A Real Story — Vibe Coding with GitHub Copilot

> This is not a polished success story.
> This is what actually happened — the struggles, the errors,
> the dead ends, and what I learned along the way.
> If you are starting from scratch, this will save you hours.

---

## Why I Even Started This

Our team was generating HTML dashboards daily from Excel files.
After every generation someone had to manually open the browser,
click through every tab, check every filter, verify every table.

45 minutes. Every day. Same checks. Different developer.
No record. No standard.

I knew this needed to be automated. But I had never written
a browser automation test in my life.

---

## Starting Point — What I Knew

```
✅ Python — comfortable
✅ HTML / CSS basics — comfortable
✅ Our dashboard structure — know it well
❌ Playwright — never used
❌ Browser automation — no experience
❌ Testing frameworks — no experience
```

This is important context. I was not a QA engineer.
I was a developer who needed to solve a practical problem.

---

## Step 1 — I Asked GitHub Copilot To Get Me Started

I did not read the Playwright documentation first.
I opened GitHub Copilot Chat and typed:

```
"Write a Python Playwright script that opens an HTML file
and checks if certain elements exist on the page"
```

Copilot generated this:

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    page.goto("file:///my/dashboard.html")
    assert page.locator(".kpi-box").count() > 0
    browser.close()
    print("Passed")
```

I looked at it. Made sense. Clean. Simple.
I ran it.

### First Error — ModuleNotFoundError

```
ModuleNotFoundError: No module named 'playwright'
```

Obviously. I had not installed it.

```bash
pip install playwright
```

Ran again.

### Second Error — Browser Not Found

```
Error: Executable doesn't exist at
/home/user/.cache/ms-playwright/chromium-1097/...
```

Copilot did not tell me I also needed to install the browser.
This is not in the code — it is a separate step.

I went to the official docs. Found this:

```bash
playwright install chromium
```

Ran again. This time it worked.

**First lesson: Copilot generates code. It does not always tell
you the environment setup. Always check the official docs
for installation steps.**

---

## Step 2 — Scaling Up, First Real Error

Feeling confident. I asked Copilot to add more checks:

```
"Add checks for all tabs, filters, and the detail drawer"
```

Copilot generated a large script. I ran it.

### Error — ElementNotFoundError on Filter

```
playwright._impl._errors.TimeoutError:
Timeout 30000ms exceeded.
waiting for locator('.f-sel[data-attr="dr"]')
```

The filter dropdown was not found.

I asked Copilot: "Why is this failing?"

Copilot said: "The element might not exist. Check your selector."

Not helpful. I opened the dashboard manually in Chrome,
right-clicked the DR filter, clicked Inspect.

The actual HTML was:

```html
<select class="f-sel" data-key="BackEnd_Unit_Testing" data-attr="dr">
```

Copilot had generated:

```python
page.locator('.f-sel[data-attr="dr"]')
```

But this matched selects across ALL tabs — including tabs
that were hidden. Playwright was finding the element but it
was in a hidden tab panel.

The fix was to scope it to the visible tab:

```python
page.locator(f'#tab-{key} .f-sel[data-attr="dr"]')
```

**Second lesson: Copilot generates generic selectors.
You have to know your specific HTML structure to make
them correct. Check the actual DOM in browser DevTools.**

---

## Step 3 — The Drawer Would Not Open

I asked Copilot to write code to click the detail button
and verify the drawer opened.

Copilot generated:

```python
page.locator(".detail-btn").first.click()
assert page.locator(".drawer-body").is_visible()
```

Ran it. Failed.

```
AssertionError: drawer-body is not visible
```

I added a print statement to see what was happening:

```python
page.locator(".detail-btn").first.click()
page.wait_for_timeout(2000)  # wait 2 seconds
print(page.locator(".drawer-body").is_visible())
```

Still False. The drawer was not opening at all.

I opened the dashboard manually and clicked the detail button.
Drawer opened fine. So the button worked — but Playwright
was not clicking it correctly.

I read the Playwright docs on actionability.
I found this:

> "Playwright checks that the element is visible, stable,
> enabled, and receives pointer events before clicking"

The detail button had `font-size: 0.69rem` and was very small.
Playwright was clicking but missing the actual clickable area.

I changed to:

```python
page.locator(".detail-btn").first.scroll_into_view_if_needed()
page.locator(".detail-btn").first.click()
page.wait_for_timeout(600)
```

Still not working. I checked the HTML more carefully.

The drawer was opened via JavaScript — `window.openDrawer(rid)`.
The button had `data-row-key` attribute with the row ID.

The JavaScript was listening for click events via addEventListener
wired in DOMContentLoaded — not inline onclick.

I added a longer wait after page load:

```python
page.goto(f"file:///{html_path}")
page.wait_for_load_state("domcontentloaded")
page.wait_for_timeout(800)  # give JS time to wire events
```

That fixed it. The drawer now opened correctly.

**Third lesson: Copilot does not know your JavaScript event
wiring. When interactions do not work — read your own HTML
and JavaScript carefully. Playwright docs on actionability
explained why clicks were failing.**

---

## Step 4 — Security Checks Generated Wrong CSP Logic

I asked Copilot to add security checks for CSP.

Copilot generated:

```python
csp = page.locator("meta[http-equiv='Content-Security-Policy']")
content = csp.get_attribute("content")
assert "unsafe-inline" not in content
```

Looked right. But when I ran it — it passed even though
I knew our dashboard had `style-src 'unsafe-inline'` in the CSP.

The check was wrong. It was checking the full CSP string
for unsafe-inline — but our CSP had:

```
style-src 'unsafe-inline'; script-src 'sha256-...'
```

`unsafe-inline` was in the style-src — which is acceptable.
The real concern is `unsafe-inline` in the script-src.

Copilot did not know this distinction. It just checked the
full string.

I updated the logic to specifically check the script-src part:

```python
if "script-src" in csp_val:
    script_src = csp_val.split("script-src")[1].split(";")[0]
    assert "unsafe-inline" not in script_src
```

This required me to actually understand CSP — not just
copy what Copilot generated.

**Fourth lesson: Security logic generated by Copilot may be
technically correct but logically wrong for your use case.
You must understand what you are checking and why.**

---

## Step 5 — The Timeline Tab Was Different

I asked Copilot to add checks for the timeline tab.

Copilot generated selectors based on the pattern it had seen
for the other tabs:

```python
page.locator(".tab-btn[data-tab='timeline']").click()
page.locator("#tab-timeline .f-sel[data-attr='dr']").click()
```

Failed. The timeline tab had completely different filter
selectors — it used `id="tl-f-dr"` instead of the class-based
selectors on the other tabs.

Copilot had assumed a pattern that did not exist.

I had to read the actual source code of
`build_rllot_dashboard.py` to understand the timeline
HTML structure and write the correct selectors myself.

```python
page.locator("#tl-f-dr").select_option(value="...")
page.locator("#tl-reset-btn").click()
```

**Fifth lesson: Copilot assumes patterns. Every dashboard
section can be different. There is no substitute for reading
your actual source code.**

---

## Step 6 — The Report Was Too Simple

Copilot generated a basic pass/fail print at the end.
I needed something more structured — section by section,
saved to a file, with a timestamp.

I designed the Report class myself:

```python
class Report:
    def __init__(self, dashboard_name):
        self.sections = {}

    def add_section(self, name):
        self.sections[name] = []

    def add_result(self, section, passed, message):
        self.sections[section].append((passed, message))

    def print_and_save(self):
        # format and save
```

I then asked Copilot to help me write the formatting
and file saving logic — which it did well.

**Sixth lesson: Use Copilot for implementation of things
you have designed. Design the structure yourself.**

---

## What Copilot Did Well

```
✅ Initial boilerplate — sync_playwright context structure
✅ Basic locator patterns — page.locator(), .click(), .fill()
✅ Error message formatting in the report
✅ Try/except wrapping for each check
✅ The requirements.txt and __init__.py files
✅ Suggesting wait_for_timeout in right places
✅ Writing repetitive sections — 3 sheets × 3 phases
```

---

## What Copilot Could NOT Do

```
❌ Know my specific HTML selectors — I had to find them
❌ Understand JavaScript event wiring in my dashboard
❌ Know the difference between tab-scoped and global selectors
❌ Design the folder structure — I decided that
❌ Decide what to test and what to skip — my manager guided
❌ Write correct CSP script-src logic for my specific case
❌ Know the timeline tab had different selectors
❌ Fix errors without me understanding the cause first
```

---

## The Real Workflow — Honest Version

```
1.  Ask Copilot for structure and boilerplate
          ↓
2.  Run it — it fails with an error
          ↓
3.  Try to fix it with Copilot — sometimes works
          ↓
4.  Go to official Playwright docs to understand WHY
          ↓
5.  Understand the concept — fix it myself
          ↓
6.  Inspect actual HTML in Chrome DevTools
          ↓
7.  Write the correct selector for MY dashboard
          ↓
8.  Run again — new error
          ↓
9.  Repeat from step 3
          ↓
10. Eventually it passes — and I understand what I built
```

Copilot accelerated the journey. It did not replace it.

---

## Errors I Hit — Full List

| # | Error | Cause | How I Fixed |
|---|---|---|---|
| 1 | ModuleNotFoundError: playwright | Not installed | pip install playwright |
| 2 | Browser executable not found | Browser not installed | playwright install chromium |
| 3 | TimeoutError on filter selector | Selector matched hidden elements | Scoped to visible tab panel |
| 4 | Drawer not opening | JS events not wired yet on page load | Added wait_for_timeout(800) after goto |
| 5 | CSP check passing incorrectly | Checked full CSP not script-src | Split on script-src and checked only that part |
| 6 | Timeline selectors not found | Timeline uses different HTML structure | Read source code, used tl-f-dr IDs |
| 7 | Screenshot blank | Page not fully rendered | Added wait_for_load_state("domcontentloaded") |
| 8 | Count always 0 for rows | Queried before JS filter applied | Added wait_for_timeout(400) after filter click |
| 9 | Collapsible not toggling | Clicking container not summary | Changed to .locator("summary").click() |
| 10 | Report not saving | Output directory not created | Added mkdir(exist_ok=True) |

---

## What I Learned About Vibe Coding

**Vibe coding works best when:**
- You understand the domain (dashboards, HTML, Python)
- You use it for structure and patterns
- You verify every generated line before trusting it
- You read error messages carefully before asking Copilot to fix

**Vibe coding fails when:**
- You accept generated code without running it
- You ask Copilot to fix errors without understanding them
- You trust generic patterns for specific problems
- You skip the official documentation

---

## Resources That Helped More Than Copilot

```
1. playwright.dev/docs/intro
   → Official getting started — read this first

2. playwright.dev/docs/actionability
   → Why clicks and interactions fail — critical reading

3. playwright.dev/docs/locators
   → How to find elements correctly

4. playwright.dev/docs/api/class-page
   → Full API reference — bookmark this

5. Chrome DevTools → Inspect
   → Finding your actual CSS selectors

6. Your own source code
   → build_rllot_dashboard.py — understanding the HTML you generate
```

---

## Advice For Anyone Starting From Scratch

```
Week 1 — Learn the basics
  pip install playwright
  playwright install chromium
  Read: playwright.dev/docs/intro
  Run the first example from the docs yourself

Week 1 — Use codegen
  playwright codegen your-html-file
  Click through your page
  Read the generated code
  Understand each line before copying

Week 2 — Write your first real check
  Pick ONE thing to validate
  Open your HTML in Chrome DevTools
  Find the actual CSS selector
  Write one report.add_result() check
  Run it — fix errors — understand each one

Week 2 — Expand slowly
  Add one section at a time
  Run after every addition
  Do not write 100 lines without running

Week 3 — Customise for your use case
  This is where Copilot helps least
  Your specific selectors, your specific logic
  Read your own source code carefully

Always — check official docs for errors you do not understand
  Copilot fixes symptoms
  Docs explain causes
```

---

## One Line Summary

> GitHub Copilot helped me start.
> Official docs helped me understand.
> My own brain solved the real problems.
> All three were necessary.

---

*Written by Mahantesh — EA Team — April 2026*
*Based on real implementation of GHCP Rollout Dashboard validation*
