# VulnDemo V2 — Enhanced Vulnerability Demo App

## Overview
Production-ready Todo Management app with **14 vulnerabilities** across all layers.
Built for testing the EA GenAI vulnerability auto-fix tool.

## Architecture
```
VulnDemo.Api/
├── Controllers/
│   ├── TodoController.cs      → V-001 SQL Injection, V-002 XSS, V-009 IDOR, V-010 No Validation
│   ├── AuthController.cs      → V-001b Login SQLi, V-003 Hardcoded Creds, V-012 Plaintext Password, V-013 User Enum
│   ├── FileController.cs      → V-014 Path Traversal, V-015 Unrestricted Upload, V-016 Stack Trace
│   └── UserNotesController.cs → V-009b IDOR Notes, V-017 Mass Assignment, V-013b Password Exposure
├── Utilities/
│   └── CryptoUtil.cs          → V-004 Weak 3DES, V-019 MD5 Hashing
├── wwwroot/
│   └── index.html             → V-020 Missing Security Headers, UI with all test buttons
└── Program.cs                 → V-007 Outdated Library, V-008 CORS AllowAll

VulnDemo.Tests/
└── VulnTests.cs               → 25 unit tests (most FAIL on original, PASS on fixed)
```

## Vulnerabilities (14 types across 6 categories)

| ID | Category | Vulnerability | File | Severity |
|----|----------|--------------|------|----------|
| V-001 | Injection | SQL Injection in Search | TodoController.cs | Critical |
| V-001b | Injection | SQL Injection in Login | AuthController.cs | Critical |
| V-002 | XSS | Unsanitized HTML Output | TodoController.cs | High |
| V-003 | Auth | Hardcoded Admin Credentials | AuthController.cs | Critical |
| V-004 | Crypto | Weak 3DES + Hardcoded Key | CryptoUtil.cs | Medium |
| V-007 | Library | Outdated Newtonsoft.Json 9.0.1 | .csproj | Medium |
| V-008 | Config | CORS allows all origins | Program.cs | Medium |
| V-009 | Access Control | IDOR - No ownership check | TodoController.cs | High |
| V-010 | Validation | No input validation | TodoController.cs | Medium |
| V-012 | Crypto | Plaintext password storage | AuthController.cs | High |
| V-013 | Info Disclosure | User enumeration | AuthController.cs | Low |
| V-014 | File | Path Traversal | FileController.cs | High |
| V-016 | Info Disclosure | Stack trace in error response | FileController.cs | Medium |
| V-017 | Access Control | Mass assignment (user sets own role) | UserNotesController.cs | High |
| V-019 | Crypto | MD5 password hashing | CryptoUtil.cs | High |
| V-020 | Config | Missing security headers | index.html | Medium |

## Quick Start

### Build
```
dotnet build VulnDemo.sln
```

### Run API + UI
```
cd VulnDemo.Api
dotnet run
```
Open: http://localhost:5000
Login: admin / admin123

### Run Tests
```
dotnet test VulnDemo.sln
```
Expected on Original: ~18 FAIL, ~7 PASS
Expected on Fixed: 25 PASS, 0 FAIL

## Test Scenarios for Tool

| Scenario | Description |
|----------|-------------|
| 1 | Full fix - all 16 vulnerabilities fixed, all 25 tests pass |
| 2 | Unit tests run before AND after fix |
| 3 | Build validation after each fix |
| 4 | Old library (Newtonsoft.Json 9.0.1) upgraded |
| 5 | UI security headers added |
