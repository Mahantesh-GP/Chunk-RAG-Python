using Microsoft.Data.Sqlite;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// VULNERABILITY V-008: No CORS policy - allows any origin
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader());
});

// Initialize SQLite DB
var dbPath = "vulndemo.db";
using (var conn = new SqliteConnection($"Data Source={dbPath}"))
{
    conn.Open();
    var cmd = conn.CreateCommand();
    cmd.CommandText = @"
        CREATE TABLE IF NOT EXISTS Todos (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Title TEXT NOT NULL,
            Description TEXT,
            IsComplete INTEGER NOT NULL DEFAULT 0,
            Priority TEXT DEFAULT 'Medium',
            Category TEXT,
            CreatedAt TEXT,
            CreatedBy TEXT
        );
        CREATE TABLE IF NOT EXISTS Users (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Username TEXT NOT NULL UNIQUE,
            Password TEXT NOT NULL,
            Email TEXT,
            Role TEXT DEFAULT 'User',
            IsActive INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS UserNotes (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            UserId INTEGER NOT NULL,
            Content TEXT NOT NULL,
            IsPrivate INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS AuditLog (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            Action TEXT,
            UserId TEXT,
            Timestamp TEXT,
            Details TEXT
        );
        INSERT OR IGNORE INTO Users (Id, Username, Password, Email, Role)
        VALUES (1, 'admin', 'admin123', 'admin@company.com', 'Admin');
        INSERT OR IGNORE INTO Users (Id, Username, Password, Email, Role)
        VALUES (2, 'john', 'password1', 'john@company.com', 'User');
    ";
    cmd.ExecuteNonQuery();
}

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseStaticFiles();
app.UseCors("AllowAll");
app.UseAuthorization();
app.MapControllers();
app.MapFallbackToFile("index.html");
app.Run();
