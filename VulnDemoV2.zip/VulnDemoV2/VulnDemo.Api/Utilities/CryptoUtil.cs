using System.Security.Cryptography;
using System.Text;

namespace VulnDemo.Api.Utilities;

public static class CryptoUtil
{
    // VULNERABILITY V-004: Hardcoded weak 3DES key and IV
    private static readonly byte[] m_KEY_192 = Encoding.UTF8.GetBytes("WeakKey1WeakKey2WeakKey3");
    private static readonly byte[] m_IV_192  = Encoding.UTF8.GetBytes("WeakIV12");

    public static string Encrypt(string plainText)
    {
        using var tripleDes = TripleDES.Create();
        tripleDes.Key = m_KEY_192;
        tripleDes.IV  = m_IV_192;
        var encryptor = tripleDes.CreateEncryptor();
        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string Decrypt(string cipherText)
    {
        using var tripleDes = TripleDES.Create();
        tripleDes.Key = m_KEY_192;
        tripleDes.IV  = m_IV_192;
        var decryptor = tripleDes.CreateDecryptor();
        var cipherBytes = Convert.FromBase64String(cipherText);
        var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
        return Encoding.UTF8.GetString(plainBytes);
    }

    // VULNERABILITY V-019: Weak MD5 hashing for passwords
    public static string HashPassword(string password)
    {
        // VULNERABLE: MD5 is cryptographically broken for passwords
        using var md5 = MD5.Create();
        var bytes = Encoding.UTF8.GetBytes(password);
        var hash = md5.ComputeHash(bytes);
        return Convert.ToHexString(hash);
    }
}
