using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;
using VulnDemo.Api.Utilities;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly string _connectionString = "Data Source=vulndemo.db";

    // VULNERABILITY V-003: Hardcoded credentials + SQL Injection in login
    private const string ADMIN_USERNAME = "admin";
    private const string ADMIN_PASSWORD = "admin123";

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        // VULNERABILITY V-001b: SQL Injection in login query
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: String concatenation in login - classic SQL injection
        cmd.CommandText = $"SELECT * FROM Users WHERE Username='{request.Username}' AND Password='{request.Password}'";
        using var reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            var userId = reader.GetInt32(0);
            var role = reader.IsDBNull(4) ? "User" : reader.GetString(4);
            // VULNERABILITY V-011: Hardcoded weak token - not JWT
            var token = $"TOKEN_{userId}_{role}_HARDCODED";
            return Ok(new { token, userId, role, message = "Login successful" });
        }
        // VULNERABILITY V-003b: Fallback hardcoded admin check
        if (request.Username == ADMIN_USERNAME && request.Password == ADMIN_PASSWORD)
            return Ok(new { token = "ADMIN_TOKEN_12345", userId = 1, role = "Admin" });

        return Unauthorized(new { message = "Invalid credentials" });
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] RegisterRequest request)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABILITY V-012: Password stored as plaintext
        cmd.CommandText = "INSERT INTO Users (Username, Password, Email, Role) VALUES (@u, @p, @e, @r)";
        cmd.Parameters.AddWithValue("@u", request.Username);
        cmd.Parameters.AddWithValue("@p", request.Password); // VULNERABLE: no hashing
        cmd.Parameters.AddWithValue("@e", request.Email);
        cmd.Parameters.AddWithValue("@r", request.Role); // VULNERABLE: user can set their own role!
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Registered successfully" });
    }

    // VULNERABILITY V-013: User enumeration - different messages for valid/invalid user
    [HttpPost("forgot-password")]
    public IActionResult ForgotPassword([FromBody] string email)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id FROM Users WHERE Email = @email";
        cmd.Parameters.AddWithValue("@email", email);
        var result = cmd.ExecuteScalar();
        if (result != null)
            return Ok(new { message = "Password reset email sent to " + email }); // VULNERABLE: confirms email exists
        return Ok(new { message = "Email not found in our system" }); // VULNERABLE: reveals non-existence
    }

    // VULNERABILITY V-004: Weak 3DES encryption for sensitive data
    [HttpGet("encrypt")]
    public IActionResult EncryptData([FromQuery] string data)
    {
        var encrypted = CryptoUtil.Encrypt(data);
        return Ok(new { encrypted, algorithm = "3DES" });
    }
}
