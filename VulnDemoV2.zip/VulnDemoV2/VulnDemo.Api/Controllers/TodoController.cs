using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TodoController : ControllerBase
{
    private readonly string _connectionString = "Data Source=vulndemo.db";

    // VULNERABILITY V-001: SQL Injection in search
    [HttpGet("search")]
    public IActionResult Search([FromQuery] string keyword, [FromQuery] string category = "")
    {
        var results = new List<Todo>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: Direct string concatenation
        cmd.CommandText = $"SELECT * FROM Todos WHERE Title LIKE '%{keyword}%' AND Category LIKE '%{category}%'";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            results.Add(MapTodo(reader));
        }
        return Ok(new ApiResponse<List<Todo>> { Success = true, Data = results });
    }

    // VULNERABILITY V-002: XSS - unsanitized output
    [HttpGet("echo")]
    public IActionResult Echo([FromQuery] string message)
    {
        // VULNERABLE: Raw user input in HTML
        return Content($"<html><body><h1>{message}</h1><p>You searched for: {message}</p></body></html>", "text/html");
    }

    // VULNERABILITY V-009: Insecure Direct Object Reference (IDOR)
    // No check if logged-in user owns the todo
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: No ownership check - any user can get any todo
        cmd.CommandText = "SELECT * FROM Todos WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        using var reader = cmd.ExecuteReader();
        if (reader.Read())
            return Ok(new ApiResponse<Todo> { Success = true, Data = MapTodo(reader) });
        return NotFound();
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var results = new List<Todo>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM Todos";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
            results.Add(MapTodo(reader));
        return Ok(new ApiResponse<List<Todo>> { Success = true, Data = results });
    }

    [HttpPost]
    public IActionResult Create([FromBody] Todo todo)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABILITY V-010: No input validation - any data accepted
        cmd.CommandText = @"INSERT INTO Todos (Title, Description, IsComplete, Priority, Category, CreatedAt, CreatedBy)
                           VALUES (@title, @desc, @complete, @priority, @category, @createdAt, @createdBy)";
        cmd.Parameters.AddWithValue("@title", todo.Title);
        cmd.Parameters.AddWithValue("@desc", todo.Description ?? "");
        cmd.Parameters.AddWithValue("@complete", todo.IsComplete ? 1 : 0);
        cmd.Parameters.AddWithValue("@priority", todo.Priority);
        cmd.Parameters.AddWithValue("@category", todo.Category ?? "");
        cmd.Parameters.AddWithValue("@createdAt", DateTime.UtcNow.ToString("o"));
        cmd.Parameters.AddWithValue("@createdBy", todo.CreatedBy ?? "anonymous");
        cmd.ExecuteNonQuery();
        return Ok(new ApiResponse<string> { Success = true, Message = "Todo created" });
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABILITY V-009: No ownership check on delete either
        cmd.CommandText = "DELETE FROM Todos WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
        return Ok(new ApiResponse<string> { Success = true, Message = "Deleted" });
    }

    private static Todo MapTodo(SqliteDataReader r) => new()
    {
        Id = r.GetInt32(0),
        Title = r.IsDBNull(1) ? "" : r.GetString(1),
        Description = r.IsDBNull(2) ? "" : r.GetString(2),
        IsComplete = r.GetInt32(3) == 1,
        Priority = r.IsDBNull(4) ? "Medium" : r.GetString(4),
        Category = r.IsDBNull(5) ? "" : r.GetString(5),
        CreatedAt = r.IsDBNull(6) ? DateTime.UtcNow : DateTime.Parse(r.GetString(6)),
        CreatedBy = r.IsDBNull(7) ? "" : r.GetString(7)
    };
}
