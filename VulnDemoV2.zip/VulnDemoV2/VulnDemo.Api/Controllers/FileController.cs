using Microsoft.AspNetCore.Mvc;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FileController : ControllerBase
{
    // VULNERABILITY V-014: Path Traversal - no path sanitization
    [HttpGet("read")]
    public IActionResult ReadFile([FromQuery] string fileName)
    {
        // VULNERABLE: Direct path concatenation allows ../../etc/passwd
        var filePath = Path.Combine("uploads", fileName);
        if (!System.IO.File.Exists(filePath))
            return NotFound(new { message = "File not found: " + filePath });
        var content = System.IO.File.ReadAllText(filePath);
        return Ok(new { fileName, content });
    }

    // VULNERABILITY V-015: Unrestricted file upload - no extension/size check
    [HttpPost("upload")]
    public IActionResult Upload([FromBody] FileUploadRequest request)
    {
        // VULNERABLE: No file type validation - accepts .exe, .sh etc.
        // VULNERABLE: No file size limit
        // VULNERABLE: User controls file path
        var uploadDir = "uploads";
        Directory.CreateDirectory(uploadDir);
        var fullPath = Path.Combine(uploadDir, request.FileName);
        System.IO.File.WriteAllText(fullPath, $"File uploaded: {request.FilePath}");
        return Ok(new { message = "File uploaded", path = fullPath });
    }

    // VULNERABILITY V-016: Sensitive data exposure in error response
    [HttpGet("download/{fileName}")]
    public IActionResult Download(string fileName)
    {
        try
        {
            var filePath = Path.Combine("uploads", fileName);
            var bytes = System.IO.File.ReadAllBytes(filePath);
            return File(bytes, "application/octet-stream", fileName);
        }
        catch (Exception ex)
        {
            // VULNERABLE: Full stack trace exposed to client
            return StatusCode(500, new
            {
                error = ex.Message,
                stackTrace = ex.StackTrace,    // VULNERABLE: exposes internal details
                innerException = ex.InnerException?.Message
            });
        }
    }
}
