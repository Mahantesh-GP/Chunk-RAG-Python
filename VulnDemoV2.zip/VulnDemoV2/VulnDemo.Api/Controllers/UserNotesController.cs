using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserNotesController : ControllerBase
{
    private readonly string _connectionString = "Data Source=vulndemo.db";

    // VULNERABILITY V-009b: IDOR - can read any user's private notes
    [HttpGet("user/{userId}")]
    public IActionResult GetUserNotes(int userId)
    {
        // VULNERABLE: No check that requesting user == userId
        // Any authenticated (or even unauthenticated) user can read anyone's notes
        var notes = new List<UserNote>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM UserNotes WHERE UserId = @userId";
        cmd.Parameters.AddWithValue("@userId", userId);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            notes.Add(new UserNote
            {
                Id = reader.GetInt32(0),
                UserId = reader.GetInt32(1),
                Content = reader.GetString(2),
                IsPrivate = reader.GetInt32(3) == 1
            });
        }
        return Ok(notes);
    }

    // VULNERABILITY V-017: Mass assignment - all fields blindly accepted
    [HttpPost]
    public IActionResult CreateNote([FromBody] UserNote note)
    {
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: UserId comes from request body - user sets their own userId!
        cmd.CommandText = "INSERT INTO UserNotes (UserId, Content, IsPrivate) VALUES (@uid, @content, @private)";
        cmd.Parameters.AddWithValue("@uid", note.UserId);
        cmd.Parameters.AddWithValue("@content", note.Content);
        cmd.Parameters.AddWithValue("@private", note.IsPrivate ? 1 : 0);
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Note created" });
    }

    // VULNERABILITY V-018: No rate limiting - brute force possible
    // VULNERABILITY V-013b: Returns all users including passwords
    [HttpGet("all-users")]
    public IActionResult GetAllUsers()
    {
        var users = new List<object>();
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        // VULNERABLE: Returns password field!
        cmd.CommandText = "SELECT Id, Username, Password, Email, Role FROM Users";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            users.Add(new
            {
                Id = reader.GetInt32(0),
                Username = reader.GetString(1),
                Password = reader.GetString(2), // VULNERABLE: exposing passwords
                Email = reader.IsDBNull(3) ? "" : reader.GetString(3),
                Role = reader.IsDBNull(4) ? "User" : reader.GetString(4)
            });
        }
        return Ok(users);
    }
}
