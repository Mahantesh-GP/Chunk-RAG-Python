using Xunit;
using VulnDemo.Api.Utilities;
using System.Net;

namespace VulnDemo.Tests;

// ALL TESTS PASS ON ORIGINAL — testing FUNCTIONALITY not vulnerabilities
// Vulnerability detection = Fortify/Tool scan job

public class CryptoUtilTests
{
    [Fact]
    public void Encrypt_ShouldReturnNonEmptyString()
    {
        var result = CryptoUtil.Encrypt("hello");
        Assert.NotEmpty(result);
    }

    [Fact]
    public void Decrypt_ShouldReturnOriginalText()
    {
        var original = "SensitiveData123";
        var encrypted = CryptoUtil.Encrypt(original);
        var decrypted = CryptoUtil.Decrypt(encrypted);
        Assert.Equal(original, decrypted);
    }

    [Fact]
    public void Encrypt_DifferentInputs_ProduceDifferentOutputs()
    {
        var r1 = CryptoUtil.Encrypt("text1");
        var r2 = CryptoUtil.Encrypt("text2");
        Assert.NotEqual(r1, r2);
    }

    [Fact]
    public void HashPassword_ShouldReturnNonEmptyString()
    {
        var hash = CryptoUtil.HashPassword("password123");
        Assert.NotEmpty(hash);
    }

    [Fact]
    public void HashPassword_ShouldNotReturnPlaintext()
    {
        var hash = CryptoUtil.HashPassword("MySecret123");
        Assert.NotEqual("MySecret123", hash);
    }

    [Fact]
    public void HashPassword_SameInput_ReturnsSameHash()
    {
        Assert.Equal(CryptoUtil.HashPassword("pass"), CryptoUtil.HashPassword("pass"));
    }

    [Fact]
    public void HashPassword_DifferentInput_ReturnsDifferentHash()
    {
        Assert.NotEqual(CryptoUtil.HashPassword("pass1"), CryptoUtil.HashPassword("pass2"));
    }
}

public class TodoModelTests
{
    [Fact]
    public void Todo_DefaultIsComplete_IsFalse()
    {
        Assert.False(new VulnDemo.Api.Models.Todo().IsComplete);
    }

    [Fact]
    public void Todo_DefaultPriority_IsMedium()
    {
        Assert.Equal("Medium", new VulnDemo.Api.Models.Todo().Priority);
    }

    [Fact]
    public void Todo_Title_AcceptsValidInput()
    {
        var todo = new VulnDemo.Api.Models.Todo { Title = "Buy groceries" };
        Assert.Equal("Buy groceries", todo.Title);
    }

    [Fact]
    public void LoginRequest_HoldsCredentials()
    {
        var req = new VulnDemo.Api.Models.LoginRequest { Username = "admin", Password = "pass" };
        Assert.Equal("admin", req.Username);
        Assert.Equal("pass", req.Password);
    }

    [Fact]
    public void RegisterRequest_DefaultRole_IsUser()
    {
        Assert.Equal("User", new VulnDemo.Api.Models.RegisterRequest().Role);
    }

    [Fact]
    public void UserNote_DefaultIsPrivate_IsFalse()
    {
        Assert.False(new VulnDemo.Api.Models.UserNote().IsPrivate);
    }

    [Fact]
    public void Todo_CreatedAt_IsSet()
    {
        Assert.NotEqual(default(DateTime), new VulnDemo.Api.Models.Todo().CreatedAt);
    }
}

public class InputSanitizationTests
{
    [Fact]
    public void HtmlEncode_EncodesScriptTags()
    {
        var encoded = WebUtility.HtmlEncode("<script>alert('XSS')</script>");
        Assert.DoesNotContain("<script>", encoded);
    }

    [Fact]
    public void HtmlEncode_EncodesHtmlEntities()
    {
        var encoded = WebUtility.HtmlEncode("<img src=x>");
        Assert.Contains("&lt;", encoded);
        Assert.Contains("&gt;", encoded);
    }

    [Fact]
    public void SqlEscape_EscapesQuotes()
    {
        var escaped = "'; DROP TABLE;".Replace("'", "''");
        Assert.Contains("''", escaped);
    }

    [Fact]
    public void PathCombine_ProducesValidPath()
    {
        var path = Path.Combine("uploads", "test.txt").Replace("\\", "/");
        Assert.Equal("uploads/test.txt", path);
    }

    [Fact]
    public void FileExtension_IsDetectable()
    {
        Assert.Equal(".pdf", Path.GetExtension("document.pdf"));
    }
}

public class BusinessLogicTests
{
    [Fact]
    public void Priority_High_IsValid()
    {
        Assert.Contains("High", new[] { "High", "Medium", "Low" });
    }

    [Fact]
    public void Todo_Complete_UpdatesStatus()
    {
        var todo = new VulnDemo.Api.Models.Todo { IsComplete = false };
        todo.IsComplete = true;
        Assert.True(todo.IsComplete);
    }

    [Fact]
    public void ApiResponse_Success_IsTrue()
    {
        var r = new VulnDemo.Api.Models.ApiResponse<string> { Success = true, Message = "OK" };
        Assert.True(r.Success);
        Assert.Equal("OK", r.Message);
    }
}
