# VulnDemo V2 — Enhanced Vulnerability Demo App

## Total Vulnerabilities: 28 across ALL layers

## New Vulnerabilities Added (from team instructions file)

| ID | Vulnerability | Controller | Category |
|----|--------------|-----------|----------|
| V-021 | SSRF - Server Side Request Forgery | NetworkController | Injection |
| V-022 | Header Manipulation | NetworkController | Header Security |
| V-023 | Host Header Injection | NetworkController | Header Security |
| V-024 | Missing timeout/redirect control | NetworkController | SSRF |
| V-025 | Insecure Mail Transmission (SMTP no TLS) | CommunicationController | Transport |
| V-026 | XPath Injection | CommunicationController | Injection |
| V-027 | Insecure Design - No rate limiting on OTP | CommunicationController | Design |
| V-028 | Insecure Design - No HTTPS enforcement | CommunicationController | Design |
| V-029 | Mass Assignment - Sensitive Field Exposure | AccountController | Access Control |
| V-030 | ASP.NET MVC - Optional Submodel Required Property | AccountController | Design |
| V-031 | Broken Access Control - Client-side role check | AccountController | Access Control |
| V-032 | Security Misconfiguration - Debug endpoint | AccountController | Config |
| V-033 | Security Misconfiguration - Swagger in production | Program.cs | Config |
| V-034 | Insecure Design - No CSRF token | AccountController | Design |

## Quick Start
```
dotnet build VulnDemo.sln
cd VulnDemo.Api
dotnet run
```
Open: http://localhost:5000

## Run Tests
```
dotnet test VulnDemo.sln
```
Expected: ALL 25 tests PASS on original ✅
