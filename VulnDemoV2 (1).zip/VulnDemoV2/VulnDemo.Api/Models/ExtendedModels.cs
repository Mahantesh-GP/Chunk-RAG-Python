namespace VulnDemo.Api.Models;

public class WebhookRequest
{
    public string CallbackUrl { get; set; } = string.Empty;
    public object? Payload { get; set; }
}

public class EmailRequest
{
    public string To { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
}

public class OtpRequest
{
    public string Otp { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
}

// VULNERABILITY V-029: Full domain model used for binding (no BindNever/JsonIgnore)
public class UserAccountDto
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = "User";         // VULNERABLE: user can set own role
    public bool IsAdmin { get; set; }                   // VULNERABLE: sensitive field exposed
    public decimal CreditLimit { get; set; }            // VULNERABLE: financial field exposed
    public string? ApiKey { get; set; }                 // VULNERABLE: secret field exposed
}

// VULNERABILITY V-030: Optional submodel with required property
public class OrderRequest
{
    public string ItemName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public PaymentDetails? PaymentDetails { get; set; } // VULNERABLE: nullable but required
}

public class PaymentDetails
{
    public string CardNumber { get; set; } = string.Empty;
    public string Cvv { get; set; } = string.Empty;
    public string ExpiryDate { get; set; } = string.Empty;
}

// VULNERABILITY V-034: No CSRF protection on funds transfer
public class FundsTransferRequest
{
    public string FromAccount { get; set; } = string.Empty;
    public string ToAccount { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    // VULNERABLE: No CSRF token field
    // VULNERABLE: No idempotency key
}
