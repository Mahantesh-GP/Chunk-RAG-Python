namespace VulnDemo.Api.Models;

// For Mass Assignment vulnerability
public class UserAccountDto
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;

    // VULNERABLE: Sensitive fields publicly settable
    public string Role { get; set; } = "User";           // privilege escalation risk
    public string AccessToken { get; set; } = string.Empty; // security token exposure
    public string ApiKey { get; set; } = string.Empty;      // API access compromise
}

// For ASP.NET MVC Bad Practice - Optional Submodel
public class OrderRequest
{
    public string ProductName { get; set; } = string.Empty;
    public int Quantity { get; set; }

    // VULNERABLE: Nullable complex type without [Required]
    public AddressInfo? ShippingAddress { get; set; } // nullable = bad practice
}

public class AddressInfo
{
    public string Street { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
}

// For Email
public class EmailRequest
{
    public string To { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
}

// For File Integrity
public class FileVerifyRequest
{
    public string Content { get; set; } = string.Empty;
    public string ExpectedHash { get; set; } = string.Empty;
}
