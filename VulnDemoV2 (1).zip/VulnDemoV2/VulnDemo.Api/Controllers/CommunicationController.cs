using Microsoft.AspNetCore.Mvc;
using System.Xml;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CommunicationController : ControllerBase
{
    // VULNERABILITY V-025: Insecure Transport - Mail Transmission
    // SMTP without TLS, hardcoded credentials
    [HttpPost("send-email")]
    public async Task<IActionResult> SendEmail([FromBody] EmailRequest request)
    {
        try
        {
            // VULNERABLE: Using insecure SMTP port 25 without encryption
            // VULNERABLE: Hardcoded SMTP credentials in source code
            var client = new System.Net.Mail.SmtpClient("smtp.company.com", 25) // VULNERABLE: port 25, no SSL
            {
                EnableSsl = false, // VULNERABLE: SSL disabled
                Credentials = new System.Net.NetworkCredential(
                    "noreply@company.com",
                    "SmtpPass123" // VULNERABLE: hardcoded password
                )
            };

            var mail = new System.Net.Mail.MailMessage
            {
                From = new System.Net.Mail.MailAddress("noreply@company.com"),
                Subject = request.Subject,
                Body = request.Body, // VULNERABLE: no sanitization - HTML injection possible
                IsBodyHtml = true
            };
            mail.To.Add(request.To);
            await client.SendMailAsync(mail);
            return Ok(new { message = "Email sent to " + request.To });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = ex.Message });
        }
    }

    // VULNERABILITY V-026: XPath Injection
    // User input directly concatenated into XPath query
    [HttpGet("search-config")]
    public IActionResult SearchConfig([FromQuery] string username)
    {
        try
        {
            // Sample XML config
            var xml = @"<?xml version='1.0'?>
                <users>
                    <user><name>admin</name><role>Admin</role><secret>supersecret</secret></user>
                    <user><name>john</name><role>User</role><secret>johnsecret</secret></user>
                </users>";

            var doc = new XmlDocument();
            doc.LoadXml(xml);

            // VULNERABLE: Direct string concatenation in XPath query
            // Attacker input: ' or '1'='1 → returns ALL users including secrets
            var query = $"//user[name='{username}']"; // VULNERABLE
            var nodes = doc.SelectNodes(query);

            var results = new List<object>();
            if (nodes != null)
            {
                foreach (XmlNode node in nodes)
                    results.Add(new { name = node["name"]?.InnerText, role = node["role"]?.InnerText });
            }
            return Ok(new { query, results });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = ex.Message, stackTrace = ex.StackTrace });
        }
    }

    // VULNERABILITY V-027: Insecure Design - No rate limiting on OTP/login
    // Brute force possible
    [HttpPost("verify-otp")]
    public IActionResult VerifyOtp([FromBody] OtpRequest request)
    {
        // VULNERABLE: No rate limiting - attacker can try all 1000 combinations (000-999)
        // VULNERABLE: OTP hardcoded for demo
        // VULNERABLE: No lockout after failed attempts
        var validOtp = "1234";
        if (request.Otp == validOtp)
            return Ok(new { message = "OTP verified", token = "ACCESS_GRANTED" });

        // VULNERABLE: Reveals that OTP was wrong (timing attack possible)
        return BadRequest(new { message = "Invalid OTP", attemptsRemaining = "unlimited" });
    }

    // VULNERABILITY V-028: Insecure Design - No HTTPS enforcement
    [HttpGet("sensitive-data")]
    public IActionResult GetSensitiveData()
    {
        // VULNERABLE: Sensitive data returned over potentially HTTP (not enforced HTTPS)
        // VULNERABLE: No HSTS header
        return Ok(new
        {
            creditCard = "4111-1111-1111-1111", // VULNERABLE: sensitive data
            ssn = "123-45-6789",                // VULNERABLE: PII in response
            apiKey = "sk-prod-abc123xyz"         // VULNERABLE: API key exposed
        });
    }
}
