using Microsoft.AspNetCore.Mvc;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class NetworkController : ControllerBase
{
    // VULNERABILITY V-021: SSRF - Server Side Request Forgery
    // User controls the URL used in outbound HTTP request
    [HttpGet("fetch")]
    public async Task<IActionResult> FetchExternalData([FromQuery] string url)
    {
        // VULNERABLE: Direct use of user input in HTTP request
        // Attacker can access: http://169.254.169.254/metadata (Azure IMDS)
        // Or internal services: http://localhost:5000/api/admin
        var client = new HttpClient(); // No timeout set - allows unlimited redirects
        try
        {
            var response = await client.GetAsync(url); // VULNERABLE: any URL allowed
            var content = await response.Content.ReadAsStringAsync();
            return Ok(new { url, content, statusCode = response.StatusCode });
        }
        catch (Exception ex)
        {
            // VULNERABLE: Detailed error messages leak internal info
            return StatusCode(500, new { error = ex.Message, url });
        }
    }

    // VULNERABILITY V-022: Header Manipulation
    // User input directly appended to response header without validation
    [HttpGet("download")]
    public IActionResult DownloadFile([FromQuery] string filename)
    {
        // VULNERABLE: Direct string concatenation into response header
        // Attacker can inject: filename = "file.txt\r\nSet-Cookie: session=hijacked"
        Response.Headers.Append("Content-Disposition", "attachment; filename=" + filename);
        Response.Headers.Append("X-User-Input", filename); // VULNERABLE: reflected header
        return Ok(new { message = "Download started", filename });
    }

    // VULNERABILITY V-023: Host Header Injection
    // Host header used without validation
    [HttpGet("reset-link")]
    public IActionResult GenerateResetLink([FromQuery] string email)
    {
        // VULNERABLE: Host header used directly to build reset URL
        // Attacker sets Host: evil.com → reset link points to evil.com
        var host = Request.Headers["Host"].ToString(); // VULNERABLE: not validated
        var resetLink = $"http://{host}/reset-password?email={email}&token=abc123";
        return Ok(new
        {
            message = "Reset link generated",
            resetLink, // VULNERABLE: attacker-controlled host in URL
            email
        });
    }

    // VULNERABILITY V-024: Missing timeout + redirect control (part of SSRF)
    [HttpPost("webhook")]
    public async Task<IActionResult> CallWebhook([FromBody] WebhookRequest request)
    {
        // VULNERABLE: No URL whitelist validation
        // VULNERABLE: AllowAutoRedirect not disabled
        var handler = new HttpClientHandler { AllowAutoRedirect = true }; // VULNERABLE
        var client = new HttpClient(handler);
        try
        {
            var response = await client.PostAsJsonAsync(request.CallbackUrl, request.Payload);
            return Ok(new { status = response.StatusCode });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = ex.Message });
        }
    }
}
