using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Mail;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-021: Insecure SMTP Mail Transmission
// Image 3: SMTP port 25, EnableSsl=false, hardcoded credentials
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class MailController : ControllerBase
{
    [HttpPost("send")]
    public async Task<IActionResult> SendEmail([FromBody] EmailRequest request)
    {
        // VULNERABLE: No TLS, hardcoded credentials, port 25
        var client = new SmtpClient("smtp.example.com", 25)
        {
            EnableSsl = false,                                          // VULNERABLE: No encryption
            Credentials = new NetworkCredential("admin", "password123") // VULNERABLE: Hardcoded
        };
        var message = new MailMessage("noreply@example.com", request.To,
            request.Subject, request.Body);
        await client.SendMailAsync(message);
        return Ok(new { message = "Email sent" });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-022: Server Side Request Forgery (SSRF)
// Image 4: User-controlled URL used in outbound HTTP request
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class ExternalController : ControllerBase
{
    [HttpGet("fetch")]
    public async Task<IActionResult> FetchExternalData([FromQuery] string url)
    {
        // VULNERABLE: User controls URL — can hit internal services
        // e.g. url=http://169.254.169.254/metadata (AWS metadata)
        // e.g. url=http://localhost:5000/admin/users
        var client = new HttpClient(); // VULNERABLE: No timeout, allows redirects
        try
        {
            var response = await client.GetStringAsync(url); // VULNERABLE: Direct user input
            return Ok(new { url, response });
        }
        catch (Exception ex)
        {
            // VULNERABLE: Exposes internal error details
            return StatusCode(500, new { error = ex.Message });
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-023: Host Header Injection
// Image 7: Host header used without validation
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class HostController : ControllerBase
{
    [HttpGet("reset-link")]
    public IActionResult GetPasswordResetLink([FromQuery] string email)
    {
        // VULNERABLE: Host header used directly without whitelist validation
        var host = Request.Headers["Host"].ToString(); // VULNERABLE
        var resetLink = $"http://{host}/reset?email={email}"; // VULNERABLE: attacker controls host
        return Ok(new { resetLink, message = "Reset link generated" });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-024: Security Logging Failures
// Image 9: No auth logging, sensitive data in logs
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class AuditController : ControllerBase
{
    [HttpPost("login-attempt")]
    public IActionResult LogLoginAttempt([FromBody] LoginRequest request)
    {
        // VULNERABLE: Password logged in plaintext
        Console.WriteLine($"Login attempt: user={request.Username} pass={request.Password}");
        // VULNERABLE: No structured logging for security events
        // VULNERABLE: No failed attempt tracking / rate limiting
        return Ok(new { message = "Logged" });
    }

    [HttpGet("logs")]
    public IActionResult GetLogs()
    {
        // VULNERABLE: Logs accessible without auth — exposes sensitive data
        var logs = new[]
        {
            "Login attempt: user=admin pass=admin123",
            "Login attempt: user=john pass=password1",
            "Failed login: user=hacker pass=tryingpassword"
        };
        return Ok(logs); // VULNERABLE: Exposes credentials from logs
    }
}
