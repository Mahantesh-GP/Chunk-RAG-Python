using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using System.Xml;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-025: Mass Assignment - Sensitive Field Exposure
// Image 6: Role, AccessToken, ApiKey publicly settable
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class ProfileController : ControllerBase
{
    private readonly string _connectionString = "Data Source=vulndemo.db";

    // VULNERABLE: Domain model used directly — user can set Role, AccessToken
    [HttpPut("update")]
    public IActionResult UpdateProfile([FromBody] UserAccountDto user)
    {
        // VULNERABLE: No check — user can overwrite Role = "Admin"
        // VULNERABLE: AccessToken, ApiKey can be overwritten via request body
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE Users SET Username=@u, Email=@e, Role=@r WHERE Id=@id";
        cmd.Parameters.AddWithValue("@u", user.Username);
        cmd.Parameters.AddWithValue("@e", user.Email);
        cmd.Parameters.AddWithValue("@r", user.Role);         // VULNERABLE: role from request!
        cmd.Parameters.AddWithValue("@id", user.Id);
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Profile updated" });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-026: ASP.NET MVC Bad Practice - Optional Submodel
// Image 2: Nullable complex type without [Required]
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    // VULNERABLE: AddressInfo is nullable complex type — can be null, no [Required]
    [HttpPost("create")]
    public IActionResult CreateOrder([FromBody] OrderRequest request)
    {
        // VULNERABLE: request.ShippingAddress can be null — NullReferenceException
        var city = request.ShippingAddress.City; // VULNERABLE: no null check
        return Ok(new { message = $"Order created for {city}" });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-027: XPath Injection
// Image 7: User input in XPath query
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class XmlController : ControllerBase
{
    [HttpGet("search")]
    public IActionResult SearchXml([FromQuery] string username)
    {
        var xml = @"<users>
            <user><name>admin</name><role>Admin</role></user>
            <user><name>john</name><role>User</role></user>
        </users>";

        var doc = new XmlDocument();
        doc.LoadXml(xml);

        // VULNERABLE: User input directly in XPath — XPath injection
        // Payload: ' or '1'='1  → returns all users
        var xpath = $"//user[name='{username}']"; // VULNERABLE
        var nodes = doc.SelectNodes(xpath);

        var results = new List<string>();
        if (nodes != null)
            foreach (XmlNode node in nodes)
                results.Add(node.InnerXml);

        return Ok(new { xpath, results });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-028: Software & Data Integrity Failures
// Image 8: Insecure deserialization, MD5 for integrity check
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class IntegrityController : ControllerBase
{
    [HttpPost("verify")]
    public IActionResult VerifyFile([FromBody] FileVerifyRequest request)
    {
        // VULNERABLE: MD5 used for integrity check — easily forged
        using var md5 = System.Security.Cryptography.MD5.Create();
        var data = System.Text.Encoding.UTF8.GetBytes(request.Content);
        var hash = Convert.ToHexString(md5.ComputeHash(data)); // VULNERABLE: MD5

        return Ok(new
        {
            hash,
            algorithm = "MD5", // VULNERABLE: should be SHA-256 minimum
            matches = hash.Equals(request.ExpectedHash, StringComparison.OrdinalIgnoreCase)
        });
    }

    // VULNERABLE: Downloads file over HTTP (not HTTPS) - no signature verification
    [HttpGet("download")]
    public async Task<IActionResult> DownloadPlugin([FromQuery] string pluginUrl)
    {
        // VULNERABLE: Downloads from HTTP — man-in-the-middle possible
        // VULNERABLE: No signature/hash verification before execution
        var client = new HttpClient();
        var content = await client.GetStringAsync(pluginUrl); // VULNERABLE
        return Ok(new { content, message = "Plugin downloaded (no verification!)" });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// VULNERABILITY V-029: Security Misconfiguration
// Image 10: Swagger in prod, debug mode, default credentials
// ─────────────────────────────────────────────────────────────────────────────
[ApiController]
[Route("api/[controller]")]
public class ConfigController : ControllerBase
{
    // VULNERABLE: Exposes all app configuration including secrets
    [HttpGet("info")]
    public IActionResult GetAppInfo()
    {
        // VULNERABLE: Exposes internal configuration to any caller
        return Ok(new
        {
            environment = "Production",
            debugMode = true,                          // VULNERABLE: debug in prod
            swaggerEnabled = true,                     // VULNERABLE: swagger in prod
            connectionString = "Data Source=vulndemo.db", // VULNERABLE: exposed
            adminEmail = "admin@company.com",
            version = "1.0.0",
            dotnetVersion = Environment.Version.ToString()
        });
    }
}
