using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AccountController : ControllerBase
{
    private readonly string _connectionString = "Data Source=vulndemo.db";

    // VULNERABILITY V-029: Mass Assignment - Sensitive Field Exposure
    // Domain model used directly for binding - exposes sensitive fields
    [HttpPost("update-profile")]
    public IActionResult UpdateProfile([FromBody] UserAccountDto account)
    {
        // VULNERABLE: Full domain model accepted from user input
        // User can set: IsAdmin=true, CreditLimit=999999, Role=SuperAdmin
        // No [BindNever] or [JsonIgnore] on sensitive fields
        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = @"UPDATE Users SET 
                           Username=@u, Email=@e, Role=@r
                           WHERE Id=@id";
        cmd.Parameters.AddWithValue("@u", account.Username);
        cmd.Parameters.AddWithValue("@e", account.Email);
        cmd.Parameters.AddWithValue("@r", account.Role); // VULNERABLE: user sets their own role
        cmd.Parameters.AddWithValue("@id", account.Id);
        cmd.ExecuteNonQuery();
        return Ok(new { message = "Profile updated", role = account.Role });
    }

    // VULNERABILITY V-030: ASP.NET MVC Bad Practice - Optional submodel with required property
    [HttpPost("process-order")]
    public IActionResult ProcessOrder([FromBody] OrderRequest request)
    {
        // VULNERABLE: PaymentDetails is nullable complex type
        // If null, payment processing is skipped silently
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // VULNERABLE: No null check on PaymentDetails before accessing
        var cardNumber = request.PaymentDetails?.CardNumber; // may be null - silent failure
        var amount = request.Amount;

        // VULNERABLE: Order processed even without payment validation
        return Ok(new
        {
            message = "Order processed",
            orderId = Guid.NewGuid(),
            amount,
            paymentStatus = cardNumber != null ? "Charged" : "SKIPPED" // VULNERABLE: order without payment!
        });
    }

    // VULNERABILITY V-031: Broken Access Control
    // No server-side role validation - client-side only
    [HttpDelete("delete-user/{userId}")]
    public IActionResult DeleteUser(int userId, [FromHeader] string role)
    {
        // VULNERABLE: Role check based on header sent by client
        // Attacker just sets header: role: Admin
        if (role != "Admin")
            return Forbid();

        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM Users WHERE Id = @id";
        cmd.Parameters.AddWithValue("@id", userId);
        cmd.ExecuteNonQuery();
        return Ok(new { message = $"User {userId} deleted" });
    }

    // VULNERABILITY V-032: Security Misconfiguration - Debug info in production
    [HttpGet("debug-info")]
    public IActionResult GetDebugInfo()
    {
        // VULNERABLE: Debug endpoint left in production
        // Exposes: connection strings, env variables, server info
        return Ok(new
        {
            connectionString = _connectionString,
            environment = Environment.GetEnvironmentVariables(),
            machineName = Environment.MachineName,
            osVersion = Environment.OSVersion.ToString(),
            dotnetVersion = Environment.Version.ToString(),
            workingDirectory = Environment.CurrentDirectory,
            // VULNERABLE: All environment variables exposed
            allEnvVars = Environment.GetEnvironmentVariables()
        });
    }

    // VULNERABILITY V-033: Security Misconfiguration - Swagger enabled in production
    // (Configured in Program.cs - no environment check)

    // VULNERABILITY V-034: Insecure Design - No anti-CSRF token on state-changing request
    [HttpPost("transfer-funds")]
    public IActionResult TransferFunds([FromBody] FundsTransferRequest request)
    {
        // VULNERABLE: No CSRF token validation
        // Attacker can forge request from another site
        // No origin validation
        return Ok(new
        {
            message = $"Transferred {request.Amount} to {request.ToAccount}",
            fromAccount = request.FromAccount,
            amount = request.Amount,
            // VULNERABLE: No idempotency key - duplicate requests possible
        });
    }
}
