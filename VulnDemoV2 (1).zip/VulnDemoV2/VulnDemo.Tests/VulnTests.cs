using Xunit;
using VulnDemo.Api.Utilities;
using System.Net;
using VulnDemo.Api.Models;

namespace VulnDemo.Tests;

// ALL TESTS PASS ON ORIGINAL — testing FUNCTIONALITY not vulnerabilities
// Vulnerability detection = Fortify/Tool scan job

public class CryptoUtilTests
{
    [Fact] public void Encrypt_ShouldReturnNonEmptyString() => Assert.NotEmpty(CryptoUtil.Encrypt("hello"));
    [Fact] public void Decrypt_ShouldReturnOriginalText() { var e = CryptoUtil.Encrypt("test"); Assert.Equal("test", CryptoUtil.Decrypt(e)); }
    [Fact] public void Encrypt_DifferentInputs_ProduceDifferentOutputs() => Assert.NotEqual(CryptoUtil.Encrypt("a"), CryptoUtil.Encrypt("b"));
    [Fact] public void HashPassword_ShouldReturnNonEmptyString() => Assert.NotEmpty(CryptoUtil.HashPassword("pass"));
    [Fact] public void HashPassword_ShouldNotReturnPlaintext() => Assert.NotEqual("pass", CryptoUtil.HashPassword("pass"));
    [Fact] public void HashPassword_SameInput_ReturnsSameHash() => Assert.Equal(CryptoUtil.HashPassword("x"), CryptoUtil.HashPassword("x"));
    [Fact] public void HashPassword_DifferentInput_ReturnsDifferentHash() => Assert.NotEqual(CryptoUtil.HashPassword("a"), CryptoUtil.HashPassword("b"));
}

public class TodoModelTests
{
    [Fact] public void Todo_DefaultIsComplete_IsFalse() => Assert.False(new Todo().IsComplete);
    [Fact] public void Todo_DefaultPriority_IsMedium() => Assert.Equal("Medium", new Todo().Priority);
    [Fact] public void Todo_Title_AcceptsValidInput() { var t = new Todo { Title = "Buy groceries" }; Assert.Equal("Buy groceries", t.Title); }
    [Fact] public void LoginRequest_HoldsCredentials() { var r = new LoginRequest { Username = "admin", Password = "pass" }; Assert.Equal("admin", r.Username); }
    [Fact] public void RegisterRequest_DefaultRole_IsUser() => Assert.Equal("User", new RegisterRequest().Role);
    [Fact] public void UserNote_DefaultIsPrivate_IsFalse() => Assert.False(new UserNote().IsPrivate);
    [Fact] public void Todo_CreatedAt_IsSet() => Assert.NotEqual(default(DateTime), new Todo().CreatedAt);
}

public class InputSanitizationTests
{
    [Fact] public void HtmlEncode_EncodesScriptTags() => Assert.DoesNotContain("<script>", WebUtility.HtmlEncode("<script>alert(1)</script>"));
    [Fact] public void HtmlEncode_EncodesHtmlEntities() { var e = WebUtility.HtmlEncode("<img>"); Assert.Contains("&lt;", e); }
    [Fact] public void SqlEscape_EscapesQuotes() => Assert.Contains("''", "'; DROP TABLE;".Replace("'", "''"));
    [Fact] public void PathCombine_ProducesValidPath() => Assert.Equal("uploads/test.txt", Path.Combine("uploads", "test.txt").Replace("\\", "/"));
    [Fact] public void FileExtension_IsDetectable() => Assert.Equal(".pdf", Path.GetExtension("document.pdf"));
}

public class BusinessLogicTests
{
    [Fact] public void Priority_High_IsValid() => Assert.Contains("High", new[] { "High", "Medium", "Low" });
    [Fact] public void Todo_Complete_UpdatesStatus() { var t = new Todo(); t.IsComplete = true; Assert.True(t.IsComplete); }
    [Fact] public void ApiResponse_Success_IsTrue() { var r = new ApiResponse<string> { Success = true }; Assert.True(r.Success); }
}

public class NewVulnerabilityModelTests
{
    [Fact] public void WebhookRequest_ShouldHoldCallbackUrl() { var r = new WebhookRequest { CallbackUrl = "https://example.com" }; Assert.Equal("https://example.com", r.CallbackUrl); }
    [Fact] public void EmailRequest_ShouldHoldEmailFields() { var r = new EmailRequest { To = "test@test.com", Subject = "Hi" }; Assert.Equal("Hi", r.Subject); }
    [Fact] public void OrderRequest_PaymentDetails_CanBeNull() { var r = new OrderRequest { Amount = 100 }; Assert.Null(r.PaymentDetails); }
    [Fact] public void UserAccountDto_DefaultRole_IsUser() => Assert.Equal("User", new UserAccountDto().Role);
    [Fact] public void FundsTransferRequest_ShouldHoldAmount() { var r = new FundsTransferRequest { Amount = 500 }; Assert.Equal(500, r.Amount); }
    [Fact] public void OtpRequest_ShouldHoldOtp() { var r = new OtpRequest { Otp = "1234" }; Assert.Equal("1234", r.Otp); }
}
