# Copilot Token Watcher

Live, per-message token usage tracking for GitHub Copilot Chat — shown in your VS Code status bar,
updated the moment a response completes. No manual export, no scripts to run daily.

## What it does
- Watches your `copilot-otel.jsonl` file (the one produced by GitHub Copilot Chat's built-in OTel export)
- The instant a new entry appears, it shows a temporary status bar message: model used + tokens (in/out)
- Keeps running totals for: current session, today, and this calendar month
- Click the status bar item any time for a full summary popup
- Warns you as you approach your monthly credit budget

## Requirements
1. GitHub Copilot Chat OTel export must already be enabled (you've already done this). Your `settings.json` should have:
   ```json
   {
     "github.copilot.chat.otel.enabled": true,
     "github.copilot.chat.otel.exporterType": "file",
     "github.copilot.chat.otel.outfile": "C:\\Users\\<you>\\copilot-otel.jsonl"
   }
   ```
2. Node.js is NOT required to just run the extension in VS Code — VS Code bundles its own Node runtime.

## How to test it locally (Extension Development Host)
1. Copy this whole `copilot-token-watcher` folder onto your Windows machine.
2. Open the folder in VS Code (`File > Open Folder`).
3. Press `F5` (or `Run > Start Debugging`). This launches a second VS Code window called the
   "Extension Development Host" — that's a real VS Code instance with your extension loaded.
4. In that new window, open Settings (`Ctrl+,`), search for "Copilot Token Watcher", and set
   `otelFilePath` to the exact path of your `copilot-otel.jsonl` file (same path you used in
   `github.copilot.chat.otel.outfile`).
5. Open Copilot Chat in that same Extension Development Host window and send a message.
6. Watch the bottom status bar — you should see a temporary message appear with the token count
   for that response, and the permanent counter update.

## Commands (Ctrl+Shift+P)
- `Copilot Token Watcher: Show Usage Summary` — popup with session/today/month totals
- `Copilot Token Watcher: Reset Today's Count` — clears just today's counter

## Packaging it as a real, installable extension (.vsix)
Once you're happy with local testing:
```
npm install -g @vscode/vsce
cd copilot-token-watcher
vsce package
```
This produces a `copilot-token-watcher-0.1.0.vsix` file. Anyone can install it via:
`Extensions view > ... menu > Install from VSIX...`

This is the exact same distribution mechanism you already use for your
`postman-collection-generator` and `vulnerability-fix` plugins in `fnf-corp/EA-marketplace` —
so publishing this org-wide follows a process your team already knows.

## About the credit estimate
GitHub Copilot bills usage in **AI Credits (AIC)**, where 1 credit = $0.01, calculated from
each model's real per-token rate (input and output are priced differently — output usually
costs far more per token than input). The OTel export only gives raw token counts, not the
credit cost directly, so this extension converts tokens → estimated credits itself using a
configurable rate table (`copilotTokenWatcher.modelRates` in settings).

**This is an estimate, not GitHub's official number.** It won't perfectly match your GitHub
billing dashboard because:
- Cached tokens are billed at a much lower rate than fresh input, and the OTel export doesn't
  always break out cache hits per event the same way GitHub's own billing does.
- Rates change over time — you should periodically check GitHub's published Copilot pricing
  and update the `modelRates` setting if numbers drift.
- Newer/less common models may not have an exact entry in the rate table and will fall back
  to the `"default"` rate, which may be inaccurate for that specific model.

Treat the percentage shown as a **directional early-warning signal** ("you're roughly halfway
through your budget"), not an exact invoice.

## Notes / limitations
- This reads the OTel file that Copilot itself writes — it does not intercept or modify any
  Copilot request/response, so it cannot break or slow down Copilot Chat in any way.
- If multiple VS Code windows write to the same file, all their events will be counted together
  (that's usually what you want for a personal total).
- The monthly/today counters persist across VS Code restarts (stored in extension state), so
  closing and reopening VS Code won't reset your running totals mid-month.
