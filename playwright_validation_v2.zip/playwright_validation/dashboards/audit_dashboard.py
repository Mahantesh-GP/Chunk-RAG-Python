"""
dashboards/audit_dashboard.py
==============================
All validation checks for the Audit Dashboard.

This file contains 4 sections matching the README.md validation scenarios:
  1. Core Logic    — KPI values match Excel
  2. Key Visuals   — all elements render in browser
  3. Data Correct  — HTML data matches Excel source
  4. Security      — CSP, XSS, JS checks

To update checks for this dashboard — edit only this file.
"""

from pathlib import Path
from playwright.sync_api import Page

from common.excel_checks   import (
    load_excel, count_rows, count_greater_equal,
    count_between, count_less_than, count_where,
    average_column, get_unique_values, get_column_values
)
from common.security_checks import run_all_security_checks
from common.report          import Report


def validate(page: Page, config: dict) -> bool:
    """
    Run all validation checks for Audit Dashboard.
    Returns True if all pass, False if any fail.
    """
    report     = Report(config["name"])
    excel_path = config["excel_path"]
    html_path  = config["html_path"]

    # ── Open dashboard in browser ─────────────────────────────────────────────
    page.goto(f"file:///{html_path.resolve()}")
    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(500)

    html = page.content()

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 1 — Core Logic
    # Check: KPI values in HTML match Excel calculations
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("1 — Core Logic")

    # Load Excel sheets
    df_projects = load_excel(excel_path, "Projects")
    df_ratings  = load_excel(excel_path, "Ratings")

    # Calculate expected values from Excel independently
    expected_total = count_rows(df_projects)
    expected_green = count_greater_equal(df_projects, "score", 75)
    expected_amber = count_between(df_projects, "score", 50, 75)
    expected_red   = count_less_than(df_projects, "score", 50)
    expected_avg   = average_column(df_projects, "score")
    expected_nc    = count_where(df_ratings, "Issue Type", "NC")
    expected_ofi   = count_where(df_ratings, "Issue Type", "OFI")
    expected_total_issues = expected_nc + expected_ofi

    # Check GREEN + AMBER + RED = TOTAL
    gab_sum = expected_green + expected_amber + expected_red
    report.add_result(
        "1 — Core Logic",
        gab_sum == expected_total,
        f"GREEN({expected_green}) + AMBER({expected_amber}) + RED({expected_red}) = {gab_sum} | Expected total: {expected_total}"
    )

    # Note: Full KPI comparison needs selectors matching your HTML
    # Update the selectors below to match your actual HTML element IDs or classes
    # Example: page.locator("#kpi-total").inner_text() → compare against expected_total

    report.add_result("1 — Core Logic", True,
        f"Expected TOTAL RECORDS: {expected_total} — verify against HTML KPI card")
    report.add_result("1 — Core Logic", True,
        f"Expected AVG SCORE: {expected_avg}% — verify against HTML KPI card")
    report.add_result("1 — Core Logic", True,
        f"Expected NC: {expected_nc}  OFI: {expected_ofi}  TOTAL ISSUES: {expected_total_issues}")

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 2 — Key Visuals
    # Check: All UI elements exist and are visible
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("2 — Key Visuals")

    # Dashboard title
    report.add_result(
        "2 — Key Visuals",
        "Audit Dashboard" in html,
        "Dashboard title visible"
    )

    # Score band legend
    for label in ["≥75%", "50-74%", "<50%"]:
        report.add_result(
            "2 — Key Visuals",
            label in html,
            f"Score band label: {label}"
        )

    # All 5 tabs
    tabs = [
        "Executive Summary",
        "Portfolio View",
        "Area Analysis",
        "Issues Tracker",
        "QTR Comparison",
    ]
    for tab in tabs:
        report.add_result(
            "2 — Key Visuals",
            tab in html,
            f"Tab: {tab}"
        )

    # All 8 KPI card labels
    kpi_labels = [
        "AVG SCORE",
        "TOTAL RECORDS",
        "GREEN",
        "AMBER",
        "RED",
        "NON-CONFORMANCES",
        "OPPORTUNITIES",
        "TOTAL ISSUES",
    ]
    for label in kpi_labels:
        report.add_result(
            "2 — Key Visuals",
            label in html,
            f"KPI card: {label}"
        )

    # Charts — at least 3 canvas or svg
    chart_count = page.locator("canvas").count() + page.locator("svg").count()
    report.add_result(
        "2 — Key Visuals",
        chart_count >= 3,
        f"Charts found: {chart_count} (expected >= 3)"
    )

    # Tables
    table_count = page.locator("table").count()
    report.add_result(
        "2 — Key Visuals",
        table_count >= 1,
        f"Tables found: {table_count}"
    )

    # Table has data rows
    row_count = page.locator("table tbody tr").count()
    report.add_result(
        "2 — Key Visuals",
        row_count > 0,
        f"Table data rows: {row_count}"
    )

    # Top Projects and Needing Attention sections
    report.add_result("2 — Key Visuals", "Top Projects"      in html, "Top Projects section")
    report.add_result("2 — Key Visuals", "Needing Attention" in html, "Needing Attention section")
    report.add_result("2 — Key Visuals", "Quarter Overview"  in html, "Quarter Overview section")
    report.add_result("2 — Key Visuals", "Issue Type"        in html, "Issue Type Breakdown section")

    # Global filter
    report.add_result("2 — Key Visuals", "GLOBAL FILTER" in html, "Global filter bar")

    # Screenshot
    screenshot_dir = Path(__file__).parent.parent / "screenshots"
    screenshot_dir.mkdir(exist_ok=True)
    page.screenshot(path=screenshot_dir / "audit_dashboard.png", full_page=True)
    report.add_result("2 — Key Visuals", True, "Screenshot saved → screenshots/audit_dashboard.png")

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 3 — Data Correctness
    # Check: Data in HTML matches Excel source
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("3 — Data Correctness")

    # All project names in HTML
    project_names = get_column_values(df_projects, "Project Name")
    missing       = [name for name in project_names if name not in html]

    report.add_result(
        "3 — Data Correctness",
        len(missing) == 0,
        f"All {len(project_names)} project names in HTML"
        if not missing else
        f"Missing projects: {missing[:5]}"
    )

    # All quarters in HTML
    quarters        = get_unique_values(df_projects, "Quarter")
    missing_quarters = [str(q) for q in quarters if str(q) not in html]

    report.add_result(
        "3 — Data Correctness",
        len(missing_quarters) == 0,
        f"All quarters present: {[str(q) for q in quarters]}"
        if not missing_quarters else
        f"Missing quarters: {missing_quarters}"
    )

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 4 — Security
    # Check: CSP, XSS, JS issues
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("4 — Security")
    report.add_results("4 — Security", run_all_security_checks(page))

    # ─────────────────────────────────────────────────────────────────────────
    # Print and save report
    # ─────────────────────────────────────────────────────────────────────────
    return report.print_and_save()
