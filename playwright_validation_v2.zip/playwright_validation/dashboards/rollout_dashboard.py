"""
dashboards/rollout_dashboard.py
================================
Complete Playwright validation for GHCP Rollout Dashboard.
(build_rllot_dashboard.py  →  rllot_data.json  →  HTML)

Sections:
  1. Core Logic      — Phase % and KPI values match JSON data
  2. Key Visuals     — All UI elements exist and are visible
  3. Data Correctness— DR/PM counts match, orgs present
  4. Smoke Test      — Tabs, filters, drawer, search, timeline
  5. Security        — CSP, XSS, eval()

CSS selectors are based on actual source code.
Update this file if dashboard structure changes.
"""

import json
import math
from pathlib import Path
from playwright.sync_api import Page

from common.security_checks import run_all_security_checks
from common.report import Report

# ── Constants matching build_rllot_dashboard.py ───────────────────────────────
SHEETS = {
    "BackEnd_Unit_Testing"  : "Backend Unit Testing",
    "Gen_Test_Case"         : "Generate Test Cases",
    "Gen_Scripts_4_PostMan" : "Generate PostMan Scripts",
}

ACTIVE_STATUSES = {"Completed", "In Progress", "Open", "On Hold", "NA"}

STATUS_ORDER = [
    "Completed", "Approved", "In Progress", "Open",
    "TBD", "On Hold", "Rejected", "NA", "Not Filled"
]

PHASES = [
    ("p1", "Phase 1", "Learning & Understanding Scope"),
    ("p2", "Phase 2", "Customize & Implement Prompt"),
    ("p3", "Phase 3", "Execution & Result Validation"),
]


# ── Helper: replicate Python script logic independently ───────────────────────

def _pct(a, tot):
    """Same as pct() in build_rllot_dashboard.py"""
    return round(a / tot * 100, 1) if tot else 0


def _phase_completion(rows, phase):
    """Same as phase_completion() in build_rllot_dashboard.py"""
    tot  = sum(1 for r in rows if r[phase] in ACTIVE_STATUSES)
    comp = sum(1 for r in rows if r[phase] == "Completed")
    return _pct(comp, tot) if tot else 0


def _overall_progress(rows):
    """Same as overall_progress() in build_rllot_dashboard.py"""
    if not rows:
        return 0.0
    pcts = []
    for ph_key, _, _ in PHASES:
        denom = sum(1 for r in rows if r[ph_key] in ACTIVE_STATUSES)
        num   = sum(1 for r in rows if r[ph_key] == "Completed")
        pcts.append(_pct(num, denom))
    return round(sum(pcts) / 3, 1)


def _load_json(json_path: Path) -> dict:
    """Load rllot_data.json"""
    with open(json_path) as f:
        return json.load(f)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN VALIDATE FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def validate(page: Page, config: dict) -> bool:
    """
    Run all validation checks for GHCP Rollout Dashboard.
    Returns True if all checks pass, False if any fail.
    """
    report    = Report(config["name"])
    html_path = config["html_path"]
    json_path = config["json_path"]

    # ── Open HTML ─────────────────────────────────────────────────────────────
    page.goto(f"file:///{html_path.resolve()}")
    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(600)

    # ── Load JSON independently ───────────────────────────────────────────────
    try:
        raw = _load_json(json_path)
    except Exception as e:
        report.add_section("0 — JSON Load")
        report.add_result("0 — JSON Load", False, f"Cannot load JSON: {e}")
        return report.print_and_save()

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 1 — Core Logic
    # Validates KPI values and phase completion % against JSON
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("1 — Core Logic")

    # ── 1a. Aggregate KPIs (Overview tab) ────────────────────────────────────
    # From render_overview() lines 584-633
    all_rows  = []
    for key in SHEETS:
        all_rows.extend(raw.get(key, []))

    agg_tot    = len(all_rows)
    agg_p1c    = sum(1 for r in all_rows if r.get("p1") == "Completed")
    agg_p2c    = sum(1 for r in all_rows if r.get("p2") == "Completed")
    agg_p3c    = sum(1 for r in all_rows if r.get("p3") == "Completed")
    agg_p1d    = sum(1 for r in all_rows if r.get("p1") in ACTIVE_STATUSES)
    agg_p2d    = sum(1 for r in all_rows if r.get("p2") in ACTIVE_STATUSES)
    agg_p3d    = sum(1 for r in all_rows if r.get("p3") in ACTIVE_STATUSES)
    agg_denom  = agg_p1d + agg_p2d + agg_p3d
    agg_pct    = round((agg_p1c + agg_p2c + agg_p3c) / agg_denom * 100, 1) \
                 if agg_denom else 0
    fully_done = sum(
        1 for r in all_rows
        if r.get("p1") == "Completed"
        and r.get("p2") == "Completed"
        and r.get("p3") == "Completed"
    )
    agg_overdue = sum(
        1 for r in all_rows
        if any([
            _is_overdue_check(r.get("p1"), r.get("p1_eta")),
            _is_overdue_check(r.get("p2"), r.get("p2_eta")),
            _is_overdue_check(r.get("p3"), r.get("p3_eta")),
        ])
    )

    # Overview KPI labels from lines 607-633:
    # "Total Team-Initiatives", "Fully Completed (All 3 Phases)",
    # "Phase 1 Completed", "Phase 2 Completed", "Phase 3 Completed",
    # "Weighted Overall Progress", "Teams with Due Phase(s)"

    html = page.content()

    report.add_result(
        "1 — Core Logic",
        str(agg_tot) in html,
        f"Total Team-Initiatives: {agg_tot}"
    )
    report.add_result(
        "1 — Core Logic",
        str(fully_done) in html,
        f"Fully Completed (All 3): {fully_done}"
    )
    report.add_result(
        "1 — Core Logic",
        str(agg_p1c) in html,
        f"Phase 1 Completed count: {agg_p1c}"
    )
    report.add_result(
        "1 — Core Logic",
        str(agg_p2c) in html,
        f"Phase 2 Completed count: {agg_p2c}"
    )
    report.add_result(
        "1 — Core Logic",
        str(agg_p3c) in html,
        f"Phase 3 Completed count: {agg_p3c}"
    )
    report.add_result(
        "1 — Core Logic",
        f"{agg_pct}" in html,
        f"Weighted Overall Progress: {agg_pct}%"
    )
    report.add_result(
        "1 — Core Logic",
        str(agg_overdue) in html,
        f"Teams with Due Phases: {agg_overdue}"
    )

    # ── 1b. Per-sheet phase completion % (donut text) ─────────────────────────
    # id="dtxt-{key}-{ph}" contains the % text
    for key in SHEETS:
        rows = raw.get(key, [])
        for ph_key, ph_label, _ in PHASES:
            expected_pct = _phase_completion(rows, ph_key)
            donut_id     = f"dtxt-{key}-{ph_key}"
            try:
                actual_text = page.locator(f"#{donut_id}").inner_text().strip()
                actual_pct  = float(actual_text.replace("%", "").strip())
                diff        = abs(actual_pct - expected_pct)
                report.add_result(
                    "1 — Core Logic",
                    diff <= 0.5,
                    f"{SHEETS[key]} {ph_label}: JSON={expected_pct}% HTML={actual_pct}%"
                )
            except Exception:
                report.add_result(
                    "1 — Core Logic",
                    False,
                    f"Cannot read donut #{donut_id} — check selector"
                )

    # ── 1c. Overall progress per sheet ───────────────────────────────────────
    for key in SHEETS:
        rows           = raw.get(key, [])
        expected_pct   = _overall_progress(rows)
        overall_arc_id = f"darc-{key}-p1"   # first phase arc as proxy check
        try:
            # check arc element exists
            arc = page.locator(f"#{overall_arc_id}")
            report.add_result(
                "1 — Core Logic",
                arc.count() > 0,
                f"{SHEETS[key]} overall donut present (overall={expected_pct}%)"
            )
        except Exception:
            report.add_result(
                "1 — Core Logic", False,
                f"Cannot find donut arc #{overall_arc_id}"
            )

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 2 — Key Visuals
    # All UI elements exist and are visible
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("2 — Key Visuals")

    # Overview tab active on load
    report.add_result(
        "2 — Key Visuals",
        page.locator("#tab-overview.active").count() > 0,
        "Overview tab active on load"
    )

    # Page title
    report.add_result(
        "2 — Key Visuals",
        "GenAI SDLC" in html or "Roll-Out" in html,
        "Dashboard title visible"
    )

    # KPI row on overview
    report.add_result(
        "2 — Key Visuals",
        page.locator(".kpi-row").count() > 0,
        "KPI row present"
    )

    # KPI boxes — at least 7 on overview
    kpi_count = page.locator(".kpi-box").count()
    report.add_result(
        "2 — Key Visuals",
        kpi_count >= 7,
        f"KPI boxes: {kpi_count} (expected >= 7)"
    )

    # No blank KPI values
    kpi_vals = page.locator(".kpi-val")
    blank_kpis = 0
    for i in range(kpi_vals.count()):
        if kpi_vals.nth(i).inner_text().strip() in ("", "—"):
            blank_kpis += 1
    report.add_result(
        "2 — Key Visuals",
        blank_kpis == 0,
        f"KPI values — blank count: {blank_kpis}"
    )

    # Overview cards — one per sheet
    ov_cards = page.locator(".ov-card")
    report.add_result(
        "2 — Key Visuals",
        ov_cards.count() == len(SHEETS),
        f"Overview cards: {ov_cards.count()} (expected {len(SHEETS)})"
    )

    # Each sheet tab panel exists
    for key in SHEETS:
        panel = page.locator(f"#tab-{key}")
        report.add_result(
            "2 — Key Visuals",
            panel.count() > 0,
            f"Tab panel exists: {SHEETS[key]}"
        )

    # Phase cards per sheet — p1, p2, p3
    for key in SHEETS:
        for ph_key, ph_label, _ in PHASES:
            card_id = f"pc-{key}-{ph_key}"
            report.add_result(
                "2 — Key Visuals",
                page.locator(f"#{card_id}").count() > 0,
                f"Phase card: {SHEETS[key]} {ph_label}"
            )

    # Stacked bar per sheet per phase
    for key in SHEETS:
        for ph_key, ph_label, _ in PHASES:
            bar_id = f"pbar-{key}-{ph_key}"
            report.add_result(
                "2 — Key Visuals",
                page.locator(f"#{bar_id}").count() > 0,
                f"Stack bar: {SHEETS[key]} {ph_label}"
            )

    # Organisation breakdown tables
    for key in SHEETS:
        table_id = f"orgt-{key}"
        report.add_result(
            "2 — Key Visuals",
            page.locator(f"#{table_id}").count() > 0,
            f"Org table: {SHEETS[key]}"
        )

    # Team detail tables
    for key in SHEETS:
        table_id = f"dt-{key}"
        report.add_result(
            "2 — Key Visuals",
            page.locator(f"#{table_id}").count() > 0,
            f"Detail table: {SHEETS[key]}"
        )

    # Filter bar per sheet
    for key in SHEETS:
        report.add_result(
            "2 — Key Visuals",
            page.locator(f'#tab-{key} .filter-bar').count() > 0,
            f"Filter bar: {SHEETS[key]}"
        )

    # Detail buttons exist
    detail_btns = page.locator(".detail-btn")
    report.add_result(
        "2 — Key Visuals",
        detail_btns.count() > 0,
        f"Detail/expand buttons: {detail_btns.count()}"
    )

    # Timeline tab
    report.add_result(
        "2 — Key Visuals",
        page.locator("#tab-timeline").count() > 0,
        "Timeline tab panel exists"
    )

    # Screenshot
    screenshot_dir = Path(__file__).parent.parent / "screenshots"
    screenshot_dir.mkdir(exist_ok=True)
    page.screenshot(
        path=screenshot_dir / "rollout_dashboard.png",
        full_page=True
    )
    report.add_result(
        "2 — Key Visuals", True,
        "Screenshot saved → screenshots/rollout_dashboard.png"
    )

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 3 — Data Correctness
    # DR counts, PM counts, org names present
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("3 — Data Correctness")

    for key in SHEETS:
        rows = raw.get(key, [])

        # ── DR count per initiative ───────────────────────────────────────────
        all_drs = sorted(set(r["dr"] for r in rows if r.get("dr")))
        for dr_name in all_drs[:5]:   # check first 5 DRs to keep test fast
            expected = sum(1 for r in rows if r.get("dr") == dr_name)

            # Select DR filter — data-attr="dr" on .f-sel
            dr_sel = page.locator(
                f'#tab-{key} .f-sel[data-attr="dr"]'
            )
            if dr_sel.count() > 0:
                dr_sel.select_option(label=dr_name)
                page.wait_for_timeout(400)

                actual = page.locator(
                    f'#dt-{key} tbody tr:visible'
                ).count()

                report.add_result(
                    "3 — Data Correctness",
                    actual == expected,
                    f"{SHEETS[key]} DR '{dr_name}': "
                    f"JSON={expected} HTML={actual}"
                )

                # Reset filter
                reset_btn = page.locator(f'#tab-{key} .f-reset')
                if reset_btn.count() > 0:
                    reset_btn.click()
                    page.wait_for_timeout(300)
            else:
                report.add_result(
                    "3 — Data Correctness", False,
                    f"DR filter not found for {SHEETS[key]}"
                )
                break

        # ── Total row count per initiative ────────────────────────────────────
        expected_total = len(rows)
        actual_rows    = page.locator(f'#dt-{key} tbody tr').count()
        report.add_result(
            "3 — Data Correctness",
            actual_rows == expected_total,
            f"{SHEETS[key]} total rows: JSON={expected_total} HTML={actual_rows}"
        )

        # ── Org names present in HTML ─────────────────────────────────────────
        all_orgs    = set(r.get("org", "") for r in rows if r.get("org"))
        missing_org = [o for o in list(all_orgs)[:5] if o not in html]
        report.add_result(
            "3 — Data Correctness",
            len(missing_org) == 0,
            f"{SHEETS[key]} org names in HTML"
            if not missing_org else
            f"{SHEETS[key]} missing orgs: {missing_org}"
        )

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 4 — Smoke Test
    # Tabs, filters, drawer, search, timeline interactions
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("4 — Smoke Test")

    # ── Click each overview card → tab opens ─────────────────────────────────
    for key in SHEETS:
        try:
            card = page.locator(f'.ov-card[data-tab="{key}"]')
            if card.count() > 0:
                card.click()
                page.wait_for_timeout(400)
                panel_visible = page.locator(
                    f'#tab-{key}.active'
                ).count() > 0 or page.locator(
                    f'#tab-{key}'
                ).is_visible()
                report.add_result(
                    "4 — Smoke Test",
                    panel_visible,
                    f"Click overview card → {SHEETS[key]} tab opens"
                )
                # Go back to overview
                ov_btn = page.locator('[data-tab="overview"], #tab-overview-btn')
                if ov_btn.count() > 0:
                    ov_btn.first.click()
                    page.wait_for_timeout(300)
        except Exception as e:
            report.add_result(
                "4 — Smoke Test", False,
                f"Overview card click error ({key}): {e}"
            )

    # ── Test first sheet tab in detail ───────────────────────────────────────
    first_key = list(SHEETS.keys())[0]

    # Navigate to first sheet
    first_card = page.locator(f'.ov-card[data-tab="{first_key}"]')
    if first_card.count() > 0:
        first_card.click()
        page.wait_for_timeout(400)

    # Status filter dropdown
    try:
        status_sel = page.locator(
            f'#tab-{first_key} .f-sel[data-attr="status"]'
        )
        if status_sel.count() > 0:
            status_sel.select_option(value="Completed")
            page.wait_for_timeout(400)
            rows_after = page.locator(
                f'#dt-{first_key} tbody tr:visible'
            ).count()
            report.add_result(
                "4 — Smoke Test",
                True,
                f"Status filter 'Completed' → {rows_after} rows visible"
            )
            # Reset
            page.locator(f'#tab-{first_key} .f-reset').click()
            page.wait_for_timeout(300)
        else:
            report.add_result(
                "4 — Smoke Test", False,
                "Status filter not found"
            )
    except Exception as e:
        report.add_result("4 — Smoke Test", False, f"Status filter error: {e}")

    # Overdue filter
    try:
        od_sel = page.locator(
            f'#tab-{first_key} .f-sel[data-attr="overdue"]'
        )
        if od_sel.count() > 0:
            od_sel.select_option(value="yes")
            page.wait_for_timeout(400)
            report.add_result("4 — Smoke Test", True, "Overdue filter works")
            page.locator(f'#tab-{first_key} .f-reset').click()
            page.wait_for_timeout(300)
    except Exception as e:
        report.add_result("4 — Smoke Test", False, f"Overdue filter error: {e}")

    # Search box
    try:
        search = page.locator(f'#tab-{first_key} .f-search')
        if search.count() > 0:
            search.fill("test")
            page.wait_for_timeout(400)
            report.add_result("4 — Smoke Test", True, "Search input works")
            page.locator(f'#tab-{first_key} .f-reset').click()
            page.wait_for_timeout(300)
    except Exception as e:
        report.add_result("4 — Smoke Test", False, f"Search error: {e}")

    # Detail/expand button → drawer opens
    try:
        btn = page.locator(".detail-btn").first
        if btn.count() > 0:
            btn.click()
            page.wait_for_timeout(500)
            drawer_visible = page.locator(".drawer-body").is_visible() or \
                             page.locator("[class*=drawer]").count() > 0
            report.add_result(
                "4 — Smoke Test",
                drawer_visible,
                "Detail button click → drawer opens"
            )
            # Close drawer if possible
            close = page.locator(".drawer-close, [class*=close]")
            if close.count() > 0:
                close.first.click()
                page.wait_for_timeout(300)
        else:
            report.add_result(
                "4 — Smoke Test", False,
                "No detail buttons found"
            )
    except Exception as e:
        report.add_result("4 — Smoke Test", False, f"Drawer error: {e}")

    # Collapsible sections
    try:
        collapsible = page.locator(".sec-collapsible").first
        if collapsible.count() > 0:
            collapsible.click()
            page.wait_for_timeout(300)
            report.add_result(
                "4 — Smoke Test", True,
                "Collapsible section toggles"
            )
    except Exception as e:
        report.add_result(
            "4 — Smoke Test", False,
            f"Collapsible error: {e}"
        )

    # Timeline tab
    try:
        tl_tab = page.locator('[data-tab="timeline"], #tl-tab-btn')
        if tl_tab.count() > 0:
            tl_tab.first.click()
            page.wait_for_timeout(400)
            tl_panel = page.locator("#tab-timeline")
            report.add_result(
                "4 — Smoke Test",
                tl_panel.count() > 0,
                "Timeline tab opens"
            )
        else:
            report.add_result(
                "4 — Smoke Test", False,
                "Timeline tab button not found"
            )
    except Exception as e:
        report.add_result("4 — Smoke Test", False, f"Timeline error: {e}")

    # No JS console errors
    errors = []
    page.on(
        "console",
        lambda msg: errors.append(msg.text) if msg.type == "error" else None
    )
    page.wait_for_timeout(500)
    report.add_result(
        "4 — Smoke Test",
        len(errors) == 0,
        "No JS console errors"
        if not errors else
        f"Console errors: {errors[:3]}"
    )

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 5 — Security
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("5 — Security")
    report.add_results("5 — Security", run_all_security_checks(page))

    # ── Print and save report ─────────────────────────────────────────────────
    return report.print_and_save()


# ── Helper for overdue check (mirrors is_overdue in source) ───────────────────
def _is_overdue_check(status, eta_str):
    from datetime import date
    if status not in ("Open", "In Progress") or not eta_str:
        return False
    try:
        eta = date.fromisoformat(eta_str)
        return date.today() > eta
    except ValueError:
        return False
