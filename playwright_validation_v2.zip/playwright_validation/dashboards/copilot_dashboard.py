"""
dashboards/copilot_dashboard.py
================================
All validation checks for the GHCP Rollout Dashboard.

Update this file when dashboard structure or KPIs change.
"""

from pathlib import Path
from playwright.sync_api import Page

from common.excel_checks    import load_excel, count_rows, get_column_values
from common.security_checks import run_all_security_checks
from common.report          import Report


def validate(page: Page, config: dict) -> bool:
    """
    Run all validation checks for GHCP Rollout Dashboard.
    Returns True if all pass, False if any fail.
    """
    report     = Report(config["name"])
    excel_path = config["excel_path"]
    html_path  = config["html_path"]

    page.goto(f"file:///{html_path.resolve()}")
    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(500)

    html = page.content()

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 1 — Core Logic
    # TODO: Update KPI calculations to match actual dashboard logic
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("1 — Core Logic")

    df = load_excel(excel_path, "Data")

    expected_total = count_rows(df)
    report.add_result("1 — Core Logic", True,
        f"Expected TOTAL: {expected_total} — verify against HTML KPI")

    # Add more KPI checks here when dashboard logic is confirmed

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 2 — Key Visuals
    # TODO: Update labels to match actual dashboard elements
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("2 — Key Visuals")

    report.add_result("2 — Key Visuals", "GitHub Copilot" in html or "GHCP" in html,
        "Dashboard title visible")

    chart_count = page.locator("canvas").count() + page.locator("svg").count()
    report.add_result("2 — Key Visuals", chart_count >= 1,
        f"Charts found: {chart_count}")

    table_count = page.locator("table").count()
    report.add_result("2 — Key Visuals", table_count >= 1,
        f"Tables found: {table_count}")

    # Screenshot
    screenshot_dir = Path(__file__).parent.parent / "screenshots"
    screenshot_dir.mkdir(exist_ok=True)
    page.screenshot(path=screenshot_dir / "copilot_dashboard.png", full_page=True)
    report.add_result("2 — Key Visuals", True,
        "Screenshot saved → screenshots/copilot_dashboard.png")

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 3 — Data Correctness
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("3 — Data Correctness")

    # Update column name to match actual Excel column
    try:
        names   = get_column_values(df, df.columns[0])
        missing = [n for n in names[:10] if n not in html]
        report.add_result("3 — Data Correctness", len(missing) == 0,
            f"Sample data values present in HTML"
            if not missing else f"Missing values: {missing[:3]}")
    except Exception as e:
        report.add_result("3 — Data Correctness", False, f"Data check error: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # SECTION 4 — Security
    # ─────────────────────────────────────────────────────────────────────────
    report.add_section("4 — Security")
    report.add_results("4 — Security", run_all_security_checks(page))

    return report.print_and_save()
