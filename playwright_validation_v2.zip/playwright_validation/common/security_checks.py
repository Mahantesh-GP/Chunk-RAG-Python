"""
common/security_checks.py
==========================
Reusable security check functions.
Used by all dashboard files.
Developer does not need to touch this file.
"""

import re
from playwright.sync_api import Page


def check_csp_exists(page: Page) -> tuple[bool, str]:
    """Check CSP meta tag exists."""
    csp = page.locator("meta[http-equiv='Content-Security-Policy']")
    if csp.count() > 0:
        return True, "CSP meta tag present"
    return False, "CSP meta tag missing"


def check_no_unsafe_inline(page: Page) -> tuple[bool, str]:
    """Check CSP does not contain unsafe-inline."""
    csp = page.locator("meta[http-equiv='Content-Security-Policy']")
    if csp.count() == 0:
        return False, "CSP meta tag missing — cannot check unsafe-inline"
    content = csp.get_attribute("content") or ""
    if "unsafe-inline" in content:
        return False, "CSP contains unsafe-inline — XSS risk"
    return True, "CSP — no unsafe-inline"


def check_no_inline_handlers(html: str) -> tuple[bool, str]:
    """Check no inline event handlers like onclick, onerror."""
    dangerous = ["onclick", "onerror", "onload", "onmouseover", "onfocus"]
    found = []
    for attr in dangerous:
        matches = re.findall(
            rf'<(?!body|html)[^>]+\s{attr}\s*=', html, re.IGNORECASE
        )
        if matches:
            found.append(attr)
    if found:
        return False, f"Inline event handlers found: {found}"
    return True, "No inline event handlers"


def check_no_javascript_protocol(html: str) -> tuple[bool, str]:
    """Check no javascript: protocol in href."""
    matches = re.findall(r'href\s*=\s*["\']javascript:', html, re.IGNORECASE)
    if matches:
        return False, "javascript: protocol found in href"
    return True, "No javascript: in href"


def check_no_eval(html: str) -> tuple[bool, str]:
    """Check no eval() in inline scripts."""
    matches = re.findall(
        r'<script[^>]*>.*?eval\s*\(', html, re.IGNORECASE | re.DOTALL
    )
    if matches:
        return False, "eval() found in script"
    return True, "No eval() in scripts"


def check_no_console_errors(page: Page) -> tuple[bool, str]:
    """Check no JS console errors after page load."""
    errors = []
    page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
    page.wait_for_timeout(1000)
    if errors:
        return False, f"Console errors: {errors[:3]}"
    return True, "No console errors"


def run_all_security_checks(page: Page) -> list[tuple[bool, str]]:
    """
    Run all security checks and return results.
    Call this from any dashboard file.
    """
    html    = page.content()
    results = []

    results.append(check_csp_exists(page))
    results.append(check_no_unsafe_inline(page))
    results.append(check_no_inline_handlers(html))
    results.append(check_no_javascript_protocol(html))
    results.append(check_no_eval(html))
    results.append(check_no_console_errors(page))

    return results
