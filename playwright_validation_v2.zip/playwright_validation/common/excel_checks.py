"""
common/excel_checks.py
======================
Reusable Excel reading and calculation functions.
Used by all dashboard files.
Developer does not need to touch this file.
"""

import pandas as pd
from pathlib import Path


def load_excel(excel_path: Path, sheet_name: str) -> pd.DataFrame:
    """Load a sheet from Excel into a DataFrame."""
    return pd.read_excel(excel_path, sheet_name=sheet_name)


def count_rows(df: pd.DataFrame) -> int:
    """Count total data rows."""
    return len(df)


def count_where(df: pd.DataFrame, column: str, value) -> int:
    """Count rows where column equals value."""
    return len(df[df[column] == value])


def count_greater_equal(df: pd.DataFrame, column: str, value: float) -> int:
    """Count rows where column >= value."""
    return len(df[df[column] >= value])


def count_between(df: pd.DataFrame, column: str, low: float, high: float) -> int:
    """Count rows where low <= column < high."""
    return len(df[(df[column] >= low) & (df[column] < high)])


def count_less_than(df: pd.DataFrame, column: str, value: float) -> int:
    """Count rows where column < value."""
    return len(df[df[column] < value])


def average_column(df: pd.DataFrame, column: str) -> float:
    """Calculate average of a column, rounded to 1 decimal."""
    return round(df[column].mean(), 1)


def get_unique_values(df: pd.DataFrame, column: str) -> list:
    """Get unique non-null values from a column."""
    return df[column].dropna().unique().tolist()


def get_column_values(df: pd.DataFrame, column: str) -> list:
    """Get all non-null values from a column as strings."""
    return df[column].dropna().astype(str).tolist()
