"""
common/report.py
================
Collects results and prints a clean pass/fail report.
Saves report to reports/ folder.
Developer does not need to touch this file.
"""

from datetime import datetime
from pathlib import Path


class Report:

    def __init__(self, dashboard_name: str):
        self.dashboard_name = dashboard_name
        self.sections       = {}   # section_name → list of (passed, message)
        self.report_dir     = Path(__file__).parent.parent / "reports"
        self.report_dir.mkdir(exist_ok=True)

    def add_section(self, section_name: str):
        """Start a new section in the report."""
        self.sections[section_name] = []

    def add_result(self, section_name: str, passed: bool, message: str):
        """Add a single check result to a section."""
        if section_name not in self.sections:
            self.add_section(section_name)
        self.sections[section_name].append((passed, message))

    def add_results(self, section_name: str, results: list[tuple[bool, str]]):
        """Add multiple results to a section at once."""
        for passed, message in results:
            self.add_result(section_name, passed, message)

    def print_and_save(self) -> bool:
        """Print report to console and save to file. Returns overall pass/fail."""
        lines      = []
        all_passed = True

        lines.append(f"\n{'═' * 60}")
        lines.append(f"  VALIDATION REPORT — {self.dashboard_name.upper()}")
        lines.append(f"  {datetime.now().strftime('%Y-%m-%d  %H:%M')}")
        lines.append(f"{'═' * 60}")

        for section, results in self.sections.items():
            section_passed = all(r[0] for r in results)
            icon           = "✅" if section_passed else "❌"

            lines.append(f"\n  {icon}  {section}")

            for passed, message in results:
                check_icon = "  ✅" if passed else "  ❌"
                lines.append(f"     {check_icon}  {message}")

            if not section_passed:
                all_passed = False

        lines.append(f"\n{'─' * 60}")
        if all_passed:
            lines.append("  ✅  ALL PASSED — Safe to deploy")
        else:
            lines.append("  ❌  FAILED — Fix issues before deploying")
        lines.append(f"{'─' * 60}\n")

        report_text = "\n".join(lines)

        # Print to console
        print(report_text)

        # Save to file
        safe_name   = self.dashboard_name.lower().replace(" ", "_")
        report_path = self.report_dir / f"{safe_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        report_path.write_text(report_text)
        print(f"  Report saved → {report_path}\n")

        return all_passed
