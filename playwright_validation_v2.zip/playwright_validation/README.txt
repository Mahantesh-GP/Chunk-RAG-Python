Dashboard Validation — Playwright
==================================
EA Team | April 2026


FOLDER STRUCTURE
----------------
playwright_validation/
├── run.py                      ← developer runs this only
├── config.py                   ← all paths and settings here
├── requirements.txt
├── dashboards/
│   ├── audit_dashboard.py      ← all checks for Audit Dashboard
│   └── copilot_dashboard.py    ← all checks for Copilot Dashboard
├── common/
│   ├── excel_checks.py         ← reusable Excel functions
│   ├── security_checks.py      ← reusable security functions
│   └── report.py               ← pass/fail report builder
├── screenshots/                ← auto created — screenshots saved here
└── reports/                    ← auto created — text reports saved here


SETUP
-----
pip install -r requirements.txt
playwright install chromium


HOW TO RUN
----------
Validate one dashboard:
    python run.py --dashboard audit
    python run.py --dashboard copilot

Validate all dashboards:
    python run.py --all


HOW TO ADD A NEW DASHBOARD
--------------------------
1. Add config in config.py:
   "my_dashboard": {
       "name"      : "My Dashboard",
       "excel_path": PROJECT_ROOT / "data" / "my_data.xlsx",
       "html_path" : PROJECT_ROOT / "package" / "dashboard" / "my" / "my.html",
       "sheets"    : { "data": "Sheet1" },
   }

2. Copy dashboards/copilot_dashboard.py
   Rename to dashboards/my_dashboard.py
   Update the checks to match your dashboard

3. Add import in run.py:
   from dashboards import my_dashboard

4. Add mapping in run.py:
   DASHBOARD_MODULES = {
       ...
       "my_dashboard": my_dashboard,
   }

5. Run:
   python run.py --dashboard my_dashboard


WHICH FILE TO EDIT FOR WHAT
----------------------------
New dashboard path changed    → config.py
New KPI check for a dashboard → dashboards/<dashboard>.py
New visual element to check   → dashboards/<dashboard>.py
New security check needed     → common/security_checks.py
Report format change          → common/report.py


WHAT GETS VALIDATED
-------------------
Section 1 — Core Logic
  KPI values calculated from Excel
  Totals consistency check

Section 2 — Key Visuals
  Dashboard title
  All tabs present
  All KPI card labels
  Charts rendered
  Tables with data rows
  Filters visible
  Screenshot taken

Section 3 — Data Correctness
  All records from Excel appear in HTML
  Quarter values match

Section 4 — Security
  CSP meta tag present
  No unsafe-inline in CSP
  No inline event handlers
  No javascript: in href
  No eval() in scripts
  No console errors
