# Spec Kit — Step by Step Guide
## GHCP Rollout Dashboard — From BRD to Implementation

**Prerequisites:** GitHub Copilot in VS Code, Python 3.11+, uv or pipx installed  
**Time required:** ~2 hours first time, 30 mins per future feature  
**Your project folder:** The folder containing your dashboard Python scripts and HTML output  

---

## STEP 0 — Install Spec Kit (one time only)

Open terminal in your project folder.

```bash
# Install the CLI
pip install uv   # if you don't have uv yet

# Initialize Spec Kit in your existing project
uvx --from git+https://github.com/github/spec-kit.git specify init . --here --integration copilot --force

# Verify it worked — should show version number
uvx --from git+https://github.com/github/spec-kit.git specify --version
```

**What gets created:**
```
.specify/
  memory/         ← constitution lives here
  specs/          ← all your feature specs live here
  templates/      ← Spec Kit templates
.github/
  prompts/        ← Copilot slash commands installed here
```

> ✅ Done when: you see `.specify/` folder created in your project

---

## STEP 1 — Constitution

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.constitution`  

**Copy and paste this exact prompt:**

```
/speckit.constitution

Create a constitution for a Python-based static HTML dashboard system with 
the following rules:

Tech Stack:
- Python 3.x for all data processing and HTML generation
- Static HTML output only — no frameworks, no JavaScript libraries
- Playwright (Python) for automated regression testing
- No database, no API, no user input — read-only dashboards

Security Rules:
- All Excel cell values must be sanitised using html.escape() before rendering
- Every generated HTML file must contain a CSP meta tag
- No inline JavaScript event handlers permitted (onclick, onload, onerror etc.)
- All external scripts must use SRI hashes

Testing Rules:
- Playwright tests must run after every dashboard regeneration
- Tests must cover: page structure, data accuracy vs source, screenshot baseline
- Test scenarios must be documented in the repo with code path

Architecture Rules:
- Max 3 Python scripts per dashboard: process_data.py, build_dashboard.py, test_dashboard.py
- No unnecessary abstraction — direct, readable Python only
- Single developer context — no over-engineering, no future-proofing
- New dashboards must reuse existing test framework without rewriting it

Data Rules:
- Excel is the single source of truth
- JSON intermediate file must be generated between Excel and HTML steps
- Sheet names and column names must be documented and validated at runtime
```

**Wait for Copilot to generate** `.specify/memory/constitution.md`

**Review it** — make sure it matches your project reality before moving on.

> ✅ Done when: `.specify/memory/constitution.md` exists and reads correctly

---

## STEP 2 — Specify (BRD → spec.md)

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.specify`  

**Copy and paste this exact prompt:**

```
/speckit.specify

Here is our BRD in Markdown. Extract a spec.md from it following the 
Spec Kit template. 

Rules:
- Convert all requirements to FR-XXX (Functional Requirements) format
- Convert all success criteria to SC-XXX format  
- Do NOT include any technology decisions in spec.md (Python, Playwright, 
  Excel, HTML — these go to plan.md)
- Mark anything ambiguous or missing acceptance criteria with 
  [NEEDS CLARIFICATION: specific question]
- Keep language in business terms only — what the user needs, not how to build it

--- BRD START ---

# Business Requirements Document
## GHCP Rollout Dashboard — GenAI SDLC Phase 1

## Business Objectives
- Provide a single source of truth for GenAI SDLC Phase 1 rollout progress across all teams
- Enable PMs and DRs to identify adoption gaps without manual data collection
- Support data-driven decisions during the Phase 1 production rollout period
- Reduce time spent by EA Team on manual reporting from Excel to stakeholders
- Ensure rollout data is always current — refreshed daily between 11am and 1pm

## Stakeholders
- EA Team: defines rollout metrics, approves changes
- PMs and DRs: update source Excel daily
- Senior Leadership: view progress, identify gaps
- Developer: builds and maintains dashboard

## Current Problem
- Rollout data lives in a manually updated Excel file with multiple sheets
- No centralised view — stakeholders request updates individually  
- No automated validation that displayed data matches source file
- Security vulnerabilities were found in previously generated HTML

## Functional Requirements
- Read rollout data from source Excel file daily
- Process three data categories: backend unit testing, test case generation, PostMan script generation
- Display rollout progress per team in structured tabular format
- Show adoption gaps clearly — incomplete teams highlighted
- Show last refresh timestamp
- Dashboard must be readable in standard desktop browsers
- Automated tests must validate page structure after every regeneration
- Automated tests must validate displayed data matches source file
- Automated tests must capture screenshot baseline after successful validation
- All displayed values must be sanitised to prevent injection

## Success Criteria
- Dashboard displays current day rollout data every working day by 1pm
- Automated tests pass with zero failures after every regeneration
- Zero HIGH severity security findings in generated output
- All displayed values match source data (validated by test suite)
- Test scenarios and code path documented in the repository
- Stakeholders can view dashboard without developer intervention

## Out of Scope
- User authentication
- Real-time data refresh
- User input or filtering
- Mobile responsiveness
- Backend API or database

--- BRD END ---
```

**Wait for Copilot to generate:**
- Git branch: `001-ghcp-rollout-dashboard`
- `.specify/specs/001-ghcp-rollout-dashboard/spec.md`

**Read spec.md carefully** — check for `[NEEDS CLARIFICATION]` markers.

> ✅ Done when: `spec.md` exists with FR-XXX and SC-XXX identifiers

---

## STEP 3 — Clarify

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.clarify`  

**Copy and paste this exact prompt:**

```
/speckit.clarify

Read the spec.md for feature 001-ghcp-rollout-dashboard.

Find all [NEEDS CLARIFICATION] markers and any other ambiguities. 
Ask me structured questions to resolve them.

Context to help you ask better questions:
- This is an internal dashboard — no authentication needed
- Data source is a single Excel file updated daily by PMs
- The audience is Senior Leadership and EA Team
- One developer maintains this — simplicity is critical
- Playwright tests already exist for other dashboards in this project
```

**Answer each question Copilot asks.**

Common answers for this dashboard:
- Authentication: Not required — internal network only
- Empty data: Show "No data available" row — do not hide the table
- Highlighting gaps: Teams with status empty or "Not Started" highlighted in amber
- Screenshot location: `tests/screenshots/rollout/`
- Who decides test pass/fail: Any missing FR-XXX item = test failure

**Wait for Copilot to update spec.md** with your answers replacing all `[NEEDS CLARIFICATION]` markers.

> ✅ Done when: spec.md has zero `[NEEDS CLARIFICATION]` markers remaining

---

## STEP 4 — Plan

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.plan`  

**Copy and paste this exact prompt:**

```
/speckit.plan

Tech stack for this feature:

- Language: Python 3.x
- Data source: Excel file (openpyxl for reading)
- Intermediate format: JSON (built-in json module)
- Output: Static HTML (Python string templating — no Jinja, no frameworks)
- Testing: Playwright Python (pytest-playwright)
- Sanitisation: Python built-in html.escape()
- Hosting: Internal file server — HTML file copied to Package/Rollout/ folder
- Version control: Git repo, code path to be documented

Scripts:
1. process_rollout.py — Excel → JSON
2. build_rollout_dashboard.py — JSON → HTML
3. tests/test_rollout_dashboard.py — Playwright validation

Existing pattern to follow:
- This project already has a Playwright config.py with a dashboard registry
- New dashboard must add an entry to config.py under key "rollout"
- JSON path: Package/Rollout/rllot_data.json
- HTML path: Package/Rollout/rllot_dashboard.html
- Sheets: BackEnd_Unit_Testing, Gen_Test_Case, Gen_Scripts_4_PostMan

Validate against constitution before generating plan.
Document any exceptions with justification.
```

**Wait for Copilot to generate:**
- `.specify/specs/001-ghcp-rollout-dashboard/plan.md`
- `.specify/specs/001-ghcp-rollout-dashboard/data-model.md`
- `.specify/specs/001-ghcp-rollout-dashboard/research.md`
- `.specify/specs/001-ghcp-rollout-dashboard/quickstart.md`

**Read plan.md** — check the Phase -1 Constitution Gates section. All should be PASS or have documented exceptions.

> ✅ Done when: plan.md exists and all constitution gates are resolved

---

## STEP 5 — Analyze (do not skip this)

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.analyze`  

**Copy and paste this exact prompt:**

```
/speckit.analyze

Read all artifacts for feature 001-ghcp-rollout-dashboard:
- spec.md
- plan.md  
- data-model.md
- constitution.md

Cross-check everything. Find:
1. Any FR-XXX requirements not addressed in plan.md
2. Any SC-XXX criteria that cannot be tested from the current architecture
3. Any constitution violations not already documented as exceptions
4. Any gaps between what the BRD described and what the spec captured

Report findings as PASS, WARNING, or FAIL. 
Do not modify any files — analysis only.
```

**Read the analysis report carefully.**

Fix any WARNINGs or FAILs before moving to tasks:
- If a WARNING is about a missing field → add it to data-model.md
- If a WARNING is about a missing endpoint or script → add it to plan.md
- Re-run `/speckit.analyze` after fixes until all items are PASS or justified

> ✅ Done when: analyze report shows all PASS or documented exceptions

---

## STEP 6 — Tasks

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.tasks`  

**Copy and paste this exact prompt:**

```
/speckit.tasks

Generate tasks for feature 001-ghcp-rollout-dashboard.

Requirements:
- Group tasks into phases: Setup → Tests → Core → Integration → Polish
- Mark tasks safe to run in parallel with [P]
- Each task must specify the exact file path it creates or modifies
- Tests (Phase 2) must come BEFORE core implementation (Phase 3) — enforce TDD order
- Include a task for adding the rollout entry to config.py
- Include a task for documenting the code path and test scenarios in repo
- Include a task for screenshot baseline capture

Existing files to be aware of (do not recreate):
- config.py — already exists, add rollout entry only
- tests/ folder — already exists
- Package/ folder — already exists
```

**Wait for Copilot to generate** `.specify/specs/001-ghcp-rollout-dashboard/tasks.md`

**Review tasks.md** — confirm:
- Phase 2 (tests) comes before Phase 3 (implementation)
- config.py update is a task
- Documentation task is included
- All file paths are correct

> ✅ Done when: tasks.md exists with correct phase ordering

---

## STEP 7 — Implement

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.implement`  

**Copy and paste this exact prompt:**

```
/speckit.implement

Execute all tasks in tasks.md for feature 001-ghcp-rollout-dashboard 
in the correct phase order.

Important rules:
- Read constitution.md before touching any file
- Do NOT use inline event handlers in any generated HTML
- Do NOT use raw string concatenation for HTML values — always html.escape()
- Do NOT add a CSP meta tag that allows unsafe-inline scripts
- Phase 2 tests must be written and confirmed to exist before Phase 3 starts
- Mark each task complete in tasks.md as you finish it
- If you encounter a decision not covered by spec or plan — stop and ask me

After each phase completes, show me a summary of what was created.
```

**Monitor as Copilot works through phases.**

- After Phase 1: check files are created in right locations
- After Phase 2: check test file exists before proceeding
- After Phase 3: run `python process_rollout.py` manually and verify JSON produced
- After Phase 4: run `python build_rollout_dashboard.py` and verify HTML produced
- After Phase 5: run `pytest tests/test_rollout_dashboard.py` and verify all pass

> ✅ Done when: all tasks checked in tasks.md and Playwright tests pass

---

## STEP 8 — Checklist

**Where:** GitHub Copilot Chat in VS Code  
**Command:** `/speckit.checklist`  

**Copy and paste this exact prompt:**

```
/speckit.checklist

Generate a review checklist for feature 001-ghcp-rollout-dashboard.

Include sections for:
1. Functional review — verify each FR-XXX is implemented
2. Security review — verify CSP, no inline handlers, html.escape() used
3. Data accuracy — verify displayed values match source Excel
4. Test coverage — verify each SC-XXX has a Playwright test
5. Documentation — verify code path and test scenarios documented in repo
6. Constitution compliance — verify no violations

This checklist will be shared with the manager for sign-off.
```

**Wait for Copilot to generate** `.specify/specs/001-ghcp-rollout-dashboard/checklists/rollout-dashboard.md`

**Share this checklist with your manager** — it is your sign-off document.

> ✅ Done when: checklist generated and reviewed

---

## Quick Reference — All Prompts in Order

| Step | Command | What it does |
|---|---|---|
| 0 | Terminal: `specify init` | Install Spec Kit in project |
| 1 | `/speckit.constitution` | Set project rules — security, tech stack, testing |
| 2 | `/speckit.specify` | BRD → spec.md with FR-XXX and SC-XXX |
| 3 | `/speckit.clarify` | Resolve all gaps before planning |
| 4 | `/speckit.plan` | Tech stack → plan.md + data-model.md |
| 5 | `/speckit.analyze` | Cross-check all artifacts — catch problems before code |
| 6 | `/speckit.tasks` | plan.md → ordered task list with phases |
| 7 | `/speckit.implement` | Execute tasks — code is written here |
| 8 | `/speckit.checklist` | Generate manager sign-off checklist |

---

## Folder Structure After Completion

```
your-project/
├── .specify/
│   ├── memory/
│   │   └── constitution.md
│   └── specs/
│       └── 001-ghcp-rollout-dashboard/
│           ├── spec.md              ← WHAT to build
│           ├── plan.md              ← HOW to build it
│           ├── data-model.md        ← Excel schema + JSON structure
│           ├── research.md          ← tech decisions + rationale
│           ├── tasks.md             ← task list (all checked when done)
│           ├── quickstart.md        ← how to run locally
│           └── checklists/
│               └── rollout-dashboard.md  ← manager sign-off doc
├── Package/
│   └── Rollout/
│       ├── rllot_data.json          ← intermediate JSON
│       └── rllot_dashboard.html     ← final dashboard
├── process_rollout.py               ← Excel → JSON
├── build_rollout_dashboard.py       ← JSON → HTML
├── config.py                        ← updated with rollout entry
└── tests/
    ├── test_rollout_dashboard.py    ← Playwright tests
    └── screenshots/
        └── rollout/                 ← baseline screenshots
```

---

## Troubleshooting

**Slash commands not showing in Copilot:**  
Run `specify init . --here --integration copilot --force` again. Then restart VS Code.

**Copilot ignores constitution rules:**  
Start your prompt with: `"Read constitution.md first. Then..."` — explicitly reference it.

**Tasks generated out of order (Phase 3 before Phase 2):**  
Add to your `/speckit.tasks` prompt: `"Tests (Phase 2) must be written before any implementation (Phase 3). This is mandatory."`

**Playwright tests fail after implementation:**  
Check config.py rollout entry — paths must exactly match `Package/Rollout/rllot_data.json` and `Package/Rollout/rllot_dashboard.html` including capitalisation.

**Constitution gate FAIL in plan.md:**  
Do not skip it. Either fix the plan to comply, or document a justified exception with reason. Then re-run `/speckit.analyze`.

---

*Generated for GHCP Rollout Dashboard — Spec Kit walkthrough — May 2026*
