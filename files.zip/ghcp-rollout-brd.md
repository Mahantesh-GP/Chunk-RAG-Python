# Business Requirements Document (BRD)
## GHCP Rollout Dashboard — GenAI SDLC Phase 1

**Document Version:** 1.0  
**Date:** May 2026  
**Author:** Mahantesh  
**Status:** Draft  
**Audience:** Engineering, PMs, DRs, EA Team  

---

## 1. Executive Summary

The GHCP Rollout Dashboard tracks the organisation-wide adoption of GitHub Copilot and GenAI SDLC initiatives across all teams during Phase 1 rollout. It provides PMs, Delivery Leads, and the EA Team with a daily-refreshed, centralised view of rollout progress, gaps, and adoption status — replacing manual status updates and scattered Excel tracking.

---

## 2. Business Objectives

- BO-001: Provide a single source of truth for GenAI SDLC Phase 1 rollout progress across all teams
- BO-002: Enable PMs and DRs to identify adoption gaps without manual data collection
- BO-003: Support data-driven decisions during the Phase 1 production rollout period
- BO-004: Reduce time spent by EA Team on manual reporting from Excel to stakeholders
- BO-005: Ensure rollout data is always current — refreshed daily between 11am and 1pm

---

## 3. Stakeholders

| Role | Name / Team | Responsibility |
|---|---|---|
| Dashboard Owner | EA Team | Defines rollout metrics, approves changes |
| Data Providers | PMs and DRs | Update source Excel daily |
| Consumers | Senior Leadership | View progress, identify gaps |
| Developer | Mahantesh | Builds and maintains dashboard |

---

## 4. Current State (Problem Statement)

- Rollout data lives in an Excel file: **GenAI SDLC Initiatives — Phase 1 Roll Out Tracker.xlsx**
- Multiple sheets: BackEnd_Unit_Testing, Gen_Test_Case, Gen_Scripts_4_PostMan
- PMs and DRs update the file manually each day
- No centralised view — stakeholders request updates individually
- No automated validation that displayed data matches source Excel
- Security vulnerabilities were found in previously generated HTML (XSS, CSP, inline JS)
- No regression testing when HTML is regenerated after fixes

---

## 5. Proposed Solution

A Python-generated static HTML dashboard that:
- Reads from the source Excel file daily
- Generates a clean, secure HTML page with no user input (fully static)
- Is hosted on an internal server
- Is validated by automated Playwright tests after every regeneration
- Sanitises all Excel values using html.escape() before rendering

---

## 6. Functional Requirements

### 6.1 Data Processing
- FR-001: System must read data from GenAI SDLC Phase 1 Roll Out Tracker.xlsx daily
- FR-002: System must process three sheets: BackEnd_Unit_Testing, Gen_Test_Case, Gen_Scripts_4_PostMan
- FR-003: All cell values from Excel must be sanitised using html.escape() before rendering in HTML
- FR-004: JSON intermediate file (rllot_data.json) must be generated as a processing step before HTML generation
- FR-005: Dashboard HTML must be regenerated daily between 11am and 1pm automatically

### 6.2 Dashboard Display
- FR-006: Dashboard must display rollout progress per team in a structured tabular format
- FR-007: Dashboard must show adoption gaps clearly — teams with incomplete status highlighted
- FR-008: Dashboard title must read: "GHCP Rollout Dashboard"
- FR-009: Dashboard subtitle must read: "Track GenAI SDLC Phase 1 rollout progress, gaps, and adoption status across all teams"
- FR-010: Dashboard must show last refresh timestamp prominently
- FR-011: Dashboard must be readable on standard desktop browsers without additional software

### 6.3 Validation and Testing
- FR-012: Playwright automated tests must run after every dashboard regeneration
- FR-013: Tests must validate page structure — title, subtitle, table presence
- FR-014: Tests must validate that key data values in HTML match source Excel/JSON values
- FR-015: Tests must capture a screenshot baseline after each successful validation run
- FR-016: Test results must be logged with pass/fail status and code path documented

### 6.4 Security
- FR-017: Dashboard HTML must contain a Content Security Policy (CSP) meta tag
- FR-018: No inline JavaScript event handlers permitted (no onclick, onload in HTML)
- FR-019: No user input fields in the dashboard — fully static read-only display
- FR-020: All external script references must use SRI (Subresource Integrity) hashes

---

## 7. Non-Functional Requirements

- NFR-001: Dashboard page must load in under 3 seconds on internal network
- NFR-002: Python generation script must complete within 60 seconds
- NFR-003: Playwright test suite must complete within 2 minutes
- NFR-004: Dashboard must render correctly in Chrome and Edge (internal standard browsers)
- NFR-005: All code must be checked into the team Git repository with documented path
- NFR-006: Solution must be maintainable by a single developer with no QA team support
- NFR-007: New dashboards added in future must integrate without rewriting test framework

---

## 8. Out of Scope

- User authentication — dashboard is internal network only
- Real-time data refresh — daily batch only
- User input or filtering — read-only static view
- Mobile responsiveness — desktop only
- Backend API or database — Excel is the single source of truth

---

## 9. Assumptions

- Source Excel file path and sheet names remain stable during Phase 1
- Internal server access is available for hosting the HTML file
- Python 3.x, Playwright, and required libraries are available in the dev environment
- PMs and DRs will continue updating the Excel file daily as agreed

---

## 10. Constraints

- Single developer — no QA team, no dedicated budget
- Generated HTML files are read-only — no user interaction path
- Must use existing internal server for hosting — no cloud deployment
- GitHub Copilot is the primary AI tool for development assistance

---

## 11. Success Criteria

- SC-001: Dashboard displays current day's rollout data every working day by 1pm
- SC-002: Playwright tests pass with zero failures after every regeneration
- SC-003: Zero HIGH severity OWASP findings in generated HTML
- SC-004: All displayed values match source Excel data (validated by test suite)
- SC-005: Test scenarios, code path, and validation approach documented in the repo
- SC-006: Manager and EA Team can view the dashboard without any developer intervention

---

## 12. Risks

| Risk | Impact | Mitigation |
|---|---|---|
| Excel schema changes by PMs | High — breaks generation | Document sheet/column names, add schema validation in Python |
| New dashboards added with different structure | Medium — test coverage gaps | Three-pillar scaling strategy already designed |
| Copilot suggestions conflict with security rules | Medium — silent vulnerability | Security Tool Conflict Resolution Matrix in place |

---

## 13. Acceptance Criteria (for Developer Handover)

- [ ] Python script generates HTML from Excel without manual intervention
- [ ] JSON intermediate file produced at Package/Rollout/rllot_data.json
- [ ] HTML file produced at Package/Rollout/rllot_dashboard.html
- [ ] Playwright config.py includes rollout dashboard entry
- [ ] All three sheet tabs represented in dashboard output
- [ ] CSP header present in generated HTML
- [ ] No inline event handlers in generated HTML
- [ ] Playwright tests pass on clean run
- [ ] Screenshot baseline captured and stored
- [ ] Code path documented in repo README or test docs

