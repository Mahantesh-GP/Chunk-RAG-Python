using System.Security.Cryptography;
using System.Text;

namespace VulnDemo.Api.Utilities;

public static class CryptoUtil
{
    // VULNERABILITY 4: Hardcoded weak encryption key (3DES)
    private static readonly byte[] m_KEY = Encoding.UTF8.GetBytes("WeakKey1WeakKey2WeakKey3"); // VULNERABLE
    private static readonly byte[] m_IV  = Encoding.UTF8.GetBytes("WeakIV12");                  // VULNERABLE

    public static string Encrypt(string plainText)
    {
        // VULNERABLE: Using 3DES which is deprecated
        using var tripleDes = TripleDES.Create();
        tripleDes.Key = m_KEY;
        tripleDes.IV  = m_IV;
        var encryptor = tripleDes.CreateEncryptor();
        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string Decrypt(string cipherText)
    {
        using var tripleDes = TripleDES.Create();
        tripleDes.Key = m_KEY;
        tripleDes.IV  = m_IV;
        var decryptor = tripleDes.CreateDecryptor();
        var cipherBytes = Convert.FromBase64String(cipherText);
        var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
        return Encoding.UTF8.GetString(plainBytes);
    }
}
