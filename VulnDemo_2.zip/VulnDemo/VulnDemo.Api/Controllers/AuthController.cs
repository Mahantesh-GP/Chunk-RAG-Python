using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Models;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly string _connectionString = "Data Source=todos.db";

    // VULNERABILITY 3: Hardcoded credentials
    private const string ADMIN_USERNAME = "admin";
    private const string ADMIN_PASSWORD = "admin123"; // VULNERABLE: hardcoded

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        // VULNERABLE: Hardcoded credential check
        if (request.Username == ADMIN_USERNAME && request.Password == ADMIN_PASSWORD)
        {
            return Ok(new { token = "hardcoded-token-12345", message = "Login successful" });
        }
        return Unauthorized(new { message = "Invalid credentials" });
    }
}
