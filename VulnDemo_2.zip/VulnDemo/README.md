# VulnDemo — Vulnerability Fix Demo App

## Purpose
Demo app to test the vulnerability auto-fix tool.
Contains **4 intentional vulnerabilities** for testing.

## Vulnerabilities Included

| ID | File | Type | Severity |
|----|------|------|----------|
| V-001 | TodoController.cs | SQL Injection | Critical |
| V-002 | TodoController.cs | XSS | High |
| V-003 | AuthController.cs | Hardcoded Credentials | Critical |
| V-004 | CryptoUtil.cs | Weak 3DES Encryption | High |

## Build
```
dotnet build VulnDemo.sln
```

## Run API
```
cd VulnDemo.Api
dotnet run
```
Open: https://localhost:5001/swagger

## Run Unit Tests
```
dotnet test VulnDemo.sln
```
Expected: 8 tests (5 pass on original, 1 fails on hardcoded creds)

## Test Scenarios for the Tool

### Scenario 1 — Unit tests exist
Run fix → build → run tests → report results

### Scenario 2 — SQL Injection fix
Original: string concatenation in query
Fixed: parameterized queries

### Scenario 3 — Hardcoded credentials
Original: hardcoded in code
Fixed: read from environment/config

### Scenario 4 — No unit tests
Remove Tests project → tool should report "No unit tests found"
