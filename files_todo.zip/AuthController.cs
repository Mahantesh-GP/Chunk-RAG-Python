using Microsoft.AspNetCore.Mvc;
using VulnDemo.Api.Models;
using VulnDemo.Api.Utilities;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    // =============================================
    // VULN-003: Hardcoded Credentials
    // Severity: Critical
    // Username and password hardcoded in source code
    // =============================================
    private const string ADMIN_USERNAME = "admin";
    private const string ADMIN_PASSWORD = "Admin@1234"; // HARDCODED PASSWORD

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginModel model)
    {
        // VULNERABLE: Comparing against hardcoded credentials
        if (model.Username == ADMIN_USERNAME && model.Password == ADMIN_PASSWORD)
        {
            // =============================================
            // VULN-004: Sensitive data in response
            // Returning internal config info to client
            // =============================================
            return Ok(new
            {
                success = true,
                token = CryptoUtil.Encrypt(model.Username),
                serverInfo = Environment.MachineName, // exposing server info
                dbPath = "Data Source=vulndemo.db"    // exposing db path
            });
        }

        return Unauthorized(new { success = false, message = "Invalid credentials" });
    }
}
