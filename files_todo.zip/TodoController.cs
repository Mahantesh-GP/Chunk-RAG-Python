using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using VulnDemo.Api.Data;
using VulnDemo.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace VulnDemo.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TodoController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _config;

    public TodoController(AppDbContext context, IConfiguration config)
    {
        _context = context;
        _config = config;
    }

    // =============================================
    // VULN-001: SQL Injection
    // Severity: Critical
    // User input directly concatenated into SQL query
    // =============================================
    [HttpGet("search")]
    public IActionResult Search([FromQuery] string keyword)
    {
        var connectionString = _config.GetConnectionString("Default") 
                               ?? "Data Source=vulndemo.db";

        var results = new List<string>();
        using var connection = new SqliteConnection(connectionString);
        connection.Open();

        // VULNERABLE: Direct string concatenation - SQL Injection possible
        var sql = "SELECT Title FROM Todos WHERE Title LIKE '%" + keyword + "%'";
        using var command = new SqliteCommand(sql, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
            results.Add(reader.GetString(0));

        return Ok(results);
    }

    // Safe CRUD using EF Core
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var todos = await _context.Todos.ToListAsync();
        return Ok(todos);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var todo = await _context.Todos.FindAsync(id);
        if (todo == null) return NotFound();
        return Ok(todo);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] TodoItem item)
    {
        // =============================================
        // VULN-002: XSS - No input sanitization
        // User supplied HTML/script stored directly
        // =============================================
        _context.Todos.Add(item);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = item.Id }, item);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] TodoItem item)
    {
        var existing = await _context.Todos.FindAsync(id);
        if (existing == null) return NotFound();
        existing.Title = item.Title;
        existing.Description = item.Description;
        existing.IsComplete = item.IsComplete;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var todo = await _context.Todos.FindAsync(id);
        if (todo == null) return NotFound();
        _context.Todos.Remove(todo);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
