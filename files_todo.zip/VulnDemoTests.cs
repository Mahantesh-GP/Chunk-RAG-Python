using Microsoft.EntityFrameworkCore;
using VulnDemo.Api.Data;
using VulnDemo.Api.Models;
using VulnDemo.Api.Controllers;
using VulnDemo.Api.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace VulnDemo.Tests;

// =============================================
// Tests for TodoController
// =============================================
public class TodoControllerTests
{
    private AppDbContext GetInMemoryDb()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        return new AppDbContext(options);
    }

    private IConfiguration GetConfig()
    {
        var inMemorySettings = new Dictionary<string, string>
        {
            { "ConnectionStrings:Default", "Data Source=:memory:" }
        };
        return new ConfigurationBuilder()
            .AddInMemoryCollection(inMemorySettings!)
            .Build();
    }

    [Fact]
    public async Task GetAll_ReturnsEmptyList_WhenNoTodos()
    {
        // Arrange
        var db = GetInMemoryDb();
        var controller = new TodoController(db, GetConfig());

        // Act
        var result = await controller.GetAll();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var items = Assert.IsAssignableFrom<IEnumerable<TodoItem>>(okResult.Value);
        Assert.Empty(items);
    }

    [Fact]
    public async Task Create_AddsTodoItem_Successfully()
    {
        // Arrange
        var db = GetInMemoryDb();
        var controller = new TodoController(db, GetConfig());
        var newItem = new TodoItem
        {
            Title = "Test Todo",
            Description = "Test Description",
            IsComplete = false,
            CreatedBy = "TestUser"
        };

        // Act
        var result = await controller.Create(newItem);

        // Assert
        var createdResult = Assert.IsType<CreatedAtActionResult>(result);
        var item = Assert.IsType<TodoItem>(createdResult.Value);
        Assert.Equal("Test Todo", item.Title);
    }

    [Fact]
    public async Task GetById_ReturnsTodo_WhenExists()
    {
        // Arrange
        var db = GetInMemoryDb();
        var todo = new TodoItem { Title = "Find Me", Description = "Test", CreatedBy = "User" };
        db.Todos.Add(todo);
        await db.SaveChangesAsync();

        var controller = new TodoController(db, GetConfig());

        // Act
        var result = await controller.GetById(todo.Id);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var item = Assert.IsType<TodoItem>(okResult.Value);
        Assert.Equal("Find Me", item.Title);
    }

    [Fact]
    public async Task GetById_ReturnsNotFound_WhenNotExists()
    {
        // Arrange
        var db = GetInMemoryDb();
        var controller = new TodoController(db, GetConfig());

        // Act
        var result = await controller.GetById(999);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Update_ModifiesTodo_Successfully()
    {
        // Arrange
        var db = GetInMemoryDb();
        var todo = new TodoItem { Title = "Old Title", Description = "Old", CreatedBy = "User" };
        db.Todos.Add(todo);
        await db.SaveChangesAsync();

        var controller = new TodoController(db, GetConfig());
        var updated = new TodoItem { Title = "New Title", Description = "New", IsComplete = true };

        // Act
        var result = await controller.Update(todo.Id, updated);

        // Assert
        Assert.IsType<NoContentResult>(result);
        var dbItem = await db.Todos.FindAsync(todo.Id);
        Assert.Equal("New Title", dbItem!.Title);
        Assert.True(dbItem.IsComplete);
    }

    [Fact]
    public async Task Delete_RemovesTodo_Successfully()
    {
        // Arrange
        var db = GetInMemoryDb();
        var todo = new TodoItem { Title = "Delete Me", Description = "Test", CreatedBy = "User" };
        db.Todos.Add(todo);
        await db.SaveChangesAsync();

        var controller = new TodoController(db, GetConfig());

        // Act
        var result = await controller.Delete(todo.Id);

        // Assert
        Assert.IsType<NoContentResult>(result);
        Assert.Null(await db.Todos.FindAsync(todo.Id));
    }
}

// =============================================
// Tests for CryptoUtil
// =============================================
public class CryptoUtilTests
{
    [Fact]
    public void Encrypt_ReturnsNonEmptyString()
    {
        // Act
        var result = CryptoUtil.Encrypt("testuser");

        // Assert
        Assert.NotEmpty(result);
        Assert.NotEqual("testuser", result);
    }

    [Fact]
    public void Decrypt_ReturnsOriginalString()
    {
        // Arrange
        var original = "testuser";
        var encrypted = CryptoUtil.Encrypt(original);

        // Act
        var decrypted = CryptoUtil.Decrypt(encrypted);

        // Assert
        Assert.Equal(original, decrypted);
    }
}

// =============================================
// Tests for AuthController
// =============================================
public class AuthControllerTests
{
    [Fact]
    public void Login_ReturnsOk_WithValidCredentials()
    {
        // Arrange
        var controller = new AuthController();
        var model = new LoginModel { Username = "admin", Password = "Admin@1234" };

        // Act
        var result = controller.Login(model);

        // Assert
        Assert.IsType<OkObjectResult>(result);
    }

    [Fact]
    public void Login_ReturnsUnauthorized_WithInvalidCredentials()
    {
        // Arrange
        var controller = new AuthController();
        var model = new LoginModel { Username = "hacker", Password = "wrong" };

        // Act
        var result = controller.Login(model);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result);
    }
}
