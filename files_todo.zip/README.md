# VulnDemo — Vulnerability Demo App for EA Team

## Purpose
This is a small .NET 8 Web API created to demonstrate and test the 
**AI-powered vulnerability detection and auto-fix tool**.

---

## Project Structure

```
VulnDemo/
├── VulnDemo.Api/                  ← Main Web API
│   ├── Controllers/
│   │   ├── TodoController.cs      ← VULN-001 (SQL Injection), VULN-002 (XSS)
│   │   └── AuthController.cs      ← VULN-003 (Hardcoded Credentials), VULN-004 (Info Exposure)
│   ├── Utilities/
│   │   └── CryptoUtil.cs          ← VULN-005 (Weak Encryption / Hardcoded Key)
│   ├── Models/TodoItem.cs
│   ├── Data/AppDbContext.cs
│   └── Program.cs
├── VulnDemo.Tests/
│   └── VulnDemoTests.cs           ← Unit tests (xUnit)
└── VulnDemo.sln
```

---

## Intentional Vulnerabilities

| ID | File | Line | Type | Severity |
|----|------|------|------|----------|
| VULN-001 | TodoController.cs | ~35 | SQL Injection | Critical |
| VULN-002 | TodoController.cs | ~60 | XSS - No Input Sanitization | High |
| VULN-003 | AuthController.cs | ~12 | Hardcoded Credentials | Critical |
| VULN-004 | AuthController.cs | ~27 | Sensitive Data Exposure | High |
| VULN-005 | CryptoUtil.cs | ~13 | Weak 3DES + Hardcoded Key/IV | High |

---

## Setup & Run Locally

### Prerequisites
- .NET 8 SDK
- Visual Studio 2022 or VS Code

### Build
```bash
dotnet build VulnDemo.sln
```

### Run API
```bash
cd VulnDemo.Api
dotnet run
```
Open: https://localhost:5001/swagger

### Run Unit Tests
```bash
dotnet test VulnDemo.sln
```

Expected: **8 tests pass**

---

## Test Scenarios for the Tool

### Scenario 1 — With Unit Tests (SQL Injection)
- File: `TodoController.cs`
- Tool should: Fix SQL injection → Build → Run tests → Report pass

### Scenario 2 — Without Unit Tests (Hardcoded Password)
- File: `AuthController.cs`  
- Tool should: Fix hardcoded creds → Build → Report "no unit tests for this file"

### Scenario 3 — Crypto Fix
- File: `CryptoUtil.cs`
- Tool should: Replace 3DES with AES → Build → Run CryptoUtil tests → Report

---

## Expected Tool Behavior (Loop)

```
1. Scan → Find vulnerabilities
2. Fix using LLM
3. dotnet build → if FAILED → go back to step 2
4. dotnet test → report results
5. If no tests → report "No unit tests found"
6. Generate comparison report
```
