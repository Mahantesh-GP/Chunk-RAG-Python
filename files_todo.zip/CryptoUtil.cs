using System.Security.Cryptography;
using System.Text;

namespace VulnDemo.Api.Utilities;

public static class CryptoUtil
{
    // =============================================
    // VULN-005: Weak Encryption - Hardcoded 3DES Key/IV
    // Severity: High
    // 3DES is deprecated. Key and IV hardcoded in source.
    // =============================================
    private static readonly byte[] KEY = Encoding.UTF8.GetBytes("VulnDemoKey12345VulnDemo"); // 24 bytes
    private static readonly byte[] IV  = Encoding.UTF8.GetBytes("VulnDemo");                 // 8 bytes

    public static string Encrypt(string plainText)
    {
        // VULNERABLE: Using 3DES (deprecated) with hardcoded key
#pragma warning disable SYSLIB0021
        using var tripleDes = TripleDES.Create();
#pragma warning restore SYSLIB0021
        tripleDes.Key = KEY;
        tripleDes.IV = IV;

        var encryptor = tripleDes.CreateEncryptor();
        var inputBytes = Encoding.UTF8.GetBytes(plainText);
        var encryptedBytes = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string Decrypt(string cipherText)
    {
#pragma warning disable SYSLIB0021
        using var tripleDes = TripleDES.Create();
#pragma warning restore SYSLIB0021
        tripleDes.Key = KEY;
        tripleDes.IV = IV;

        var decryptor = tripleDes.CreateDecryptor();
        var inputBytes = Convert.FromBase64String(cipherText);
        var decryptedBytes = decryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
        return Encoding.UTF8.GetString(decryptedBytes);
    }
}
