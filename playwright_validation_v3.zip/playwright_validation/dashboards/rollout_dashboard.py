"""
dashboards/rollout_dashboard.py
================================
End-to-end UI validation for GHCP Rollout Dashboard.
Based on: build_rllot_dashboard.py

Manager direction:
  - UI layer is sufficient for this application
  - Extend daily sync with this validation
  - Scenarios are limited — keep it simple
  - Sustainable, not manual, not time consuming

Covers:
  1.  Page Load          — opens without errors
  2.  Page Structure     — title, CSP, all tab panels exist
  3.  Overview Tab       — KPI cards, initiative cards, donuts
  4.  Initiative Tabs    — each opens, has phase cards, tables, filters
  5.  Filters            — org, dr, pm, status, overdue, search, reset
  6.  Drawer             — detail button opens with content
  7.  Collapsible        — org breakdown toggles
  8.  Timeline Tab       — opens, filters work, grid has content
  9.  Security           — CSP, XSS, eval, hash
  10. Screenshot         — visual proof saved
"""

from pathlib import Path
from playwright.sync_api import Page

from common.security_checks import run_all_security_checks
from common.report import Report

SHEETS = {
    "BackEnd_Unit_Testing"  : "Backend Unit Testing",
    "Gen_Test_Case"         : "Generate Test Cases",
    "Gen_Scripts_4_PostMan" : "Generate PostMan Scripts",
}

PHASES = ["p1", "p2", "p3"]


def validate(page: Page, config: dict) -> bool:
    report    = Report(config["name"])
    html_path = config["html_path"]

    page.goto(f"file:///{html_path.resolve()}")
    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(800)
    html = page.content()

    # ── 1. Page Load ──────────────────────────────────────────────────────────
    report.add_section("1 — Page Load")

    js_errors = []
    page.on("console", lambda m: js_errors.append(m.text) if m.type == "error" else None)
    page.wait_for_timeout(500)

    report.add_result("1 — Page Load",
        len(js_errors) == 0,
        "No JS errors on load" if not js_errors else f"JS errors: {js_errors[:2]}")

    report.add_result("1 — Page Load",
        len(html) > 5000,
        f"Page has content ({len(html):,} chars)")

    report.add_result("1 — Page Load",
        "GenAI SDLC" in html or "Roll-Out" in html or "Rollout" in html,
        "Dashboard title present")

    # ── 2. Page Structure ─────────────────────────────────────────────────────
    report.add_section("2 — Page Structure")

    csp = page.locator("meta[http-equiv='Content-Security-Policy']")
    report.add_result("2 — Page Structure", csp.count() > 0, "CSP meta tag present")

    tab_btns = page.locator(".tab-btn")
    report.add_result("2 — Page Structure",
        tab_btns.count() >= 5,
        f"Tab buttons: {tab_btns.count()} (expected >= 5)")

    report.add_result("2 — Page Structure",
        page.locator(".tab-btn.active[data-tab='overview']").count() > 0,
        "Overview tab active on load")

    report.add_result("2 — Page Structure",
        page.locator("#tab-overview").is_visible(),
        "Overview panel visible on load")

    for key, label in SHEETS.items():
        report.add_result("2 — Page Structure",
            page.locator(f"#tab-{key}").count() > 0,
            f"Tab panel in DOM: {label}")

    report.add_result("2 — Page Structure",
        page.locator("#tab-timeline").count() > 0,
        "Timeline panel in DOM")

    # ── 3. Overview Tab ───────────────────────────────────────────────────────
    report.add_section("3 — Overview Tab")

    kpi_boxes = page.locator("#tab-overview .kpi-box")
    report.add_result("3 — Overview Tab",
        kpi_boxes.count() >= 7,
        f"KPI cards: {kpi_boxes.count()} (expected >= 7)")

    kpi_vals = page.locator("#tab-overview .kpi-val")
    blanks   = sum(1 for i in range(kpi_vals.count())
                   if kpi_vals.nth(i).inner_text().strip() in ("", "—"))
    report.add_result("3 — Overview Tab", blanks == 0,
        f"All KPI values populated (blank: {blanks})")

    ov_cards = page.locator(".ov-card")
    report.add_result("3 — Overview Tab",
        ov_cards.count() == len(SHEETS),
        f"Initiative cards: {ov_cards.count()} (expected {len(SHEETS)})")

    report.add_result("3 — Overview Tab",
        page.locator("#tab-overview .donut-svg").count() > 0,
        "Donut charts present in overview")

    report.add_result("3 — Overview Tab",
        page.locator(".overall-ring").count() > 0,
        "Overall progress ring present")

    report.add_result("3 — Overview Tab",
        "Initiative Summary" in html,
        "Initiative Summary section present")

    # ── 4. Initiative Tabs ────────────────────────────────────────────────────
    report.add_section("4 — Initiative Tabs")

    for key, label in SHEETS.items():

        # Navigate via tab button
        page.locator(f".tab-btn[data-tab='{key}']").click()
        page.wait_for_timeout(500)
        panel = page.locator(f"#tab-{key}")

        report.add_result("4 — Initiative Tabs",
            panel.is_visible(), f"{label} — tab visible after click")

        # Phase cards
        for ph in PHASES:
            report.add_result("4 — Initiative Tabs",
                page.locator(f"#pc-{key}-{ph}").count() > 0,
                f"{label} — phase card {ph}")

        # Donut text not empty
        for ph in PHASES:
            el = page.locator(f"#dtxt-{key}-{ph}")
            report.add_result("4 — Initiative Tabs",
                el.count() > 0 and el.inner_text().strip() != "",
                f"{label} — donut % {ph} not empty")

        # Stacked bars
        for ph in PHASES:
            report.add_result("4 — Initiative Tabs",
                page.locator(f"#pbar-{key}-{ph}").count() > 0,
                f"{label} — stacked bar {ph}")

        # Filter bar
        report.add_result("4 — Initiative Tabs",
            panel.locator(".filter-bar").count() > 0,
            f"{label} — filter bar present")

        # Org table with rows
        org_rows = page.locator(f"#orgt-{key} tbody tr")
        report.add_result("4 — Initiative Tabs",
            org_rows.count() > 0,
            f"{label} — org table: {org_rows.count()} rows")

        # Detail table with rows
        det_rows = page.locator(f"#dt-{key} tbody tr")
        report.add_result("4 — Initiative Tabs",
            det_rows.count() > 0,
            f"{label} — detail table: {det_rows.count()} rows")

        # Detail buttons
        d_btns = panel.locator(".detail-btn")
        report.add_result("4 — Initiative Tabs",
            d_btns.count() > 0,
            f"{label} — {d_btns.count()} detail buttons")

        # Remarks tooltip cells exist
        report.add_result("4 — Initiative Tabs",
            panel.locator(".rem-tip").count() > 0
            or panel.locator(".rem-empty").count() > 0,
            f"{label} — remarks cells present")

        # Back to overview
        page.locator(".tab-btn[data-tab='overview']").click()
        page.wait_for_timeout(300)

    # ── 5. Filters ────────────────────────────────────────────────────────────
    report.add_section("5 — Filters")

    first_key = list(SHEETS.keys())[0]
    page.locator(f".tab-btn[data-tab='{first_key}']").click()
    page.wait_for_timeout(400)

    def test_filter(attr, label, value=None, use_index=False):
        try:
            sel = page.locator(f"#tab-{first_key} .f-sel[data-attr='{attr}']")
            if sel.count() == 0:
                report.add_result("5 — Filters", False, f"{label} filter not found")
                return
            opts = sel.locator("option").count()
            report.add_result("5 — Filters", opts > 1,
                f"{label} filter: {opts} options")
            if opts > 1:
                if use_index:
                    sel.select_option(index=1)
                elif value:
                    sel.select_option(value=value)
                page.wait_for_timeout(400)
                vis = page.locator(f"#dt-{first_key} tbody tr:visible").count()
                report.add_result("5 — Filters", True,
                    f"{label} filter applied: {vis} rows visible")
        except Exception as e:
            report.add_result("5 — Filters", False, f"{label} error: {e}")

    test_filter("org",     "Org",     use_index=True)
    test_filter("dr",      "DR",      use_index=True)
    test_filter("pm",      "PM",      use_index=True)
    test_filter("status",  "Status",  value="Completed")
    test_filter("overdue", "Overdue", value="yes")

    # Search
    try:
        search = page.locator(f"#tab-{first_key} .f-search")
        if search.count() > 0:
            search.fill("a")
            page.wait_for_timeout(400)
            cnt = page.locator(f"#tab-{first_key} .f-counts")
            report.add_result("5 — Filters", True,
                f"Search works — counts: {cnt.inner_text().strip()[:40]}")
    except Exception as e:
        report.add_result("5 — Filters", False, f"Search error: {e}")

    # Reset
    try:
        reset = page.locator(f"#tab-{first_key} .f-reset")
        if reset.count() > 0:
            reset.click()
            page.wait_for_timeout(400)
            total = page.locator(f"#dt-{first_key} tbody tr:visible").count()
            report.add_result("5 — Filters", total > 0,
                f"Reset restores rows: {total} visible")
    except Exception as e:
        report.add_result("5 — Filters", False, f"Reset error: {e}")

    # ── 6. Drawer ─────────────────────────────────────────────────────────────
    report.add_section("6 — Drawer")

    report.add_result("6 — Drawer",
        page.locator("#sd-title").count() > 0, "Drawer title element in DOM")
    report.add_result("6 — Drawer",
        page.locator("#sd-sub").count() > 0, "Drawer sub element in DOM")
    report.add_result("6 — Drawer",
        page.locator("#sd-body").count() > 0, "Drawer body element in DOM")
    report.add_result("6 — Drawer",
        page.locator("#shared-overlay").count() > 0, "Drawer overlay in DOM")

    try:
        btn = page.locator(".detail-btn").first
        if btn.count() > 0:
            btn.click()
            page.wait_for_timeout(700)

            drawer = page.locator("#shared-drawer, .detail-drawer")
            cls    = drawer.first.get_attribute("class") or ""
            report.add_result("6 — Drawer",
                "open" in cls or drawer.first.is_visible(),
                "Drawer opens on detail button click")

            title = page.locator("#sd-title").inner_text().strip()
            report.add_result("6 — Drawer",
                title != "", f"Drawer title: '{title[:40]}'")

            body_text = page.locator("#sd-body").inner_text().strip()
            report.add_result("6 — Drawer",
                len(body_text) > 10, "Drawer body has content")

            report.add_result("6 — Drawer",
                page.locator(".drawer-phases").count() > 0
                or "Phase 1" in body_text,
                "Phase info in drawer")

            report.add_result("6 — Drawer",
                page.locator(".drawer-grid").count() > 0,
                "Drawer grid (PM/DR/Members) present")

            # Close via overlay
            overlay = page.locator("#shared-overlay")
            if overlay.is_visible():
                overlay.click()
                page.wait_for_timeout(400)
    except Exception as e:
        report.add_result("6 — Drawer", False, f"Drawer error: {e}")

    # ── 7. Collapsible ────────────────────────────────────────────────────────
    report.add_section("7 — Collapsible")

    try:
        col = page.locator(f"#tab-{first_key} .sec-collapsible").first
        if col.count() > 0:
            was_open = col.get_attribute("open") is not None
            col.locator("summary").click()
            page.wait_for_timeout(300)
            is_open = col.get_attribute("open") is not None
            report.add_result("7 — Collapsible",
                was_open != is_open, "Collapsible toggles on click")
            col.locator("summary").click()
            page.wait_for_timeout(200)
        else:
            report.add_result("7 — Collapsible", False, "No collapsible found")
    except Exception as e:
        report.add_result("7 — Collapsible", False, f"Collapsible error: {e}")

    # ── 8. Timeline Tab ───────────────────────────────────────────────────────
    report.add_section("8 — Timeline Tab")

    tl_btn = page.locator(".tab-btn[data-tab='timeline']")
    if tl_btn.count() > 0:
        tl_btn.click()
        page.wait_for_timeout(600)

        report.add_result("8 — Timeline Tab",
            page.locator("#tab-timeline").is_visible(),
            "Timeline tab opens on click")

        report.add_result("8 — Timeline Tab",
            "Activity Timeline" in html,
            "Activity Timeline heading present")

        report.add_result("8 — Timeline Tab",
            page.locator("#tl-monthly-btn").count() > 0,
            "Monthly view button present")

        # Month multi-select button
        ms_btn = page.locator("#ms-month .ms-btn")
        report.add_result("8 — Timeline Tab",
            ms_btn.count() > 0, "Month filter button present")

        try:
            if ms_btn.count() > 0:
                ms_btn.click()
                page.wait_for_timeout(300)
                ms_panel = page.locator("#ms-month-panel")
                report.add_result("8 — Timeline Tab",
                    ms_panel.is_visible(), "Month panel opens")
                ms_btn.click()
                page.wait_for_timeout(200)
        except Exception as e:
            report.add_result("8 — Timeline Tab", False, f"Month panel: {e}")

        # Phase filter
        report.add_result("8 — Timeline Tab",
            page.locator("#ms-phase .ms-btn").count() > 0,
            "Phase filter button present")

        # Status filter
        report.add_result("8 — Timeline Tab",
            page.locator("#ms-tl-status .ms-btn").count() > 0,
            "Status filter button present")

        # DR / PM / Overdue dropdowns
        for fid, lbl in [("tl-f-dr","DR"), ("tl-f-pm","PM"), ("tl-f-od","Overdue")]:
            report.add_result("8 — Timeline Tab",
                page.locator(f"#{fid}").count() > 0,
                f"Timeline {lbl} filter present")

        # Reset button
        report.add_result("8 — Timeline Tab",
            page.locator("#tl-reset-btn").count() > 0,
            "Timeline reset button present")

        # Grid has content
        tl_grid = page.locator("#tl-monthly")
        report.add_result("8 — Timeline Tab",
            tl_grid.count() > 0 and len(tl_grid.inner_text().strip()) > 0,
            "Timeline grid has content")

        # Overdue filter works
        try:
            page.locator("#tl-f-od").select_option(value="yes")
            page.wait_for_timeout(400)
            report.add_result("8 — Timeline Tab",
                True, "Timeline overdue filter works")
            page.locator("#tl-reset-btn").click()
            page.wait_for_timeout(300)
        except Exception as e:
            report.add_result("8 — Timeline Tab", False, f"TL overdue: {e}")

    else:
        report.add_result("8 — Timeline Tab", False, "Timeline tab button not found")

    # ── 9. Security ───────────────────────────────────────────────────────────
    report.add_section("9 — Security")
    report.add_results("9 — Security", run_all_security_checks(page))

    if csp.count() > 0:
        csp_val = csp.get_attribute("content") or ""
        report.add_result("9 — Security",
            "sha256-" in csp_val,
            "CSP uses script hash")
        report.add_result("9 — Security",
            "frame-ancestors" in csp_val,
            "CSP has frame-ancestors")
        report.add_result("9 — Security",
            "unsafe-inline" not in csp_val.split("script-src")[1].split(";")[0]
            if "script-src" in csp_val else True,
            "No unsafe-inline in script-src")

    # ── 10. Screenshot ────────────────────────────────────────────────────────
    page.locator(".tab-btn[data-tab='overview']").click()
    page.wait_for_timeout(400)

    screenshot_dir = Path(__file__).parent.parent / "screenshots"
    screenshot_dir.mkdir(exist_ok=True)
    page.screenshot(
        path=screenshot_dir / "rollout_dashboard.png",
        full_page=True
    )
    report.add_section("10 — Screenshot")
    report.add_result("10 — Screenshot",
        True, "Saved → screenshots/rollout_dashboard.png")

    return report.print_and_save()
