# GitHub Copilot Adoption Dashboard

> Track GenAI SDLC Phase 1 rollout progress, gaps, and adoption status across all teams

---

## Purpose

Replaces manual Excel tracking by 35-40 managers.
Provides a consistent org-level view of Copilot adoption impact
at ADM, ER, and manager levels during production rollout.

---

## Team Responsibilities

| Role          | Responsible      |
|---------------|------------------|
| Builder       | [Developer name] |
| Validator     | [Developer name] |
| Deployer      | [Developer name] |
| Maintainer    | EA Team          |

> Ownership is team-based — not individual dependent.

---

## Data Source

| Item            | Detail                                      |
|-----------------|---------------------------------------------|
| File            | GenAI SDLC Initiatives - Phase 1 Roll Out Tracker.xlsx |
| Updated by      | PMs and DRs — each updates their own rows   |
| Consolidated by | EA Team                                     |

---

## Refresh Frequency

Daily between 11:00am to 1:00pm — EA Team consolidates and regenerates.

---

## Code Path

| Item             | Path                                              |
|------------------|---------------------------------------------------|
| Generator script | Package/Copilot/generate_copilot_dashboard.py     |
| Excel data       | Package/Copilot/data/copilot_data.xlsx            |
| Output HTML      | Package/Copilot/output/copilot_dashboard.html     |
| Repository       | [Git repo URL or name]                            |

---

## Deployment

| Item                  | Detail            |
|-----------------------|-------------------|
| Environment           | Internal Server   |
| Server path           | [server path]     |
| Deployed by           | EA Team           |
| Stakeholders notified | Yes — via Teams   |

---

## ADO Work Item

| Item      | Detail                   |
|-----------|--------------------------|
| Epic      | [Epic ID]                |
| Feature   | [Feature ID]             |
| Area path | [Azure DevOps area path] |

---

## Team Communication

| Event             | How                          |
|-------------------|------------------------------|
| New deployment    | Teams — EA Dashboard channel |
| Bug fix deployed  | Teams — tag relevant members |
| Enhancement added | Teams + ADO work item update |

---

## Validation Scenarios

> Developer must complete all scenarios before every deployment.
> Mark each Pass or Fail in the sign-off table at the bottom.
> Do not deploy if any scenario fails.
> Current method: Manual | Automation planned via validation_agent

---

### Scenario 1 — Core Logic Validation

**What to check:** KPI values in dashboard match Excel source data.

**Steps:**
1. Open Excel file — note total number of rows
2. Count how many rows show each status value
3. Calculate adoption rate independently
4. Open generated HTML in browser
5. Compare each KPI card value against your Excel calculations

**Expected result:**
- Total count matches Excel row count
- Status breakdown counts match Excel
- Adoption rate matches calculated value

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 2 — Key Visuals Validation

**What to check:** All charts, tables and UI elements render correctly.

**Steps:**
1. Open generated HTML in browser
2. Verify title "GitHub Copilot" visible in header
3. Verify all navigation tabs exist and load without error
4. Verify all KPI cards visible and not blank
5. Verify charts show data — not blank
6. Verify tables have data rows
7. Verify filters and dropdowns visible and clickable

**Expected result:**
- All tabs load without error
- All KPI cards show values
- Charts visible with data
- Tables have data rows

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 3 — Data Correctness Validation

**What to check:** Data in dashboard accurately reflects Excel source.

**Steps:**
1. Open Excel file
2. Note 5 manager or team names from the file
3. Open generated HTML dashboard
4. Find each of those names in the dashboard
5. Verify values shown match Excel

**Expected result:**
- All key records appear in dashboard
- Values match Excel source
- No data missing

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 4 — Access and Security Validation

**What to check:** No security vulnerabilities in generated HTML.

**Steps:**
1. Open generated HTML in text editor
2. Search for `Content-Security-Policy` — verify exists
3. Check CSP — confirm no `unsafe-inline`
4. Search for `onclick=`, `onerror=`, `onload=` — verify none found
5. Search for `javascript:` — verify not found in href
6. Search for `eval(` — verify not found in scripts
7. Open browser DevTools (F12) → Console → reload — no red errors

**Expected result:**
- CSP meta tag present
- No unsafe-inline
- No inline event handlers
- No eval() in scripts
- No console errors

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 5 — Regression Check (After Fix or Enhancement)

**What to check:** Recent change has not broken anything working before.

**Steps:**
1. Note what was changed
2. Run Scenarios 1 to 4 in full
3. Test the specific area that was changed
4. Compare with last known good state

**Expected result:**
- All scenarios 1–4 pass
- Specific fix works
- Nothing previously working is broken

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

## Validation Sign-off

| Scenario                       | Pass / Fail | Checked by | Date |
|--------------------------------|-------------|------------|------|
| 1 — Core Logic                 |             |            |      |
| 2 — Key Visuals                |             |            |      |
| 3 — Data Correctness           |             |            |      |
| 4 — Access and Security        |             |            |      |
| 5 — Regression (if applicable) |             |            |      |

> All must show **Pass** before deploying.

---

## Maintenance

All changes follow: **Understand → Track → Build → Validate → Deploy**

| Type               | Example                    | ADO Item |
|--------------------|----------------------------|----------|
| Bug fix            | Wrong adoption rate        | Yes      |
| Vulnerability fix  | Security patches           | Yes      |
| Enhancement        | New metric added           | Yes      |
| Data source change | New column in Excel        | Yes      |

---

## Change History

| Date     | Change             | Done by | ADO Item |
|----------|--------------------|---------|----------|
| Apr 2026 | Initial deployment | EA Team | [ID]     |

---

*Last updated: April 2026 | Owner: EA Team*
