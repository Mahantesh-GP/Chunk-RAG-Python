# [Dashboard Name]

> [One line — what this dashboard tracks or measures]

---

## Purpose

[Describe what problem this dashboard solves and who benefits from it.]

---

## Team Responsibilities

| Role          | Responsible      |
|---------------|------------------|
| Builder       | [Developer name] |
| Validator     | [Developer name] |
| Deployer      | [Developer name] |
| Maintainer    | [Team name]      |

> Ownership is team-based — not individual dependent.

---

## Data Source

| Item            | Detail                        |
|-----------------|-------------------------------|
| Type            | Excel / Database / API        |
| File / Table    | [file name or table name]     |
| Sheets          | [sheet names if Excel]        |
| Updated by      | [who updates the source data] |
| Consolidated by | [who consolidates]            |

---

## Refresh Frequency

[Daily / Weekly / Monthly / On Demand — add timing if fixed e.g. Daily between 11am–1pm]

---

## Code Path

| Item             | Path                                 |
|------------------|--------------------------------------|
| Generator script | [path to Python script]              |
| Data source      | [path to Excel or connection string] |
| JSON output      | [path if JSON step exists, else N/A] |
| HTML output      | [path to generated HTML]             |
| Repository       | [Git repo URL or name]               |

---

## Deployment

| Item                  | Detail                    |
|-----------------------|---------------------------|
| Environment           | [Internal Server / Azure] |
| Server path           | [path on server]          |
| Deployed by           | [Developer / Team]        |
| Stakeholders notified | Yes / No                  |

---

## ADO Work Item

| Item      | Detail                   |
|-----------|--------------------------|
| Epic      | [Epic ID]                |
| Feature   | [Feature ID]             |
| Area path | [Azure DevOps area path] |

---

## Team Communication

| Event             | How                       |
|-------------------|---------------------------|
| New deployment    | [Teams / Email / Both]    |
| Bug fix deployed  | [Teams / Email / Both]    |
| Enhancement added | [Teams + ADO work item]   |

---

## Validation Scenarios

> Developer must complete all scenarios before every deployment.
> Mark each Pass or Fail in the sign-off table at the bottom.
> Do not deploy if any scenario fails.
> Current method: Manual | Update to Automated when recurring

---

### Scenario 1 — Core Logic Validation

**What to check:** KPI values and calculations in dashboard match source data.

**Steps:**
1. Open source data file — [Excel / database / API]
2. Calculate each KPI independently:
   - [KPI 1 name] = [how to calculate from raw data]
   - [KPI 2 name] = [how to calculate from raw data]
   - [Add more as needed]
3. Open generated HTML in browser
4. Compare each KPI shown in dashboard against your calculations

**Expected result:**
- [KPI 1] matches calculated value
- [KPI 2] matches calculated value
- All totals add up correctly

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 2 — Key Visuals Validation

**What to check:** All charts, tables, tabs and UI elements render correctly.

**Steps:**
1. Open generated HTML in browser
2. Verify dashboard title is visible
3. Verify all navigation tabs exist and each loads without error
4. Verify all KPI cards are visible and not blank
5. Verify all charts show data — not blank or broken
6. Verify all tables have data rows
7. Verify all filters and dropdowns are visible and clickable

**Expected result:**
- All tabs load without error
- All KPI cards show values — nothing blank
- All charts visible with data
- All tables have data rows
- All filters work

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 3 — Data Correctness Validation

**What to check:** Data shown in dashboard accurately reflects source data.

**Steps:**
1. Open source data — [Excel / database]
2. Note down [5–10] key records — names, values, dates
3. Open generated HTML dashboard
4. Find each of those records in the dashboard
5. Verify values shown match source data

**Expected result:**
- All key records from source appear in dashboard
- Values shown match source data
- No data missing or truncated

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 4 — Access and Security Validation

**What to check:** No security vulnerabilities in generated HTML.

**Steps:**
1. Open generated HTML file in text editor
2. Search for `Content-Security-Policy` — verify it exists in meta tags
3. Check CSP — confirm no `unsafe-inline`
4. Search for `onclick=`, `onerror=`, `onload=` — verify none found
5. Search for `javascript:` in href — verify not found
6. Search for `eval(` — verify not found in scripts
7. Open browser DevTools (F12) → Console → reload — verify no red errors

**Expected result:**
- CSP meta tag present
- No unsafe-inline in CSP
- No inline event handlers
- No javascript: in href
- No eval() in scripts
- No console errors

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 5 — Regression Check (After Fix or Enhancement)

**What to check:** Recent change has not broken anything that was working before.

**Steps:**
1. Note what was changed — specific fix or enhancement
2. Run Scenarios 1 to 4 in full
3. Specifically test the area that was changed
4. Compare with last known good state

**Expected result:**
- All scenarios 1–4 still pass
- Specific fix works correctly
- Nothing previously working is now broken

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

## Validation Sign-off

Complete before every deployment:

| Scenario                       | Pass / Fail | Checked by | Date |
|--------------------------------|-------------|------------|------|
| 1 — Core Logic                 |             |            |      |
| 2 — Key Visuals                |             |            |      |
| 3 — Data Correctness           |             |            |      |
| 4 — Access and Security        |             |            |      |
| 5 — Regression (if applicable) |             |            |      |

> All must show **Pass** before deploying.

---

## Maintenance

All changes follow: **Understand → Track → Build → Validate → Deploy**

| Type               | Example           | ADO Item |
|--------------------|-------------------|----------|
| Bug fix            | [example]         | Yes      |
| Vulnerability fix  | [example]         | Yes      |
| Enhancement        | [example]         | Yes      |
| Data source change | [example]         | Yes      |

---

## Change History

| Date | Change | Done by | ADO Item |
|------|--------|---------|----------|
|      |        |         |          |

---

*Last updated: [Date] | Owner: [Team]*
