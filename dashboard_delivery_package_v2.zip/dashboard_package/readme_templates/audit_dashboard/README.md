# Audit Dashboard

> Track GenAI SDLC Phase 1 rollout progress, gaps, and adoption status across all teams

---

## Purpose

This dashboard tracks and measures the outcome of the GitHub Copilot adoption initiative
across all projects at ADM, ER, and manager levels.

It provides PMO team with a consistent org-level view of audit scores,
non-conformances, opportunities, and quarterly trends.

---

## Team Responsibilities

| Role          | Responsible      |
|---------------|------------------|
| Builder       | [Developer name] |
| Validator     | [Developer name] |
| Deployer      | [Developer name] |
| Maintainer    | EA Team          |

> Ownership is team-based — not individual dependent.

---

## Data Source

| Item            | Detail                          |
|-----------------|---------------------------------|
| File            | audit_data.xlsx                 |
| Sheets          | Projects, Ratings, Instructions |
| Updated by      | Managers                        |
| Consolidated by | EA Team                         |

---

## Refresh Frequency

Daily — Python script reads updated Excel and generates HTML.

---

## Code Path

| Item             | Path                                          |
|------------------|-----------------------------------------------|
| Generator script | Package/Audit/generate_audit_dashboard.py     |
| Excel data       | Package/Audit/data/audit_data.xlsx            |
| Output HTML      | Package/Audit/output/audit_q1_2026.html       |
| Repository       | [Git repo URL or name]                        |

---

## Deployment

| Item                  | Detail            |
|-----------------------|-------------------|
| Environment           | Internal Server   |
| Server path           | [server path]     |
| Deployed by           | EA Team           |
| Stakeholders notified | Yes — via Teams   |

---

## ADO Work Item

| Item      | Detail                   |
|-----------|--------------------------|
| Epic      | [Epic ID]                |
| Feature   | [Feature ID]             |
| Area path | [Azure DevOps area path] |

---

## Team Communication

| Event             | How                          |
|-------------------|------------------------------|
| New deployment    | Teams — EA Dashboard channel |
| Bug fix deployed  | Teams — tag relevant members |
| Enhancement added | Teams + ADO work item update |

---

## Validation Scenarios

> Developer must complete all scenarios before every deployment.
> Mark each Pass or Fail in the sign-off table at the bottom.
> Do not deploy if any scenario fails.
> Current method: Manual | Automation planned via validation_agent

---

### Scenario 1 — Core Logic Validation

**What to check:** KPI values in dashboard match raw Excel source data.

**Steps:**
1. Open `audit_data.xlsx` — Projects sheet
2. Count total rows → note as expected TOTAL RECORDS
3. Count rows where score >= 75 → expected GREEN count
4. Count rows where score 50–74 → expected AMBER count
5. Count rows where score < 50 → expected RED count
6. Calculate average of all scores → expected AVG SCORE
7. Go to Ratings sheet — count rows where Issue Type = NC → expected NC
8. Count rows where Issue Type = OFI → expected OFI
9. Open generated HTML in browser
10. Compare each KPI card value against your calculations above

**Expected result:**
- TOTAL RECORDS = Excel row count
- GREEN + AMBER + RED = TOTAL RECORDS
- AVG SCORE = Excel average (±0.5 tolerance for rounding)
- NC = Ratings NC row count
- OFI = Ratings OFI row count
- TOTAL ISSUES = NC + OFI

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 2 — Key Visuals Validation

**What to check:** All charts, tables, tabs and UI elements render correctly.

**Steps:**
1. Open generated HTML in browser
2. Verify title "Audit Dashboard" is visible
3. Verify score band legend visible — Green ≥75%, Amber 50–74%, Red <50%
4. Verify all 5 tabs exist and each loads without error:
   - Executive Summary
   - Portfolio View
   - Area Analysis
   - Issues Tracker
   - QTR Comparison
5. On Executive Summary — verify all 8 KPI cards visible and not blank
6. Verify Score Distribution chart shows bars — not blank
7. Verify Portfolio Performance chart shows all portfolios
8. Verify Area Compliance chart shows all areas
9. Scroll down — verify Top Projects table has data rows
10. Verify Projects Needing Attention table has data rows
11. Verify Quarter Overview table shows quarters and counts
12. Verify Issue Type Breakdown donut chart visible
13. Verify Global Filter bar — All Portfolios and All DMs dropdowns exist

**Expected result:**
- All 5 tabs load without error
- All 8 KPI cards show values — nothing blank
- All charts visible with data
- Both tables have data rows
- All filters visible and clickable

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 3 — Data Correctness Validation

**What to check:** Data in dashboard accurately reflects what is in Excel.

**Steps:**
1. Open `audit_data.xlsx` — Projects sheet
2. Note 5 project names from the file
3. Open generated HTML dashboard
4. Find each of those 5 project names in the dashboard
5. Verify score shown for each project matches Excel
6. Verify quarter values in filter match quarters in Excel Quarter column
7. Go to Ratings sheet — pick 3 projects
8. Verify NC and OFI counts shown in dashboard match Ratings sheet

**Expected result:**
- All project names from Excel appear in dashboard
- Scores shown match Excel values
- Quarter filter options match Excel quarters
- NC and OFI per project match Ratings sheet

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 4 — Access and Security Validation

**What to check:** No security vulnerabilities in generated HTML.

**Steps:**
1. Open generated HTML file in a text editor
2. Search for `Content-Security-Policy` — verify it exists in meta tags
3. Check CSP value — confirm it does NOT contain `unsafe-inline`
4. Search for `onclick=`, `onerror=`, `onload=` — verify none found
5. Search for `javascript:` — verify not found in any href
6. Search for `eval(` — verify not found in any script tag
7. Open browser DevTools (F12) → Console tab
8. Reload dashboard — verify no red errors in console

**Expected result:**
- CSP meta tag present
- No unsafe-inline in CSP
- No inline event handlers
- No javascript: in href
- No eval() in scripts
- No console errors on load

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

### Scenario 5 — Regression Check (After Fix or Enhancement)

**What to check:** Recent change has not broken anything that was working before.

**Steps:**
1. Note what was changed — specific fix or enhancement
2. Run Scenarios 1 to 4 in full
3. Check the specific area that was changed works as expected
4. Compare with last known good screenshot from tests/screenshots/

**Expected result:**
- All scenarios 1–4 still pass
- Specific fix works correctly
- Nothing previously working is now broken

**Pass / Fail:** _______  |  **Checked by:** _______  |  **Date:** _______

---

## Validation Sign-off

Complete before every deployment:

| Scenario                          | Pass / Fail | Checked by | Date |
|-----------------------------------|-------------|------------|------|
| 1 — Core Logic                    |             |            |      |
| 2 — Key Visuals                   |             |            |      |
| 3 — Data Correctness              |             |            |      |
| 4 — Access and Security           |             |            |      |
| 5 — Regression (if applicable)    |             |            |      |

> All must show **Pass** before deploying to server.

---

## Maintenance

All changes follow: **Understand → Track → Build → Validate → Deploy**

| Type               | Example                   | ADO Item |
|--------------------|---------------------------|----------|
| Bug fix            | KPI calculation wrong     | Yes      |
| Vulnerability fix  | CSP, XSS patch            | Yes      |
| Enhancement        | New chart or filter       | Yes      |
| Data source change | New Excel column          | Yes      |

---

## Change History

| Date     | Change                        | Done by     | ADO Item |
|----------|-------------------------------|-------------|----------|
| Apr 2026 | CSP and XSS vulnerability fix | [Developer] | [ID]     |
| Apr 2026 | Initial deployment            | EA Team     | [ID]     |

---

*Last updated: April 2026 | Owner: EA Team*
