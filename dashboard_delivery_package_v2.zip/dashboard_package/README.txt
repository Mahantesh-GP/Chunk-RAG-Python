Dashboard Delivery Package
==========================
EA Team | April 2026


WHAT IS IN THIS PACKAGE
------------------------

1. Dashboard_Tracker.xlsx
   - One row per dashboard
   - Developer fills their own row
   - Manager sees all dashboards at a glance
   - Covers full lifecycle: Understand → Track → Build → Validate → Deploy → Maintain

2. readme_templates/
   - audit_dashboard/README.md       — fully filled for Audit Dashboard
   - copilot_dashboard/README.md     — partially filled for Copilot Dashboard
   - dashboard_template/README.md    — blank template for new dashboards


HOW TO USE
----------

Excel Tracker:
   Open Dashboard_Tracker.xlsx
   Each developer fills their own row
   Update after every deployment or change

README.md:
   Copy readme_templates/dashboard_template/README.md
   into your dashboard repo folder
   Fill in all sections
   Commit it to the repo

   Example:
   Package/
   └── Audit/
       ├── generate_audit_dashboard.py
       ├── data/audit_data.xlsx
       └── README.md    ← put it here


WHY BOTH?
---------
Excel Tracker = Manager level view — all dashboards in one place
README.md     = Developer level view — lives inside the repo with the code

The manager specifically asked:
  "If it makes sense, you can convert into MD"
  "Who is owning what responsibility?"
  "How do you communicate when you make changes?"

Both files together answer all three questions.


NEW DASHBOARD CHECKLIST
-----------------------
When a new dashboard arrives:
  [ ] Add a row to Dashboard_Tracker.xlsx
  [ ] Copy README.md template into repo folder
  [ ] Fill both with dashboard details
  [ ] Create ADO work item
  [ ] Confirm team responsibilities (all 4 roles)
