Dashboard Validation Agent
==========================

Sub-agent based validation system for PMO dashboards.
Each dashboard has its own SKILL.md defining what to validate.
Agents read the SKILL.md and run automatically.


FOLDER STRUCTURE
----------------
validation_agent/
├── orchestrator.py              ← main entry point
├── requirements.txt
├── agents/
│   ├── excel_agent.py           ← validates Excel data + calculates KPIs
│   ├── json_agent.py            ← validates JSON (for excel→json→html flow)
│   ├── html_agent.py            ← checks visuals via Playwright
│   ├── data_match_agent.py      ← compares Excel KPIs vs HTML values
│   ├── security_agent.py        ← CSP, XSS, JS checks
│   └── report_agent.py          ← collects results and prints report
├── skills/
│   ├── audit_dashboard/
│   │   └── SKILL.md             ← what to validate for Audit Dashboard
│   ├── copilot_dashboard/
│   │   └── SKILL.md             ← what to validate for Copilot Dashboard
│   └── dashboard_template/
│       └── SKILL.md             ← copy this for each new dashboard
└── output/                      ← validation reports saved here


SETUP
-----
1. Install dependencies:
   pip install -r requirements.txt
   playwright install chromium

2. Place this folder inside your project root:
   your-project/
   ├── validation_agent/    ← here
   ├── package/
   │   └── dashboard/
   │       └── audit/
   │           └── audit_q1_2026.html
   └── data/
       └── audit_data.xlsx


HOW TO RUN
----------
Validate one dashboard:
   python orchestrator.py --dashboard audit
   python orchestrator.py --dashboard copilot

Validate all dashboards:
   python orchestrator.py --all


HOW TO ADD A NEW DASHBOARD
--------------------------
1. Copy skills/dashboard_template/SKILL.md
   to   skills/your_dashboard_name/SKILL.md

2. Fill in the SKILL.md:
   - dashboard_name
   - file paths (excel, html, json if needed)
   - set run_json_agent: true if your flow has a JSON step
   - define core_logic KPIs in plain English
   - define key_visuals to check
   - define data_correctness checks
   - define mandatory Excel columns

3. Add to DASHBOARD_MAP in orchestrator.py:
   DASHBOARD_MAP = {
       "audit"   : "audit_dashboard",
       "copilot" : "copilot_dashboard",
       "myboard" : "my_dashboard_name",   ← add here
   }

4. Run:
   python orchestrator.py --dashboard myboard

No new agent code needed.
SKILL.md defines the rules. Agents execute them.


WHEN TO UPDATE SKILL.md
-----------------------
- KPI formula changes in Python script   → update core_logic section
- New KPI card added to dashboard        → add to key_visuals labels
- New column added to Excel              → add to mandatory_columns
- New allowed value added                → add to allowed_values
- JSON structure changes                 → update json_checks

WHEN TO UPDATE AGENT CODE
-------------------------
- Completely new type of validation not covered by any agent
- New data source type (e.g. database instead of Excel)
- New output format (e.g. PDF instead of HTML)


TWO FLOWS SUPPORTED
-------------------
Flow A — Simple:     Excel → Python → HTML
  Set: flow_type: excel_to_html
  Set: run_json_agent: false

Flow B — With JSON:  Excel → Python → JSON → Python → HTML
  Set: flow_type: excel_to_json_to_html
  Set: run_json_agent: true
  Set: json_path: path/to/output.json
