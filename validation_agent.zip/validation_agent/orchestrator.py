"""
Validation Orchestrator
========================
Main entry point. Reads SKILL.md for the requested dashboard,
decides which agents to run, collects results, and prints report.

Usage:
    python orchestrator.py --dashboard audit
    python orchestrator.py --dashboard copilot
    python orchestrator.py --all
"""

import argparse
import yaml
from pathlib import Path
from agents.excel_agent   import ExcelAgent
from agents.json_agent    import JsonAgent
from agents.html_agent    import HtmlAgent
from agents.data_match_agent import DataMatchAgent
from agents.security_agent   import SecurityAgent
from agents.report_agent     import ReportAgent

# ── Config ────────────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).parent.parent
SKILLS_DIR   = Path(__file__).parent / "skills"

DASHBOARD_MAP = {
    "audit"   : "audit_dashboard",
    "copilot" : "copilot_dashboard",
    # Add new dashboards here:
    # "dashboard3": "dashboard_3",
}


# ── Load SKILL.md ─────────────────────────────────────────────────────────────
def load_skill(dashboard_key: str) -> dict:
    skill_name = DASHBOARD_MAP.get(dashboard_key)
    if not skill_name:
        raise ValueError(f"Unknown dashboard: '{dashboard_key}'. "
                         f"Available: {list(DASHBOARD_MAP.keys())}")

    skill_path = SKILLS_DIR / skill_name / "SKILL.md"
    if not skill_path.exists():
        raise FileNotFoundError(f"SKILL.md not found: {skill_path}")

    with open(skill_path) as f:
        skill = yaml.safe_load(f)

    print(f"\n  Loaded skill: {skill_path.relative_to(Path(__file__).parent)}")
    return skill


# ── Run one dashboard ─────────────────────────────────────────────────────────
def run_dashboard(dashboard_key: str) -> dict:
    skill   = load_skill(dashboard_key)
    results = {}

    print(f"\n{'═' * 60}")
    print(f"  Validating: {skill.get('dashboard_name', dashboard_key)}")
    print(f"{'═' * 60}")

    # Step 1 — Excel validation
    if skill.get("run_excel_agent"):
        agent = ExcelAgent(skill, PROJECT_ROOT)
        results["excel"] = agent.run()

    # Step 2 — JSON validation (only for excel→json→html flow)
    if skill.get("run_json_agent"):
        agent = JsonAgent(skill, PROJECT_ROOT)
        results["json"] = agent.run()

    # Step 3 — HTML structure check
    if skill.get("run_html_agent"):
        agent = HtmlAgent(skill, PROJECT_ROOT)
        results["html"] = agent.run()

    # Step 4 — Data match (Excel vs HTML)
    if skill.get("run_data_match_agent"):
        agent = DataMatchAgent(skill, PROJECT_ROOT, results)
        results["data_match"] = agent.run()

    # Step 5 — Security check
    if skill.get("run_security_agent"):
        agent = SecurityAgent(skill, PROJECT_ROOT)
        results["security"] = agent.run()

    # Step 6 — Final report
    if skill.get("run_report_agent"):
        agent = ReportAgent(skill, results)
        agent.run()

    return results


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dashboard Validation Orchestrator")
    parser.add_argument("--dashboard", help="Dashboard key to validate (e.g. audit, copilot)")
    parser.add_argument("--all", action="store_true", help="Validate all dashboards")
    args = parser.parse_args()

    if args.all:
        all_results = {}
        for key in DASHBOARD_MAP:
            try:
                all_results[key] = run_dashboard(key)
            except Exception as e:
                print(f"\n  ❌ {key}: {e}")

        print(f"\n{'═' * 60}")
        print("  COMBINED SUMMARY")
        print(f"{'═' * 60}")
        for key, res in all_results.items():
            passed = all(v.get("passed", False) for v in res.values())
            icon = "✅" if passed else "❌"
            print(f"  {icon}  {key}")

    elif args.dashboard:
        run_dashboard(args.dashboard)

    else:
        parser.print_help()
