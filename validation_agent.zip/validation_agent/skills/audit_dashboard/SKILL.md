# Audit Dashboard — Validation Skill
# =====================================
# This file defines WHAT to validate for the Audit Dashboard.
# The orchestrator reads this file and decides which agents to run.
# Update this file when KPI logic or dashboard structure changes.
# No code changes needed — just update this file.

# ── Dashboard Info ────────────────────────────────────────────────────────────
dashboard_name: Audit Dashboard
flow_type: excel_to_html        # excel → python → html (no JSON step)
developer: EA Team

# ── File Paths ────────────────────────────────────────────────────────────────
excel_path: data/audit_data.xlsx
html_path: package/dashboard/audit/audit_q1_2026.html
excel_sheets:
  - Projects
  - Ratings

# ── Agents To Run ─────────────────────────────────────────────────────────────
# Set true/false to enable or disable each agent
run_excel_agent: true
run_json_agent: false           # No JSON step in this dashboard
run_html_agent: true
run_data_match_agent: true
run_security_agent: true
run_report_agent: true

# ── Core Logic Checks ─────────────────────────────────────────────────────────
# Define KPI formulas here in plain English.
# excel_agent will calculate these independently from raw Excel data.
# data_match_agent will compare against HTML values.
core_logic:
  - name: AVG SCORE
    description: Average of all project scores
    formula: average of score column in Projects sheet
    tolerance: 0.5              # allow 0.5% difference due to rounding

  - name: TOTAL RECORDS
    description: Total number of project rows
    formula: count of rows in Projects sheet

  - name: GREEN COUNT
    description: Projects with score >= 75
    formula: count of projects where score >= 75

  - name: AMBER COUNT
    description: Projects with score between 50 and 74
    formula: count of projects where score >= 50 and score < 75

  - name: RED COUNT
    description: Projects with score < 50
    formula: count of projects where score < 50

  - name: NC COUNT
    description: Non-conformance count
    formula: count of rows in Ratings sheet where Issue Type == NC

  - name: OFI COUNT
    description: Opportunities for improvement count
    formula: count of rows in Ratings sheet where Issue Type == OFI

  - name: TOTAL ISSUES
    description: Total issues = NC + OFI
    formula: NC COUNT + OFI COUNT

  - name: GREEN + AMBER + RED
    description: Sum must equal TOTAL RECORDS
    formula: GREEN COUNT + AMBER COUNT + RED COUNT == TOTAL RECORDS

# ── Key Visuals Checks ────────────────────────────────────────────────────────
# html_agent checks these elements exist and are visible in the browser.
key_visuals:
  - name: Dashboard Title
    check: text contains Audit Dashboard

  - name: KPI Cards
    check: all 8 labels exist
    labels:
      - AVG SCORE
      - TOTAL RECORDS
      - GREEN
      - AMBER
      - RED
      - NON-CONFORMANCES
      - OPPORTUNITIES
      - TOTAL ISSUES

  - name: Tab Navigation
    check: all 5 tabs exist
    tabs:
      - Executive Summary
      - Portfolio View
      - Area Analysis
      - Issues Tracker
      - QTR Comparison

  - name: Charts
    check: at least 3 canvas or svg elements exist

  - name: Top Projects Table
    check: text contains Top Projects

  - name: Needing Attention Table
    check: text contains Needing Attention

  - name: Quarter Overview Table
    check: text contains Quarter Overview

  - name: Global Filter Bar
    check: text contains GLOBAL FILTER

# ── Data Correctness Checks ───────────────────────────────────────────────────
# data_match_agent compares Excel data against HTML output.
data_correctness:
  - name: Project names in HTML
    check: every project name from Excel Projects sheet appears in HTML

  - name: Quarter values in HTML
    check: every unique quarter from Excel appears in HTML

  - name: Top projects correct
    check: projects with score >= 75 appear in Top Projects table

  - name: Attention projects correct
    check: projects with score < 75 appear in Needing Attention table

  - name: Row count matches
    check: TOTAL RECORDS KPI matches row count in Excel

# ── Security Checks ───────────────────────────────────────────────────────────
security:
  - check: CSP meta tag exists
  - check: no unsafe-inline in CSP
  - check: no inline event handlers (onclick, onerror, onload)
  - check: no javascript protocol in href
  - check: no eval() in scripts

# ── Excel Validation ──────────────────────────────────────────────────────────
excel_validation:
  mandatory_columns:
    Projects:
      - Project Name
      - Portfolio
      - Delivery Manager
      - PM
      - Auditor
      - Auditee
      - Audit Date
      - Quarter
      - Opportunity
      - Audit Highlights
    Ratings:
      - Project Name
      - Quarter
      - Question ID
      - Area
      - Question
      - Rating
      - Issue Type
      - Recommendation

  allowed_values:
    Quarter:
      - Q2 2025
      - Q3 2025
      - Q4 2025
      - Q1 2026
    Rating:
      - Fully Implemented
      - Partially Implemented
      - Not Implemented
      - Not Applicable
    Issue Type:
      - NC
      - OFI
      - ""                      # blank is allowed
