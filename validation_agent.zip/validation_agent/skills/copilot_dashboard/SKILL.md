# GitHub Copilot Adoption Dashboard — Validation Skill
# ======================================================
# Flow: Excel (managers update) → Python script → HTML dashboard
# No JSON intermediate step.

# ── Dashboard Info ────────────────────────────────────────────────────────────
dashboard_name: GitHub Copilot Adoption Dashboard
flow_type: excel_to_html
developer: EA Team

# ── File Paths ────────────────────────────────────────────────────────────────
excel_path: data/copilot_data.xlsx
html_path: package/dashboard/copilot/copilot_dashboard.html
excel_sheets:
  - Data                        # update sheet name to match actual

# ── Agents To Run ─────────────────────────────────────────────────────────────
run_excel_agent: true
run_json_agent: false
run_html_agent: true
run_data_match_agent: true
run_security_agent: true
run_report_agent: true

# ── Core Logic Checks ─────────────────────────────────────────────────────────
# TODO: Fill in actual KPI formulas when known
core_logic:
  - name: TOTAL MANAGERS
    description: Total number of manager rows
    formula: count of rows in Data sheet

  - name: ADOPTION RATE
    description: Percentage of managers actively using Copilot
    formula: to be defined by developer
    tolerance: 0.5

# ── Key Visuals Checks ────────────────────────────────────────────────────────
# TODO: Update labels to match actual dashboard elements
key_visuals:
  - name: Dashboard Title
    check: text contains GitHub Copilot

  - name: KPI Cards
    check: key summary cards exist
    labels:
      - Total Managers           # update to match actual labels
      - Adoption Rate

  - name: Charts
    check: at least 1 canvas or svg element exists

# ── Data Correctness ──────────────────────────────────────────────────────────
data_correctness:
  - name: Manager data in HTML
    check: key values from Excel appear in HTML

  - name: Row count matches
    check: total count in HTML matches Excel row count

# ── Security ──────────────────────────────────────────────────────────────────
security:
  - check: CSP meta tag exists
  - check: no unsafe-inline in CSP
  - check: no inline event handlers
  - check: no javascript protocol in href
  - check: no eval() in scripts

# ── Excel Validation ──────────────────────────────────────────────────────────
excel_validation:
  mandatory_columns:
    Data:
      - Manager Name             # update to match actual column names
      - Portfolio
      - Status
  allowed_values: {}             # define when columns are known
