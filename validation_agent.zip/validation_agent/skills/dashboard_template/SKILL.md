# [Dashboard Name] — Validation Skill
# =====================================
# TEMPLATE — Copy this file to skills/<your_dashboard>/ and fill in.
# This file defines WHAT to validate. No code changes needed.

# ── Dashboard Info ────────────────────────────────────────────────────────────
dashboard_name: "[Dashboard Name]"
flow_type: excel_to_html        # options: excel_to_html | excel_to_json_to_html
developer: EA Team

# ── File Paths ────────────────────────────────────────────────────────────────
excel_path: data/your_excel.xlsx
html_path: package/dashboard/your_folder/your_file.html
json_path: data/output.json     # only needed if flow_type is excel_to_json_to_html
excel_sheets:
  - Sheet1                      # add all sheet names

# ── Agents To Run ─────────────────────────────────────────────────────────────
run_excel_agent: true
run_json_agent: false           # set true if flow has JSON step
run_html_agent: true
run_data_match_agent: true
run_security_agent: true
run_report_agent: true

# ── Core Logic Checks ─────────────────────────────────────────────────────────
# Define each KPI or metric that the Python script calculates.
# The excel_agent will recalculate these independently.
# The data_match_agent will compare against HTML values.
core_logic:
  - name: "[KPI Name]"
    description: "[What this KPI represents]"
    formula: "[Plain English formula — e.g. count of rows where Status == Active]"
    tolerance: 0                # allowed difference (use 0.5 for percentages)

  # Add more KPIs below:
  # - name: "[KPI 2]"
  #   description: "..."
  #   formula: "..."

# ── Key Visuals Checks ────────────────────────────────────────────────────────
# Define all UI elements that must exist in the generated HTML.
key_visuals:
  - name: Dashboard Title
    check: text contains "[Your Dashboard Title]"

  - name: KPI Cards
    check: key label texts exist
    labels:
      - "[Label 1]"
      - "[Label 2]"

  - name: Charts
    check: at least [N] canvas or svg elements exist

  - name: Tables
    check: text contains "[Table heading]"

  # Add more visual checks as needed

# ── Data Correctness Checks ───────────────────────────────────────────────────
data_correctness:
  - name: Row count matches
    check: total count in HTML matches Excel row count

  - name: Key values in HTML
    check: primary key column values from Excel appear in HTML

  # Add more checks as needed

# ── JSON Checks (only if flow_type is excel_to_json_to_html) ─────────────────
json_checks:
  - check: JSON file exists and is not empty
  - check: root array is not empty
  - check: each item has required fields
  required_fields:
    - "[field1]"
    - "[field2]"

# ── Security Checks ───────────────────────────────────────────────────────────
security:
  - check: CSP meta tag exists
  - check: no unsafe-inline in CSP
  - check: no inline event handlers
  - check: no javascript protocol in href
  - check: no eval() in scripts

# ── Excel Validation ──────────────────────────────────────────────────────────
excel_validation:
  mandatory_columns:
    Sheet1:
      - "[Column 1]"
      - "[Column 2]"
  allowed_values:
    "[Column Name]":
      - "[Allowed Value 1]"
      - "[Allowed Value 2]"
