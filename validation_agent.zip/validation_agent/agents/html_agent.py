"""
HTML Agent
==========
Opens the generated HTML in a real Chromium browser using Playwright.
Checks all key visuals defined in SKILL.md exist and are visible.
Extracts KPI values from HTML for DataMatchAgent to compare.
"""

import re
from pathlib import Path
from playwright.sync_api import sync_playwright


class HtmlAgent:

    def __init__(self, skill: dict, project_root: Path):
        self.skill        = skill
        self.project_root = project_root
        self.html_path    = project_root / skill.get("html_path", "")
        self.results      = {
            "passed"      : True,
            "errors"      : [],
            "warnings"    : [],
            "html_content": "",
            "kpi_values"  : {},
        }

    def run(self) -> dict:
        print("\n  🌐 HTML Agent")

        if not self.html_path.exists():
            self._fail(f"HTML file not found: {self.html_path}")
            return self.results

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch()
                page    = browser.new_page()
                page.goto(f"file:///{self.html_path.resolve()}")
                page.wait_for_load_state("domcontentloaded")
                page.wait_for_timeout(500)

                self.results["html_content"] = page.content()

                self._check_visuals(page)
                self._extract_kpis(page)

                browser.close()

            if self.results["passed"]:
                print("     ✅ HTML structure check passed")
            else:
                for e in self.results["errors"]:
                    print(f"     ❌ {e}")

        except Exception as e:
            self._fail(f"HTML agent error: {e}")

        return self.results

    # ── Visual checks ─────────────────────────────────────────────────────────
    def _check_visuals(self, page):
        visuals  = self.skill.get("key_visuals", [])
        content  = self.results["html_content"]

        for visual in visuals:
            name  = visual.get("name", "")
            check = visual.get("check", "")

            try:
                if "text contains" in check:
                    search_text = check.replace("text contains", "").strip().strip('"')
                    if search_text not in content:
                        self._fail(f"'{name}' not found — expected text: '{search_text}'")
                    else:
                        print(f"     ✅ {name}")

                elif "labels exist" in check or "tabs exist" in check:
                    items = visual.get("labels", []) or visual.get("tabs", [])
                    for item in items:
                        if item not in content:
                            self._fail(f"'{name}' — label missing: '{item}'")
                    if all(item in content for item in items):
                        print(f"     ✅ {name} ({len(items)} items found)")

                elif "canvas or svg" in check:
                    # Extract minimum count from check string
                    nums = re.findall(r'\d+', check)
                    min_count = int(nums[0]) if nums else 1
                    count = (
                        page.locator("canvas").count() +
                        page.locator("svg").count()
                    )
                    if count < min_count:
                        self._fail(f"'{name}' — found {count} charts, expected >= {min_count}")
                    else:
                        print(f"     ✅ {name} ({count} found)")

            except Exception as e:
                self.results["warnings"].append(f"Visual check '{name}' error: {e}")

    # ── KPI extraction ────────────────────────────────────────────────────────
    def _extract_kpis(self, page):
        """
        Try to extract KPI values from HTML for comparison.
        This is a best-effort extraction — update selectors to match
        your actual dashboard HTML structure.
        """
        content = self.results["html_content"]
        kpis    = {}

        # Extract percentage values (e.g. AVG SCORE)
        pct_matches = re.findall(r'(\d+\.?\d*)\s*%', content)
        if pct_matches:
            kpis["AVG SCORE (extracted)"] = float(pct_matches[0])

        # Extract numbers near KPI labels
        # Customize these patterns to match your HTML structure
        patterns = {
            "TOTAL RECORDS" : r'TOTAL RECORDS[^0-9]*(\d+)',
            "GREEN"         : r'GREEN[^0-9]*(\d+)',
            "AMBER"         : r'AMBER[^0-9]*(\d+)',
            "RED"           : r'RED[^0-9]*(\d+)',
            "NON-CONFORM"   : r'NON.CONFORMANCES?[^0-9]*(\d+)',
            "OPPORTUNITIES" : r'OPPORTUNITIES[^0-9]*(\d+)',
            "TOTAL ISSUES"  : r'TOTAL ISSUES[^0-9]*(\d+)',
        }

        for name, pattern in patterns.items():
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                kpis[name] = int(match.group(1))

        self.results["kpi_values"] = kpis
        print(f"     Extracted {len(kpis)} KPI values from HTML")

    def _fail(self, msg):
        self.results["passed"] = False
        self.results["errors"].append(msg)
