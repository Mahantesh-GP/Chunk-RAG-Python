"""
Security Agent
==============
Checks the generated HTML for security vulnerabilities
defined in SKILL.md security section.
Covers CSP, XSS, and JS injection risks.
"""

import re
from pathlib import Path
from playwright.sync_api import sync_playwright


class SecurityAgent:

    def __init__(self, skill: dict, project_root: Path):
        self.skill        = skill
        self.project_root = project_root
        self.html_path    = project_root / skill.get("html_path", "")
        self.results      = {"passed": True, "errors": [], "warnings": []}

    def run(self) -> dict:
        print("\n  🔒 Security Agent")

        if not self.html_path.exists():
            self._fail(f"HTML file not found: {self.html_path}")
            return self.results

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch()
                page    = browser.new_page()
                page.goto(f"file:///{self.html_path.resolve()}")
                page.wait_for_load_state("domcontentloaded")

                html = page.content()
                self._run_checks(page, html)

                browser.close()

            if self.results["passed"]:
                print("     ✅ Security check passed")
            else:
                for e in self.results["errors"]:
                    print(f"     ❌ {e}")

        except Exception as e:
            self._fail(f"Security agent error: {e}")

        return self.results

    def _run_checks(self, page, html: str):
        checks = self.skill.get("security", [])

        for check in checks:
            check_str = check.get("check", "").lower() if isinstance(check, dict) else str(check).lower()

            if "csp meta tag exists" in check_str:
                csp = page.locator("meta[http-equiv='Content-Security-Policy']")
                if csp.count() > 0:
                    print("     ✅ CSP meta tag present")
                else:
                    self._warn("CSP meta tag missing — add to generated HTML")

            elif "no unsafe-inline" in check_str:
                csp_tag = page.locator("meta[http-equiv='Content-Security-Policy']")
                if csp_tag.count() > 0:
                    content = csp_tag.get_attribute("content") or ""
                    if "unsafe-inline" in content:
                        self._fail("CSP contains unsafe-inline — XSS risk")
                    else:
                        print("     ✅ CSP no unsafe-inline")

            elif "inline event handlers" in check_str:
                dangerous = ["onerror", "onload", "onmouseover", "onfocus", "onclick"]
                found = []
                for attr in dangerous:
                    matches = re.findall(
                        rf'<(?!body|html)[^>]+\s{attr}\s*=', html, re.IGNORECASE
                    )
                    if matches:
                        found.append(attr)
                if found:
                    self._fail(f"Inline event handlers found: {found}")
                else:
                    print("     ✅ No inline event handlers")

            elif "javascript protocol" in check_str:
                matches = re.findall(r'href\s*=\s*["\']javascript:', html, re.IGNORECASE)
                if matches:
                    self._fail("javascript: protocol found in href")
                else:
                    print("     ✅ No javascript: protocol in href")

            elif "eval()" in check_str:
                matches = re.findall(
                    r'<script[^>]*>.*?eval\s*\(', html, re.IGNORECASE | re.DOTALL
                )
                if matches:
                    self._fail("eval() found in inline script")
                else:
                    print("     ✅ No eval() in scripts")

    def _fail(self, msg):
        self.results["passed"] = False
        self.results["errors"].append(msg)

    def _warn(self, msg):
        self.results["warnings"].append(msg)
        print(f"     ⚠️  {msg}")
