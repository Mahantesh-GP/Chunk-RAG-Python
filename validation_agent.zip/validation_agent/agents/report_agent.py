"""
Report Agent
============
Collects results from all agents and prints a clean summary.
Saves report to output/ folder.
"""

from datetime import datetime
from pathlib import Path


class ReportAgent:

    def __init__(self, skill: dict, all_results: dict):
        self.skill       = skill
        self.all_results = all_results
        self.output_dir  = Path(__file__).parent.parent / "output"
        self.output_dir.mkdir(exist_ok=True)

    def run(self):
        name     = self.skill.get("dashboard_name", "Dashboard")
        now      = datetime.now().strftime("%Y-%m-%d %H:%M")

        lines    = []
        lines.append(f"\n{'─' * 60}")
        lines.append(f"  VALIDATION REPORT — {name.upper()}")
        lines.append(f"  {now}")
        lines.append(f"{'─' * 60}")

        agent_labels = {
            "excel"      : "Excel Validation",
            "json"       : "JSON Validation",
            "html"       : "Structure Check",
            "data_match" : "Data Match",
            "security"   : "Security Check",
        }

        all_passed = True

        for key, label in agent_labels.items():
            result = self.all_results.get(key)
            if result is None:
                continue

            passed = result.get("passed", True)
            icon   = "✅" if passed else "❌"
            lines.append(f"  {icon}  {label}")

            if not passed:
                all_passed = False
                for e in result.get("errors", []):
                    lines.append(f"       → {e}")

            for w in result.get("warnings", []):
                lines.append(f"       ⚠️  {w}")

        lines.append(f"{'─' * 60}")
        if all_passed:
            lines.append("  ✅  ALL PASSED — Safe to deploy")
        else:
            lines.append("  ❌  FAILED — Fix issues before deploying")
        lines.append(f"{'─' * 60}\n")

        report_text = "\n".join(lines)
        print(report_text)

        # Save to file
        safe_name   = name.lower().replace(" ", "_")
        report_path = self.output_dir / f"{safe_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        report_path.write_text(report_text)
        print(f"  Report saved → {report_path}")
