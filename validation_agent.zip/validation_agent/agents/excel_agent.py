"""
Excel Agent
===========
Reads the Excel file, validates structure and data,
and independently calculates expected KPI values.
Results are passed to DataMatchAgent for comparison.
"""

import pandas as pd
import re
from pathlib import Path


class ExcelAgent:

    def __init__(self, skill: dict, project_root: Path):
        self.skill        = skill
        self.project_root = project_root
        self.excel_path   = project_root / skill.get("excel_path", "")
        self.results      = {"passed": True, "errors": [], "warnings": [], "kpis": {}, "dataframes": {}}

    def run(self) -> dict:
        print("\n  📊 Excel Agent")

        if not self.excel_path.exists():
            self._fail(f"Excel file not found: {self.excel_path}")
            return self.results

        try:
            self._validate_sheets()
            self._validate_columns()
            self._validate_data_values()
            self._check_xss()
            self._calculate_kpis()

            if self.results["passed"]:
                print("     ✅ Excel validation passed")
            else:
                for e in self.results["errors"]:
                    print(f"     ❌ {e}")

        except Exception as e:
            self._fail(f"Excel agent error: {e}")

        return self.results

    # ── Sheet validation ──────────────────────────────────────────────────────
    def _validate_sheets(self):
        expected = self.skill.get("excel_sheets", [])
        xl       = pd.ExcelFile(self.excel_path)
        actual   = xl.sheet_names

        for sheet in expected:
            if sheet not in actual:
                self._fail(f"Sheet '{sheet}' not found. Available: {actual}")
            else:
                df = pd.read_excel(self.excel_path, sheet_name=sheet)
                self.results["dataframes"][sheet] = df
                print(f"     Sheet '{sheet}': {len(df)} rows loaded")

    # ── Column validation ─────────────────────────────────────────────────────
    def _validate_columns(self):
        excel_val = self.skill.get("excel_validation", {})
        mandatory = excel_val.get("mandatory_columns", {})

        for sheet, cols in mandatory.items():
            df = self.results["dataframes"].get(sheet)
            if df is None:
                continue
            for col in cols:
                if col not in df.columns:
                    self._fail(f"Column '{col}' missing from sheet '{sheet}'")

    # ── Data value validation ─────────────────────────────────────────────────
    def _validate_data_values(self):
        excel_val     = self.skill.get("excel_validation", {})
        allowed_vals  = excel_val.get("allowed_values", {})

        for sheet, df in self.results["dataframes"].items():
            for col, allowed in allowed_vals.items():
                if col not in df.columns:
                    continue
                # Filter out empty allowed values
                non_empty_allowed = [v for v in allowed if v and str(v).strip()]
                if not non_empty_allowed:
                    continue
                invalid = df[~df[col].isin(allowed) & df[col].notna() & (df[col] != "")]
                if not invalid.empty:
                    self._fail(
                        f"Column '{col}' has invalid values: "
                        f"{invalid[col].unique().tolist()}"
                    )

    # ── XSS check ─────────────────────────────────────────────────────────────
    def _check_xss(self):
        for sheet, df in self.results["dataframes"].items():
            for col in df.select_dtypes(include="object").columns:
                for val in df[col].dropna():
                    val_str = str(val)
                    if re.search(r"<[^>]+>", val_str) or "javascript:" in val_str.lower():
                        self._fail(
                            f"Potential XSS in sheet '{sheet}' "
                            f"column '{col}': {val_str[:50]}"
                        )

    # ── KPI calculation ───────────────────────────────────────────────────────
    def _calculate_kpis(self):
        """
        Calculate expected KPI values independently from raw Excel data.
        These are compared against HTML values by DataMatchAgent.
        Add your own KPI calculations here as your dashboards evolve.
        """
        dfs    = self.results["dataframes"]
        kpis   = {}
        checks = self.skill.get("core_logic", [])

        for check in checks:
            name    = check.get("name", "")
            formula = check.get("formula", "").lower()

            try:
                # ── Audit Dashboard KPIs ──────────────────────────────────────
                if "average of score" in formula and "Projects" in dfs:
                    df = dfs["Projects"]
                    if "score" in [c.lower() for c in df.columns]:
                        score_col = next(c for c in df.columns if c.lower() == "score")
                        kpis[name] = round(df[score_col].mean(), 1)

                elif "count of rows in projects" in formula and "Projects" in dfs:
                    kpis[name] = len(dfs["Projects"])

                elif "score >= 75" in formula and "Projects" in dfs:
                    df = dfs["Projects"]
                    if "score" in [c.lower() for c in df.columns]:
                        score_col = next(c for c in df.columns if c.lower() == "score")
                        kpis[name] = len(df[df[score_col] >= 75])

                elif "score >= 50 and score < 75" in formula and "Projects" in dfs:
                    df = dfs["Projects"]
                    if "score" in [c.lower() for c in df.columns]:
                        score_col = next(c for c in df.columns if c.lower() == "score")
                        kpis[name] = len(df[(df[score_col] >= 50) & (df[score_col] < 75)])

                elif "score < 50" in formula and "Projects" in dfs:
                    df = dfs["Projects"]
                    if "score" in [c.lower() for c in df.columns]:
                        score_col = next(c for c in df.columns if c.lower() == "score")
                        kpis[name] = len(df[df[score_col] < 50])

                elif "issue type == nc" in formula and "Ratings" in dfs:
                    df = dfs["Ratings"]
                    kpis[name] = len(df[df["Issue Type"] == "NC"])

                elif "issue type == ofi" in formula and "Ratings" in dfs:
                    df = dfs["Ratings"]
                    kpis[name] = len(df[df["Issue Type"] == "OFI"])

                elif "nc count + ofi count" in formula:
                    nc  = kpis.get("NC COUNT", 0)
                    ofi = kpis.get("OFI COUNT", 0)
                    kpis[name] = nc + ofi

                elif "green count + amber count + red count" in formula:
                    g = kpis.get("GREEN COUNT", 0)
                    a = kpis.get("AMBER COUNT", 0)
                    r = kpis.get("RED COUNT",   0)
                    t = kpis.get("TOTAL RECORDS", None)
                    if t is not None:
                        kpis[name] = "PASS" if (g + a + r) == t else f"FAIL — {g}+{a}+{r}={g+a+r} != {t}"

                # ── Add your own KPI formulas here ────────────────────────────
                # elif "your formula keyword" in formula:
                #     kpis[name] = your_calculation

                if name in kpis:
                    print(f"     KPI '{name}' = {kpis[name]}")

            except Exception as e:
                self.results["warnings"].append(f"Could not calculate '{name}': {e}")

        self.results["kpis"] = kpis

    def _fail(self, msg):
        self.results["passed"] = False
        self.results["errors"].append(msg)
