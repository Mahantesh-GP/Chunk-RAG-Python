"""
JSON Agent
==========
Only runs for dashboards with flow: excel → json → html
Validates the intermediate JSON file produced by the first Python script.
Set run_json_agent: true in SKILL.md to enable.
"""

import json
from pathlib import Path


class JsonAgent:

    def __init__(self, skill: dict, project_root: Path):
        self.skill        = skill
        self.project_root = project_root
        self.json_path    = project_root / skill.get("json_path", "")
        self.results      = {"passed": True, "errors": [], "data": None}

    def run(self) -> dict:
        print("\n  📄 JSON Agent")

        if not self.json_path.exists():
            self._fail(f"JSON file not found: {self.json_path}")
            return self.results

        try:
            with open(self.json_path) as f:
                data = json.load(f)

            self._check_not_empty(data)
            self._check_required_fields(data)

            self.results["data"] = data

            if self.results["passed"]:
                print(f"     ✅ JSON valid — {len(data) if isinstance(data, list) else 'object'} records")
            else:
                for e in self.results["errors"]:
                    print(f"     ❌ {e}")

        except json.JSONDecodeError as e:
            self._fail(f"JSON parse error: {e}")
        except Exception as e:
            self._fail(f"JSON agent error: {e}")

        return self.results

    def _check_not_empty(self, data):
        if isinstance(data, list) and len(data) == 0:
            self._fail("JSON file is empty — no records found")
        elif isinstance(data, dict) and len(data) == 0:
            self._fail("JSON file is empty object")

    def _check_required_fields(self, data):
        json_checks     = self.skill.get("json_checks", [])
        required_fields = []

        for check in json_checks:
            if isinstance(check, dict) and "required_fields" in check:
                required_fields = check["required_fields"]

        if not required_fields or not isinstance(data, list):
            return

        for i, item in enumerate(data[:5]):  # check first 5 items
            for field in required_fields:
                if field not in item:
                    self._fail(f"JSON item {i} missing required field: '{field}'")

    def _fail(self, msg):
        self.results["passed"] = False
        self.results["errors"].append(msg)
