"""
Data Match Agent
================
Compares KPI values calculated by ExcelAgent against
values extracted from HTML by HtmlAgent.
This is the core validation — ensures Python script
produced correct output from Excel input.
"""

from pathlib import Path


class DataMatchAgent:

    def __init__(self, skill: dict, project_root: Path, previous_results: dict):
        self.skill            = skill
        self.project_root     = project_root
        self.previous_results = previous_results
        self.results          = {"passed": True, "errors": [], "matches": [], "mismatches": []}

    def run(self) -> dict:
        print("\n  🔍 Data Match Agent")

        excel_results = self.previous_results.get("excel", {})
        html_results  = self.previous_results.get("html",  {})

        if not excel_results or not html_results:
            self.results["warnings"] = ["Skipped — Excel or HTML results not available"]
            print("     ⚠️  Skipped — previous agent results not available")
            return self.results

        excel_kpis = excel_results.get("kpis",       {})
        html_kpis  = html_results.get("kpi_values",  {})
        html_content = html_results.get("html_content", "")
        dfs        = excel_results.get("dataframes", {})

        self._compare_kpis(excel_kpis, html_kpis)
        self._check_data_correctness(dfs, html_content)

        if self.results["passed"]:
            print("     ✅ Data match passed")
        else:
            for e in self.results["errors"]:
                print(f"     ❌ {e}")

        return self.results

    # ── KPI comparison ────────────────────────────────────────────────────────
    def _compare_kpis(self, excel_kpis: dict, html_kpis: dict):
        checks    = self.skill.get("core_logic", [])

        for check in checks:
            name      = check.get("name", "")
            tolerance = check.get("tolerance", 0)

            excel_val = excel_kpis.get(name)
            if excel_val is None:
                continue

            # Try to find matching HTML KPI
            html_val = None
            for key in html_kpis:
                if name.upper() in key.upper() or key.upper() in name.upper():
                    html_val = html_kpis[key]
                    break

            if html_val is None:
                self.results["matches"].append(
                    f"{name}: Excel={excel_val} | HTML=not extracted (manual check needed)"
                )
                print(f"     ⚠️  {name}: Excel={excel_val} | HTML value not extracted")
                continue

            # Compare with tolerance
            try:
                diff = abs(float(excel_val) - float(html_val))
                if diff <= tolerance:
                    self.results["matches"].append(f"{name}: ✅ {excel_val}")
                    print(f"     ✅ {name}: {excel_val} matches")
                else:
                    msg = f"{name}: Excel={excel_val} | HTML={html_val} | diff={diff}"
                    self.results["mismatches"].append(msg)
                    self._fail(msg)
            except (TypeError, ValueError):
                # Non-numeric comparison (e.g. PASS/FAIL string)
                if str(excel_val) == str(html_val):
                    self.results["matches"].append(f"{name}: ✅ {excel_val}")
                else:
                    self._fail(f"{name}: Excel={excel_val} | HTML={html_val}")

    # ── Data correctness checks ───────────────────────────────────────────────
    def _check_data_correctness(self, dfs: dict, html_content: str):
        checks = self.skill.get("data_correctness", [])

        for check in checks:
            check_name = check.get("name", "")
            check_type = check.get("check", "").lower()

            try:
                if "project names" in check_type and "Projects" in dfs:
                    df      = dfs["Projects"]
                    col     = "Project Name"
                    if col in df.columns:
                        missing = [
                            name for name in df[col].dropna()
                            if str(name) not in html_content
                        ]
                        if missing:
                            self._fail(f"{check_name}: Missing in HTML — {missing[:5]}")
                        else:
                            print(f"     ✅ {check_name}")

                elif "row count" in check_type:
                    # Already handled in KPI comparison via TOTAL RECORDS
                    print(f"     ✅ {check_name} — verified via KPI comparison")

                elif "quarter" in check_type and "Projects" in dfs:
                    df = dfs["Projects"]
                    if "Quarter" in df.columns:
                        missing_q = [
                            q for q in df["Quarter"].dropna().unique()
                            if str(q) not in html_content
                        ]
                        if missing_q:
                            self._fail(f"{check_name}: Quarters missing in HTML — {missing_q}")
                        else:
                            print(f"     ✅ {check_name}")

                # Add more data correctness checks here as needed

            except Exception as e:
                self.results["warnings"] = self.results.get("warnings", [])
                self.results["warnings"].append(f"Data check '{check_name}' error: {e}")

    def _fail(self, msg):
        self.results["passed"] = False
        self.results["errors"].append(msg)
