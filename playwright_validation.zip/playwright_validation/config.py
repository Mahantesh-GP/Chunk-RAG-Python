"""
config.py
=========
All file paths and settings in one place.
If paths change — update here only.
Nothing else needs to change.
"""

from pathlib import Path

# ── Project root ──────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).parent.parent

# ── Dashboard configurations ──────────────────────────────────────────────────
# Add new dashboard here when it arrives.
# That is the only change needed for a new dashboard.

DASHBOARDS = {

    "audit": {
        "name"       : "Audit Dashboard",
        "excel_path" : PROJECT_ROOT / "data" / "audit_data.xlsx",
        "html_path"  : PROJECT_ROOT / "package" / "dashboard" / "audit" / "a.html",
        "sheets"     : {
            "projects" : "Projects",
            "ratings"  : "Ratings",
        },
    },

    "copilot": {
        "name"       : "GHCP Rollout Dashboard",
        "excel_path" : PROJECT_ROOT / "data" / "copilot_data.xlsx",
        "html_path"  : PROJECT_ROOT / "package" / "dashboard" / "copilot" / "copilot.html",
        "sheets"     : {
            "data" : "Data",
        },
    },

    # ── Add new dashboard here ────────────────────────────────────────────────
    # "my_dashboard": {
    #     "name"      : "My Dashboard",
    #     "excel_path": PROJECT_ROOT / "data" / "my_data.xlsx",
    #     "html_path" : PROJECT_ROOT / "package" / "dashboard" / "my_folder" / "my.html",
    #     "sheets"    : { "data": "Sheet1" },
    # },
}

# ── Screenshots ───────────────────────────────────────────────────────────────
SCREENSHOT_DIR = Path(__file__).parent / "screenshots"

# ── Report ────────────────────────────────────────────────────────────────────
REPORT_DIR = Path(__file__).parent / "reports"
