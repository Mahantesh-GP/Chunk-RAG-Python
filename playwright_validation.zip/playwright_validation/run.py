"""
run.py
======
Main entry point. Developer runs this — nothing else needed.

Usage:
    python run.py --dashboard audit       ← validate one dashboard
    python run.py --dashboard copilot     ← validate another
    python run.py --all                   ← validate all dashboards
"""

import argparse
import sys
from playwright.sync_api import sync_playwright

from config import DASHBOARDS

# ── Import all dashboard modules ──────────────────────────────────────────────
# Add new dashboard import here when it arrives
from dashboards import audit_dashboard
from dashboards import copilot_dashboard

# ── Map dashboard key to module ───────────────────────────────────────────────
# Add new dashboard mapping here when it arrives
DASHBOARD_MODULES = {
    "audit"   : audit_dashboard,
    "copilot" : copilot_dashboard,
}


def run_dashboard(key: str) -> bool:
    """Open browser and run all checks for one dashboard."""
    config = DASHBOARDS.get(key)
    module = DASHBOARD_MODULES.get(key)

    if not config or not module:
        print(f"\n  ❌ Unknown dashboard: '{key}'")
        print(f"  Available: {list(DASHBOARDS.keys())}")
        return False

    print(f"\n  Opening: {config['html_path']}")

    # Check files exist before opening browser
    if not config["html_path"].exists():
        print(f"  ❌ HTML file not found: {config['html_path']}")
        print(f"     Run the Python generator script first.")
        return False

    if not config["excel_path"].exists():
        print(f"  ❌ Excel file not found: {config['excel_path']}")
        return False

    # Open browser and run checks
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page    = browser.new_page()

        passed = module.validate(page, config)

        browser.close()

    return passed


def run_all() -> None:
    """Run validation for all configured dashboards."""
    results = {}

    for key in DASHBOARDS:
        results[key] = run_dashboard(key)

    # Combined summary
    print(f"\n{'═' * 60}")
    print("  COMBINED SUMMARY")
    print(f"{'═' * 60}")
    for key, passed in results.items():
        icon = "✅" if passed else "❌"
        name = DASHBOARDS[key]["name"]
        print(f"  {icon}  {name}")
    print(f"{'═' * 60}\n")


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dashboard Validation")
    parser.add_argument("--dashboard", help="Dashboard key — e.g. audit, copilot")
    parser.add_argument("--all", action="store_true", help="Validate all dashboards")
    args = parser.parse_args()

    if args.all:
        run_all()
    elif args.dashboard:
        passed = run_dashboard(args.dashboard)
        sys.exit(0 if passed else 1)
    else:
        parser.print_help()
